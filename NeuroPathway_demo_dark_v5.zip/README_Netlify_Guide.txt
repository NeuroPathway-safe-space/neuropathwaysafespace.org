
NeuroPathway Demo — Dark Edition (v5)
====================================

What's inside
-------------
- index.html — the live demo (dark theme, top-left logo, welcome + slogan, glowing tabs, fade transitions, print mode)
- NeuroPathway_theme_dark.css — the deep-teal → navy theme
- netlify.toml — config for instant deploy on Netlify

How to deploy on Netlify (2 minutes)
------------------------------------
1) Go to https://www.netlify.com → Add new site → Deploy manually
2) Drag and drop these files: index.html, NeuroPathway_theme_dark.css, netlify.toml
3) Done! Netlify gives you a public URL like https://neuropathway-demo.netlify.app
4) (Optional) Site settings → Domain to rename the URL

Contact
-------
© Created by Tanja Hanson – Neurodivergent Support Initiative
Email: Tchanson87@icloud.com
