"use server";

import { createClient } from "@/lib/supabase/server";
import { headers } from "next/headers";

// Security headers for all responses
export const securityHeaders = {
  "X-DNS-Prefetch-Control": "on",
  "Strict-Transport-Security": "max-age=63072000; includeSubDomains; preload",
  "X-XSS-Protection": "1; mode=block",
  "X-Frame-Options": "SAMEORIGIN",
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "strict-origin-when-cross-origin",
  "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
  "Content-Security-Policy": 
    "default-src 'self'; " +
    "script-src 'self' 'unsafe-inline' 'unsafe-eval'; " +
    "style-src 'self' 'unsafe-inline'; " +
    "img-src 'self' data: blob: https:; " +
    "font-src 'self' data:; " +
    "connect-src 'self' https://*.supabase.co wss://*.supabase.co; " +
    "frame-ancestors 'self';",
};

// Rate limiting configuration
const RATE_LIMIT_WINDOW = 60 * 1000; // 1 minute
const RATE_LIMITS: Record<string, number> = {
  "/api": 100,           // 100 requests per minute for API
  "/auth": 10,           // 10 auth attempts per minute
  "/dashboard": 200,     // 200 requests per minute for dashboard
  default: 60,           // 60 requests per minute default
};

// Get client IP from headers
export async function getClientIP(): Promise<string> {
  const headersList = await headers();
  return (
    headersList.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    headersList.get("x-real-ip") ||
    "unknown"
  );
}

// Check if IP is blocked
export async function isIPBlocked(ip: string): Promise<boolean> {
  if (!ip || ip === "unknown") return false;
  
  try {
    const supabase = await createClient();
    const { data } = await supabase
      .from("blocked_ips")
      .select("id, expires_at")
      .eq("ip_address", ip)
      .single();

    if (!data) return false;

    // Check if block has expired
    if (data.expires_at && new Date(data.expires_at) < new Date()) {
      // Block expired, remove it
      await supabase.from("blocked_ips").delete().eq("id", data.id);
      return false;
    }

    return true;
  } catch {
    return false;
  }
}

// Check rate limit
export async function checkRateLimit(
  identifier: string,
  endpoint: string
): Promise<{ allowed: boolean; remaining: number; resetAt: Date }> {
  const supabase = await createClient();
  const now = new Date();
  const windowStart = new Date(now.getTime() - RATE_LIMIT_WINDOW);

  // Determine limit for this endpoint
  let limit = RATE_LIMITS.default;
  for (const [path, pathLimit] of Object.entries(RATE_LIMITS)) {
    if (endpoint.startsWith(path)) {
      limit = pathLimit;
      break;
    }
  }

  try {
    // Get or create rate limit record
    const { data: existing } = await supabase
      .from("rate_limits")
      .select("*")
      .eq("identifier", identifier)
      .eq("endpoint", endpoint)
      .single();

    if (existing) {
      const recordWindowStart = new Date(existing.window_start);
      
      if (recordWindowStart < windowStart) {
        // Window expired, reset counter
        await supabase
          .from("rate_limits")
          .update({ request_count: 1, window_start: now.toISOString() })
          .eq("id", existing.id);

        return {
          allowed: true,
          remaining: limit - 1,
          resetAt: new Date(now.getTime() + RATE_LIMIT_WINDOW),
        };
      }

      // Within window, check count
      if (existing.request_count >= limit) {
        return {
          allowed: false,
          remaining: 0,
          resetAt: new Date(recordWindowStart.getTime() + RATE_LIMIT_WINDOW),
        };
      }

      // Increment counter
      await supabase
        .from("rate_limits")
        .update({ request_count: existing.request_count + 1 })
        .eq("id", existing.id);

      return {
        allowed: true,
        remaining: limit - existing.request_count - 1,
        resetAt: new Date(recordWindowStart.getTime() + RATE_LIMIT_WINDOW),
      };
    }

    // No existing record, create one
    await supabase.from("rate_limits").insert({
      identifier,
      endpoint,
      request_count: 1,
      window_start: now.toISOString(),
    });

    return {
      allowed: true,
      remaining: limit - 1,
      resetAt: new Date(now.getTime() + RATE_LIMIT_WINDOW),
    };
  } catch {
    // On error, allow the request (fail open)
    return {
      allowed: true,
      remaining: limit,
      resetAt: new Date(now.getTime() + RATE_LIMIT_WINDOW),
    };
  }
}

// Log audit event
export async function logAuditEvent(params: {
  userId?: string;
  action: string;
  entityType: string;
  entityId?: string;
  oldData?: Record<string, unknown>;
  newData?: Record<string, unknown>;
}): Promise<void> {
  try {
    const supabase = await createClient();
    const ip = await getClientIP();
    const headersList = await headers();
    const userAgent = headersList.get("user-agent") || "unknown";

    await supabase.from("audit_logs").insert({
      user_id: params.userId || null,
      action: params.action,
      entity_type: params.entityType,
      entity_id: params.entityId || null,
      old_data: params.oldData || null,
      new_data: params.newData || null,
      ip_address: ip,
      user_agent: userAgent,
    });
  } catch (error) {
    console.error("Failed to log audit event:", error);
  }
}
