import { generateText } from 'ai'
import { createClient } from '@/lib/supabase/server'
import { resolveModel } from '@/lib/ai/model'

// Types for AI system
export interface AIPrompt {
  id: string
  name: string
  slug: string
  category: string
  system_prompt: string
  user_prompt_template: string
  model: string
  temperature: number
}

export interface PatternResult {
  domain: string
  pattern_name: string
  description: string
  frequency: 'rare' | 'occasional' | 'frequent' | 'very_frequent' | 'constant'
  severity: 'mild' | 'moderate' | 'significant' | 'severe'
  triggers: string[]
  protective_factors: string[]
  settings: string[]
  confidence_score: number
  evidence_count: number
  trend: 'improving' | 'stable' | 'worsening' | 'fluctuating' | 'new'
}

export interface RiskAssessment {
  status: 'green' | 'amber' | 'red'
  score: number
  reasoning: string
  concerns: Array<{
    type: string
    description: string
    observation_id?: string
    severity: string
  }>
  recommended_actions: string[]
}

export interface EHCPMapping {
  area: string
  evidence: Array<{
    observation_id: string
    summary: string
    relevance: number
  }>
  strength: 'weak' | 'moderate' | 'strong'
  gaps: string[]
  recommended_outcomes: string[]
}

export interface Strategy {
  name: string
  description: string
  implementation_steps: string[]
  target_setting: string
  evidence_base: string
  priority: 'high' | 'medium' | 'low'
}

export interface CrossSettingResult {
  consistent_behaviors: Array<{
    behavior: string
    settings: string[]
    frequency: string
  }>
  setting_specific: Array<{
    behavior: string
    setting: string
    possible_triggers: string[]
  }>
  environmental_factors: string[]
  implications: string[]
}

export interface ProgressResult {
  overall_trend: 'improving' | 'stable' | 'worsening' | 'mixed'
  domain_trends: Array<{
    domain: string
    trend: string
    change_description: string
    evidence: string[]
  }>
  key_improvements: string[]
  areas_of_concern: string[]
  recommendations: string[]
}

export interface SafeSpaceInsight {
  emotional_patterns: Array<{
    pattern: string
    frequency: string
    associated_triggers: string[]
  }>
  coping_effectiveness: Array<{
    strategy: string
    effectiveness: 'high' | 'medium' | 'low'
  }>
  concerning_trends: string[]
  protective_factors: string[]
  recommendations: string[]
}

export interface DataQualityResult {
  overall_score: number
  completeness: number
  consistency: number
  recency: number
  coverage: Record<string, number>
  missing_areas: string[]
  recommendations: string[]
}

export interface ReportContent {
  title: string
  summary: string
  sections: Array<{
    heading: string
    content: string
    evidence?: string[]
  }>
  recommendations: string[]
  next_steps: string[]
}

export interface AIRunResult {
  run_id: string
  engine_type: string
  status: 'completed' | 'failed' | 'review_required'
  confidence_score: number
  output: unknown
  requires_review: boolean
  tokens_used: number
  latency_ms: number
}

// Confidence thresholds
const CONFIDENCE_THRESHOLDS = {
  auto_approve: 0.85,
  review_required: 0.6,
  reject: 0.4
}

// AI Orchestrator class
export class AIOrchestrator {
  private supabase: Awaited<ReturnType<typeof createClient>> | null = null

  async initialize() {
    this.supabase = await createClient()
  }

  private async getPrompt(slug: string): Promise<AIPrompt | null> {
    if (!this.supabase) await this.initialize()
    
    const { data } = await this.supabase!
      .from('ai_prompts')
      .select('*')
      .eq('slug', slug)
      .eq('is_active', true)
      .single()
    
    return data
  }

  private async logRun(params: {
    user_id: string
    child_id: string
    prompt_id?: string
    engine_type: string
    input_data: unknown
    output_data?: unknown
    confidence_score?: number
    model_used: string
    tokens_used?: number
    latency_ms?: number
    status: string
    error_message?: string
    requires_review?: boolean
  }): Promise<string> {
    if (!this.supabase) await this.initialize()
    
    const { data } = await this.supabase!
      .from('ai_runs')
      .insert({
        ...params,
        input_data: params.input_data,
        output_data: params.output_data,
      })
      .select('id')
      .single()
    
    return data?.id || ''
  }

  private interpolateTemplate(template: string, variables: Record<string, string>): string {
    return template.replace(/\{\{(\w+)\}\}/g, (_, key) => variables[key] || `{{${key}}}`)
  }

  // Pattern Recognition Engine
  async analyzePatterns(params: {
    user_id: string
    child_id: string
    child_name: string
    observations: Array<{
      id: string
      behaviour: string
      antecedent?: string
      consequence?: string
      setting?: string
      time_of_day?: string
      severity?: number
      category?: string
      created_at: string
    }>
  }): Promise<AIRunResult> {
    const startTime = Date.now()
    const prompt = await this.getPrompt('pattern-recognition-v1')
    
    if (!prompt) {
      throw new Error('Pattern recognition prompt not found')
    }

    const dateRange = params.observations.length > 0
      ? `${params.observations[params.observations.length - 1].created_at.split('T')[0]} to ${params.observations[0].created_at.split('T')[0]}`
      : 'N/A'

    const userPrompt = this.interpolateTemplate(prompt.user_prompt_template, {
      observation_count: String(params.observations.length),
      child_name: params.child_name,
      date_range: dateRange
    })

    const observationsText = params.observations.map((o, i) => 
      `[${i + 1}] ID: ${o.id}\nDate: ${o.created_at}\nSetting: ${o.setting || 'Not specified'}\nTime: ${o.time_of_day || 'Not specified'}\nCategory: ${o.category || 'General'}\nSeverity: ${o.severity || 'N/A'}\nAntecedent: ${o.antecedent || 'Not recorded'}\nBehaviour: ${o.behaviour}\nConsequence: ${o.consequence || 'Not recorded'}`
    ).join('\n\n---\n\n')

    try {
      const result = await generateText({
        model: resolveModel(prompt.model),
        system: prompt.system_prompt,
        prompt: `${userPrompt}\n\nOBSERVATIONS:\n${observationsText}\n\nRespond in JSON format with an array of patterns. Each pattern should have: domain, pattern_name, description, frequency, severity, triggers (array), protective_factors (array), settings (array), confidence_score (0-1), evidence_count, trend.`,
        temperature: prompt.temperature,
      })

      const latency = Date.now() - startTime
      let patterns: PatternResult[] = []
      let confidence = 0.5

      try {
        const jsonMatch = result.text.match(/\[[\s\S]*\]/)
        if (jsonMatch) {
          patterns = JSON.parse(jsonMatch[0])
          confidence = patterns.length > 0 
            ? patterns.reduce((acc, p) => acc + p.confidence_score, 0) / patterns.length
            : 0.5
        }
      } catch {
        patterns = []
      }

      const requiresReview = confidence < CONFIDENCE_THRESHOLDS.auto_approve

      const runId = await this.logRun({
        user_id: params.user_id,
        child_id: params.child_id,
        prompt_id: prompt.id,
        engine_type: 'pattern_recognition',
        input_data: { observations: params.observations.map(o => o.id), child_name: params.child_name },
        output_data: { patterns, raw_text: result.text },
        confidence_score: confidence,
        model_used: prompt.model,
        tokens_used: result.usage?.totalTokens || 0,
        latency_ms: latency,
        status: requiresReview ? 'review_required' : 'completed',
        requires_review: requiresReview
      })

      return {
        run_id: runId,
        engine_type: 'pattern_recognition',
        status: requiresReview ? 'review_required' : 'completed',
        confidence_score: confidence,
        output: patterns,
        requires_review: requiresReview,
        tokens_used: result.usage?.totalTokens || 0,
        latency_ms: latency
      }
    } catch (error) {
      const latency = Date.now() - startTime
      const runId = await this.logRun({
        user_id: params.user_id,
        child_id: params.child_id,
        prompt_id: prompt.id,
        engine_type: 'pattern_recognition',
        input_data: { observations: params.observations.map(o => o.id) },
        model_used: prompt.model,
        latency_ms: latency,
        status: 'failed',
        error_message: error instanceof Error ? error.message : 'Unknown error'
      })

      return {
        run_id: runId,
        engine_type: 'pattern_recognition',
        status: 'failed',
        confidence_score: 0,
        output: null,
        requires_review: true,
        tokens_used: 0,
        latency_ms: latency
      }
    }
  }

  // Risk Stratification Engine
  async assessRisk(params: {
    user_id: string
    child_id: string
    observations: Array<{
      id: string
      behaviour: string
      safeguarding_concern?: boolean
      safeguarding_notes?: string
      severity?: number
      created_at: string
    }>
    youth_data?: {
      journal_entries?: Array<{ content: string; flagged_for_review?: boolean }>
      crisis_events?: Array<{ severity_level: number; trigger_source?: string }>
    }
  }): Promise<AIRunResult> {
    const startTime = Date.now()
    const prompt = await this.getPrompt('risk-stratification-v1')
    
    if (!prompt) {
      throw new Error('Risk stratification prompt not found')
    }

    const observationsText = params.observations.map((o, i) => 
      `[${i + 1}] ID: ${o.id}\nDate: ${o.created_at}\nSeverity: ${o.severity || 'N/A'}\nSafeguarding Flag: ${o.safeguarding_concern ? 'YES' : 'No'}\nBehaviour: ${o.behaviour}${o.safeguarding_notes ? `\nSafeguarding Notes: ${o.safeguarding_notes}` : ''}`
    ).join('\n\n---\n\n')

    let youthDataText = ''
    if (params.youth_data) {
      if (params.youth_data.journal_entries?.length) {
        youthDataText += '\n\nYOUTH JOURNAL ENTRIES (self-reported):\n'
        youthDataText += params.youth_data.journal_entries
          .filter(j => j.flagged_for_review)
          .map(j => `- ${j.content.substring(0, 500)}...`)
          .join('\n')
      }
      if (params.youth_data.crisis_events?.length) {
        youthDataText += '\n\nCRISIS EVENTS:\n'
        youthDataText += params.youth_data.crisis_events
          .map(c => `- Severity: ${c.severity_level}/5, Trigger: ${c.trigger_source || 'Unknown'}`)
          .join('\n')
      }
    }

    try {
      const result = await generateText({
        model: resolveModel(prompt.model),
        system: prompt.system_prompt,
        prompt: `${prompt.user_prompt_template}\n\nOBSERVATIONS:\n${observationsText}${youthDataText}\n\nRespond in JSON format with: status (green/amber/red), score (0-1), reasoning, concerns (array with type, description, observation_id, severity), recommended_actions (array of strings).`,
        temperature: prompt.temperature,
      })

      const latency = Date.now() - startTime
      let assessment: RiskAssessment = {
        status: 'green',
        score: 0,
        reasoning: '',
        concerns: [],
        recommended_actions: []
      }

      try {
        const jsonMatch = result.text.match(/\{[\s\S]*\}/)
        if (jsonMatch) {
          assessment = JSON.parse(jsonMatch[0])
        }
      } catch {
        // Default to amber if parsing fails for safety
        assessment.status = 'amber'
        assessment.reasoning = 'Unable to parse AI response - manual review required'
      }

      // Always require review for non-green assessments
      const requiresReview = assessment.status !== 'green'
      const confidence = assessment.status === 'green' ? 0.9 : assessment.status === 'amber' ? 0.7 : 0.5

      const runId = await this.logRun({
        user_id: params.user_id,
        child_id: params.child_id,
        prompt_id: prompt.id,
        engine_type: 'risk_stratification',
        input_data: { observation_ids: params.observations.map(o => o.id), has_youth_data: !!params.youth_data },
        output_data: assessment,
        confidence_score: confidence,
        model_used: prompt.model,
        tokens_used: result.usage?.totalTokens || 0,
        latency_ms: latency,
        status: requiresReview ? 'review_required' : 'completed',
        requires_review: requiresReview
      })

      // Create safeguarding alert if red or high-severity amber
      if (assessment.status === 'red' || (assessment.status === 'amber' && assessment.score > 0.7)) {
        await this.createSafeguardingAlert({
          child_id: params.child_id,
          user_id: params.user_id,
          source: 'ai_detection',
          severity: assessment.status === 'red' ? 'critical' : 'high',
          alert_type: 'AI Risk Detection',
          description: assessment.reasoning,
          ai_reasoning: JSON.stringify(assessment.concerns)
        })
      }

      return {
        run_id: runId,
        engine_type: 'risk_stratification',
        status: requiresReview ? 'review_required' : 'completed',
        confidence_score: confidence,
        output: assessment,
        requires_review: requiresReview,
        tokens_used: result.usage?.totalTokens || 0,
        latency_ms: latency
      }
    } catch (error) {
      const latency = Date.now() - startTime
      const runId = await this.logRun({
        user_id: params.user_id,
        child_id: params.child_id,
        prompt_id: prompt.id,
        engine_type: 'risk_stratification',
        input_data: { observation_ids: params.observations.map(o => o.id) },
        model_used: prompt.model,
        latency_ms: latency,
        status: 'failed',
        error_message: error instanceof Error ? error.message : 'Unknown error'
      })

      return {
        run_id: runId,
        engine_type: 'risk_stratification',
        status: 'failed',
        confidence_score: 0,
        output: null,
        requires_review: true,
        tokens_used: 0,
        latency_ms: latency
      }
    }
  }

  // EHCP Evidence Mapper
  async mapEHCPEvidence(params: {
    user_id: string
    child_id: string
    observations: Array<{
      id: string
      behaviour: string
      category?: string
      setting?: string
      created_at: string
    }>
  }): Promise<AIRunResult> {
    const startTime = Date.now()
    const prompt = await this.getPrompt('ehcp-evidence-v1')
    
    if (!prompt) {
      throw new Error('EHCP evidence prompt not found')
    }

    const observationsText = params.observations.map((o, i) => 
      `[${i + 1}] ID: ${o.id}\nCategory: ${o.category || 'General'}\nSetting: ${o.setting || 'Not specified'}\nObservation: ${o.behaviour}`
    ).join('\n\n')

    try {
      const result = await generateText({
        model: resolveModel(prompt.model),
        system: prompt.system_prompt,
        prompt: `${prompt.user_prompt_template}\n\nOBSERVATIONS:\n${observationsText}\n\nRespond in JSON format with an array of 4 objects (one per EHCP area). Each should have: area, evidence (array with observation_id, summary, relevance 0-1), strength (weak/moderate/strong), gaps (array of strings), recommended_outcomes (array of strings).`,
        temperature: prompt.temperature,
      })

      const latency = Date.now() - startTime
      let mappings: EHCPMapping[] = []
      let confidence = 0.5

      try {
        const jsonMatch = result.text.match(/\[[\s\S]*\]/)
        if (jsonMatch) {
          mappings = JSON.parse(jsonMatch[0])
          const strongCount = mappings.filter(m => m.strength === 'strong').length
          confidence = 0.5 + (strongCount * 0.125)
        }
      } catch {
        mappings = []
      }

      const requiresReview = confidence < CONFIDENCE_THRESHOLDS.auto_approve

      const runId = await this.logRun({
        user_id: params.user_id,
        child_id: params.child_id,
        prompt_id: prompt.id,
        engine_type: 'ehcp_evidence',
        input_data: { observation_ids: params.observations.map(o => o.id) },
        output_data: mappings,
        confidence_score: confidence,
        model_used: prompt.model,
        tokens_used: result.usage?.totalTokens || 0,
        latency_ms: latency,
        status: requiresReview ? 'review_required' : 'completed',
        requires_review: requiresReview
      })

      return {
        run_id: runId,
        engine_type: 'ehcp_evidence',
        status: requiresReview ? 'review_required' : 'completed',
        confidence_score: confidence,
        output: mappings,
        requires_review: requiresReview,
        tokens_used: result.usage?.totalTokens || 0,
        latency_ms: latency
      }
    } catch (error) {
      const latency = Date.now() - startTime
      const runId = await this.logRun({
        user_id: params.user_id,
        child_id: params.child_id,
        prompt_id: prompt.id,
        engine_type: 'ehcp_evidence',
        input_data: { observation_ids: params.observations.map(o => o.id) },
        model_used: prompt.model,
        latency_ms: latency,
        status: 'failed',
        error_message: error instanceof Error ? error.message : 'Unknown error'
      })

      return {
        run_id: runId,
        engine_type: 'ehcp_evidence',
        status: 'failed',
        confidence_score: 0,
        output: null,
        requires_review: true,
        tokens_used: 0,
        latency_ms: latency
      }
    }
  }

  // Strategy Generator
  async generateStrategies(params: {
    user_id: string
    child_id: string
    child_name: string
    pattern: PatternResult
    target_setting: string
  }): Promise<AIRunResult> {
    const startTime = Date.now()
    const prompt = await this.getPrompt('strategy-generator-v1')
    
    if (!prompt) {
      throw new Error('Strategy generator prompt not found')
    }

    const userPrompt = this.interpolateTemplate(prompt.user_prompt_template, {
      pattern_name: params.pattern.pattern_name,
      child_name: params.child_name,
      target_setting: params.target_setting
    })

    try {
      const result = await generateText({
        model: resolveModel(prompt.model),
        system: prompt.system_prompt,
        prompt: `${userPrompt}\n\nPattern Details:\nDomain: ${params.pattern.domain}\nDescription: ${params.pattern.description}\nFrequency: ${params.pattern.frequency}\nSeverity: ${params.pattern.severity}\nTriggers: ${params.pattern.triggers.join(', ')}\nProtective Factors: ${params.pattern.protective_factors.join(', ')}\n\nRespond in JSON format with an array of strategies. Each strategy should have: name, description, implementation_steps (array), target_setting, evidence_base, priority (high/medium/low).`,
        temperature: prompt.temperature,
      })

      const latency = Date.now() - startTime
      let strategies: Strategy[] = []

      try {
        const jsonMatch = result.text.match(/\[[\s\S]*\]/)
        if (jsonMatch) {
          strategies = JSON.parse(jsonMatch[0])
        }
      } catch {
        strategies = []
      }

      const confidence = strategies.length >= 3 ? 0.85 : strategies.length > 0 ? 0.7 : 0.3
      const requiresReview = confidence < CONFIDENCE_THRESHOLDS.auto_approve

      const runId = await this.logRun({
        user_id: params.user_id,
        child_id: params.child_id,
        prompt_id: prompt.id,
        engine_type: 'strategies',
        input_data: { pattern: params.pattern, target_setting: params.target_setting },
        output_data: strategies,
        confidence_score: confidence,
        model_used: prompt.model,
        tokens_used: result.usage?.totalTokens || 0,
        latency_ms: latency,
        status: requiresReview ? 'review_required' : 'completed',
        requires_review: requiresReview
      })

      return {
        run_id: runId,
        engine_type: 'strategies',
        status: requiresReview ? 'review_required' : 'completed',
        confidence_score: confidence,
        output: strategies,
        requires_review: requiresReview,
        tokens_used: result.usage?.totalTokens || 0,
        latency_ms: latency
      }
    } catch (error) {
      const latency = Date.now() - startTime
      const runId = await this.logRun({
        user_id: params.user_id,
        child_id: params.child_id,
        prompt_id: prompt.id,
        engine_type: 'strategies',
        input_data: { pattern: params.pattern },
        model_used: prompt.model,
        latency_ms: latency,
        status: 'failed',
        error_message: error instanceof Error ? error.message : 'Unknown error'
      })

      return {
        run_id: runId,
        engine_type: 'strategies',
        status: 'failed',
        confidence_score: 0,
        output: null,
        requires_review: true,
        tokens_used: 0,
        latency_ms: latency
      }
    }
  }

  // Create safeguarding alert
  private async createSafeguardingAlert(params: {
    child_id: string
    user_id: string
    source: string
    severity: string
    alert_type: string
    description: string
    ai_reasoning?: string
  }) {
    if (!this.supabase) await this.initialize()
    
    await this.supabase!
      .from('safeguarding_alerts')
      .insert({
        ...params,
        status: 'new'
      })
  }

  // Cross-Setting Correlation Engine
  async analyzeCrossSettings(params: {
    user_id: string
    child_id: string
    observations: Array<{
      id: string
      behaviour: string
      setting?: string
      time_of_day?: string
      triggers?: string[]
      created_at: string
    }>
  }): Promise<AIRunResult> {
    const startTime = Date.now()
    const prompt = await this.getPrompt('cross-setting-v1')
    
    if (!prompt) {
      throw new Error('Cross-setting prompt not found')
    }

    const settings = [...new Set(params.observations.map((o) => o.setting).filter(Boolean))]
    const userPrompt = this.interpolateTemplate(prompt.user_prompt_template, {
      settings: settings.join(', ')
    })

    const observationsText = params.observations.map((o, i) => 
      `[${i + 1}] Setting: ${o.setting || 'Unknown'}\nTime: ${o.time_of_day || 'N/A'}\nBehaviour: ${o.behaviour}`
    ).join('\n\n')

    try {
      const result = await generateText({
        model: resolveModel(prompt.model),
        system: prompt.system_prompt,
        prompt: `${userPrompt}\n\nOBSERVATIONS:\n${observationsText}\n\nRespond in JSON format with: consistent_behaviors (array with behavior, settings array, frequency), setting_specific (array with behavior, setting, possible_triggers array), environmental_factors (array), implications (array).`,
        temperature: prompt.temperature,
      })

      const latency = Date.now() - startTime
      let crossSettingData: CrossSettingResult = {
        consistent_behaviors: [],
        setting_specific: [],
        environmental_factors: [],
        implications: []
      }

      try {
        const jsonMatch = result.text.match(/\{[\s\S]*\}/)
        if (jsonMatch) {
          crossSettingData = JSON.parse(jsonMatch[0])
        }
      } catch {
        // Keep defaults
      }

      const confidence = crossSettingData.consistent_behaviors.length > 0 ? 0.8 : 0.5
      const requiresReview = confidence < CONFIDENCE_THRESHOLDS.auto_approve

      const runId = await this.logRun({
        user_id: params.user_id,
        child_id: params.child_id,
        prompt_id: prompt.id,
        engine_type: 'cross_setting',
        input_data: { observation_count: params.observations.length, settings },
        output_data: crossSettingData,
        confidence_score: confidence,
        model_used: prompt.model,
        tokens_used: result.usage?.totalTokens || 0,
        latency_ms: latency,
        status: requiresReview ? 'review_required' : 'completed',
        requires_review: requiresReview
      })

      return {
        run_id: runId,
        engine_type: 'cross_setting',
        status: requiresReview ? 'review_required' : 'completed',
        confidence_score: confidence,
        output: crossSettingData,
        requires_review: requiresReview,
        tokens_used: result.usage?.totalTokens || 0,
        latency_ms: latency
      }
    } catch (error) {
      const latency = Date.now() - startTime
      const runId = await this.logRun({
        user_id: params.user_id,
        child_id: params.child_id,
        engine_type: 'cross_setting',
        input_data: { observation_count: params.observations.length },
        model_used: prompt.model,
        latency_ms: latency,
        status: 'failed',
        error_message: error instanceof Error ? error.message : 'Unknown error'
      })

      return {
        run_id: runId,
        engine_type: 'cross_setting',
        status: 'failed',
        confidence_score: 0,
        output: null,
        requires_review: true,
        tokens_used: 0,
        latency_ms: latency
      }
    }
  }

  // Progress Tracking Engine
  async analyzeProgress(params: {
    user_id: string
    child_id: string
    child_name: string
    current_observations: Array<{
      id: string
      behaviour: string
      category?: string
      severity?: number
      created_at: string
    }>
    previous_assessment?: {
      patterns: PatternResult[]
      date: string
    }
  }): Promise<AIRunResult> {
    const startTime = Date.now()

    const systemPrompt = `You are an educational progress analyst. Compare current observations with previous patterns to identify improvements, regressions, and stable areas. Be specific about evidence and avoid speculation.`
    
    const currentText = params.current_observations.map((o, i) => 
      `[${i + 1}] Date: ${o.created_at}\nCategory: ${o.category || 'General'}\nSeverity: ${o.severity || 'N/A'}\nObservation: ${o.behaviour}`
    ).join('\n\n')

    const previousText = params.previous_assessment 
      ? `PREVIOUS PATTERNS (from ${params.previous_assessment.date}):\n${params.previous_assessment.patterns.map(p => 
          `- ${p.pattern_name} (${p.domain}): ${p.description} [Severity: ${p.severity}, Trend: ${p.trend}]`
        ).join('\n')}`
      : 'No previous assessment available.'

    try {
      const result = await generateText({
        model: resolveModel('openai/gpt-5'),
        system: systemPrompt,
        prompt: `Analyze progress for ${params.child_name}.\n\n${previousText}\n\nCURRENT OBSERVATIONS:\n${currentText}\n\nRespond in JSON format with: overall_trend (improving/stable/worsening/mixed), domain_trends (array with domain, trend, change_description, evidence array), key_improvements (array), areas_of_concern (array), recommendations (array).`,
        temperature: 0.3,
      })

      const latency = Date.now() - startTime
      let progressData: ProgressResult = {
        overall_trend: 'stable',
        domain_trends: [],
        key_improvements: [],
        areas_of_concern: [],
        recommendations: []
      }

      try {
        const jsonMatch = result.text.match(/\{[\s\S]*\}/)
        if (jsonMatch) {
          progressData = JSON.parse(jsonMatch[0])
        }
      } catch {
        // Keep defaults
      }

      const confidence = params.previous_assessment ? 0.8 : 0.6
      const requiresReview = confidence < CONFIDENCE_THRESHOLDS.auto_approve

      const runId = await this.logRun({
        user_id: params.user_id,
        child_id: params.child_id,
        engine_type: 'progress_tracking',
        input_data: { 
          observation_count: params.current_observations.length,
          has_previous: !!params.previous_assessment 
        },
        output_data: progressData,
        confidence_score: confidence,
        model_used: 'openai/gpt-5',
        tokens_used: result.usage?.totalTokens || 0,
        latency_ms: latency,
        status: requiresReview ? 'review_required' : 'completed',
        requires_review: requiresReview
      })

      // Store progress snapshot
      if (this.supabase) {
        await this.supabase
          .from('progress_snapshots')
          .insert({
            child_id: params.child_id,
            snapshot_date: new Date().toISOString().split('T')[0],
            domain_scores: progressData.domain_trends.reduce((acc, d) => ({
              ...acc,
              [d.domain]: d.trend
            }), {}),
            overall_trend: progressData.overall_trend,
            key_changes: {
              improvements: progressData.key_improvements,
              concerns: progressData.areas_of_concern
            }
          })
      }

      return {
        run_id: runId,
        engine_type: 'progress_tracking',
        status: requiresReview ? 'review_required' : 'completed',
        confidence_score: confidence,
        output: progressData,
        requires_review: requiresReview,
        tokens_used: result.usage?.totalTokens || 0,
        latency_ms: latency
      }
    } catch (error) {
      const latency = Date.now() - startTime
      const runId = await this.logRun({
        user_id: params.user_id,
        child_id: params.child_id,
        engine_type: 'progress_tracking',
        input_data: { observation_count: params.current_observations.length },
        model_used: 'openai/gpt-5',
        latency_ms: latency,
        status: 'failed',
        error_message: error instanceof Error ? error.message : 'Unknown error'
      })

      return {
        run_id: runId,
        engine_type: 'progress_tracking',
        status: 'failed',
        confidence_score: 0,
        output: null,
        requires_review: true,
        tokens_used: 0,
        latency_ms: latency
      }
    }
  }

  // Safe Space Insights Engine
  async analyzeSafeSpaceData(params: {
    user_id: string
    child_id: string
    youth_profile_id: string
    mood_checkins: Array<{
      mood_score: number
      energy_level: number
      anxiety_level: number
      feelings: string[]
      triggers: string[]
      created_at: string
    }>
    journal_entries: Array<{
      content: string
      detected_emotions: string[]
      created_at: string
    }>
    exercises_completed: Array<{
      exercise_type: string
      effectiveness_rating: number
    }>
  }): Promise<AIRunResult> {
    const startTime = Date.now()
    const prompt = await this.getPrompt('safe-space-insights-v1')
    
    if (!prompt) {
      throw new Error('Safe space insights prompt not found')
    }

    const moodText = params.mood_checkins.map((m, i) => 
      `[${i + 1}] Date: ${m.created_at}\nMood: ${m.mood_score}/5, Energy: ${m.energy_level}/5, Anxiety: ${m.anxiety_level}/5\nFeelings: ${m.feelings?.join(', ') || 'Not specified'}\nTriggers: ${m.triggers?.join(', ') || 'None noted'}`
    ).join('\n\n')

    const journalText = params.journal_entries.map((j, i) => 
      `[${i + 1}] Date: ${j.created_at}\nEmotions: ${j.detected_emotions?.join(', ') || 'Unknown'}\nEntry: ${j.content.substring(0, 300)}...`
    ).join('\n\n')

    const exerciseText = params.exercises_completed.length > 0
      ? `Exercises used: ${params.exercises_completed.map(e => `${e.exercise_type} (${e.effectiveness_rating}/5)`).join(', ')}`
      : 'No exercises completed.'

    try {
      const result = await generateText({
        model: resolveModel(prompt.model),
        system: prompt.system_prompt,
        prompt: `${prompt.user_prompt_template.replace('{{display_name}}', 'young person')}\n\nMOOD CHECK-INS:\n${moodText}\n\nJOURNAL ENTRIES:\n${journalText}\n\n${exerciseText}\n\nRespond in JSON format with: emotional_patterns (array with pattern, frequency, associated_triggers array), coping_effectiveness (array with strategy, effectiveness high/medium/low), concerning_trends (array), protective_factors (array), recommendations (array).`,
        temperature: prompt.temperature,
      })

      const latency = Date.now() - startTime
      let insights: SafeSpaceInsight = {
        emotional_patterns: [],
        coping_effectiveness: [],
        concerning_trends: [],
        protective_factors: [],
        recommendations: []
      }

      try {
        const jsonMatch = result.text.match(/\{[\s\S]*\}/)
        if (jsonMatch) {
          insights = JSON.parse(jsonMatch[0])
        }
      } catch {
        // Keep defaults
      }

      const hasConcerns = insights.concerning_trends.length > 0
      const confidence = hasConcerns ? 0.7 : 0.85
      const requiresReview = hasConcerns || confidence < CONFIDENCE_THRESHOLDS.auto_approve

      const runId = await this.logRun({
        user_id: params.user_id,
        child_id: params.child_id,
        engine_type: 'safe_space_insights',
        input_data: { 
          youth_profile_id: params.youth_profile_id,
          mood_count: params.mood_checkins.length,
          journal_count: params.journal_entries.length
        },
        output_data: insights,
        confidence_score: confidence,
        model_used: prompt.model,
        tokens_used: result.usage?.totalTokens || 0,
        latency_ms: latency,
        status: requiresReview ? 'review_required' : 'completed',
        requires_review: requiresReview
      })

      return {
        run_id: runId,
        engine_type: 'safe_space_insights',
        status: requiresReview ? 'review_required' : 'completed',
        confidence_score: confidence,
        output: insights,
        requires_review: requiresReview,
        tokens_used: result.usage?.totalTokens || 0,
        latency_ms: latency
      }
    } catch (error) {
      const latency = Date.now() - startTime
      const runId = await this.logRun({
        user_id: params.user_id,
        child_id: params.child_id,
        engine_type: 'safe_space_insights',
        input_data: { youth_profile_id: params.youth_profile_id },
        model_used: prompt?.model || 'unknown',
        latency_ms: latency,
        status: 'failed',
        error_message: error instanceof Error ? error.message : 'Unknown error'
      })

      return {
        run_id: runId,
        engine_type: 'safe_space_insights',
        status: 'failed',
        confidence_score: 0,
        output: null,
        requires_review: true,
        tokens_used: 0,
        latency_ms: latency
      }
    }
  }

  // Data Quality Engine
  async assessDataQuality(params: {
    user_id: string
    child_id: string
    observations: Array<{
      behaviour: string
      antecedent?: string
      consequence?: string
      setting?: string
      time_of_day?: string
      category?: string
      created_at: string
    }>
  }): Promise<AIRunResult> {
    const startTime = Date.now()
    const observations = params.observations

    // Calculate metrics
    const totalCount = observations.length
    const withAntecedent = observations.filter(o => o.antecedent).length
    const withConsequence = observations.filter(o => o.consequence).length
    const withSetting = observations.filter(o => o.setting).length
    const withTime = observations.filter(o => o.time_of_day).length
    const withCategory = observations.filter(o => o.category).length

    const completeness = totalCount > 0 
      ? (withAntecedent + withConsequence + withSetting + withTime + withCategory) / (totalCount * 5)
      : 0

    // Check recency
    const now = new Date()
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)
    const recentCount = observations.filter(o => new Date(o.created_at) > thirtyDaysAgo).length
    const recency = totalCount > 0 ? recentCount / totalCount : 0

    // Check coverage by category
    const categories = ['Attention/Focus', 'Emotional Regulation', 'Social Interaction', 'Sensory Needs', 'Learning Engagement', 'Communication', 'Physical/Motor', 'Self-Care']
    const observedCategories = new Set(observations.map(o => o.category).filter(Boolean))
    const coverage: Record<string, number> = {}
    categories.forEach(cat => {
      const count = observations.filter(o => o.category === cat).length
      coverage[cat] = count / Math.max(totalCount, 1)
    })

    // Missing areas
    const missingAreas = categories.filter(cat => !observedCategories.has(cat))

    // Calculate overall score
    const overallScore = (completeness * 0.4) + (recency * 0.3) + ((1 - missingAreas.length / categories.length) * 0.3)

    // Generate recommendations
    const recommendations: string[] = []
    if (completeness < 0.5) {
      recommendations.push('Add more context to observations: include what happened before (antecedent) and after (consequence)')
    }
    if (recency < 0.3) {
      recommendations.push('Most observations are over 30 days old - continue logging recent behaviours')
    }
    if (missingAreas.length > 4) {
      recommendations.push(`Consider observations in these areas: ${missingAreas.slice(0, 3).join(', ')}`)
    }
    if (totalCount < 10) {
      recommendations.push('More observations needed for reliable pattern analysis (aim for 20+)')
    }

    const dataQuality: DataQualityResult = {
      overall_score: overallScore,
      completeness,
      consistency: 0.8, // Would need more complex analysis
      recency,
      coverage,
      missing_areas: missingAreas,
      recommendations
    }

    const latency = Date.now() - startTime

    const runId = await this.logRun({
      user_id: params.user_id,
      child_id: params.child_id,
      engine_type: 'data_quality',
      input_data: { observation_count: totalCount },
      output_data: dataQuality,
      confidence_score: 1, // Deterministic calculation
      model_used: 'deterministic',
      tokens_used: 0,
      latency_ms: latency,
      status: 'completed',
      requires_review: false
    })

    return {
      run_id: runId,
      engine_type: 'data_quality',
      status: 'completed',
      confidence_score: 1,
      output: dataQuality,
      requires_review: false,
      tokens_used: 0,
      latency_ms: latency
    }
  }

  // Report Writer Engine
  async generateReport(params: {
    user_id: string
    child_id: string
    child_name: string
    report_type: 'parent_summary' | 'teacher_summary' | 'clinical_summary' | 'ehcp_evidence'
    assessment: {
      patterns: PatternResult[]
      risk_status: string
      ehcp_mapping?: EHCPMapping[]
      strategies?: Strategy[]
    }
  }): Promise<AIRunResult> {
    const startTime = Date.now()

    const voiceGuidance = {
      parent_summary: 'Write in warm, accessible language for parents. Avoid jargon. Focus on practical strategies and positive framing while being honest about challenges.',
      teacher_summary: 'Write professionally for educators. Include classroom-specific strategies and reference educational frameworks where relevant.',
      clinical_summary: 'Write formally for clinical professionals. Use appropriate clinical terminology and reference relevant guidelines (NICE, DSM-5 criteria descriptions).',
      ehcp_evidence: 'Write in EHCP-appropriate language. Map evidence to the four needs areas. Include specific dated observations as evidence. Reference the SEND Code of Practice.'
    }

    const systemPrompt = `You are an expert report writer for SEND documentation. ${voiceGuidance[params.report_type]}`

    const patternsText = params.assessment.patterns.map(p => 
      `- ${p.pattern_name} (${p.domain}): ${p.description}. Severity: ${p.severity}, Frequency: ${p.frequency}. Triggers: ${p.triggers.join(', ')}. Protective factors: ${p.protective_factors.join(', ')}.`
    ).join('\n')

    const strategiesText = params.assessment.strategies?.map(s =>
      `- ${s.name}: ${s.description} (Priority: ${s.priority})`
    ).join('\n') || 'Strategies to be developed.'

    try {
      const result = await generateText({
        model: resolveModel('openai/gpt-5'),
        system: systemPrompt,
        prompt: `Generate a ${params.report_type.replace('_', ' ')} report for ${params.child_name}.\n\nIDENTIFIED PATTERNS:\n${patternsText}\n\nRISK STATUS: ${params.assessment.risk_status}\n\nSTRATEGIES:\n${strategiesText}\n\nRespond in JSON format with: title, summary (2-3 paragraphs), sections (array with heading, content, evidence array), recommendations (array), next_steps (array).`,
        temperature: 0.4,
      })

      const latency = Date.now() - startTime
      let report: ReportContent = {
        title: `${params.report_type.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())} for ${params.child_name}`,
        summary: '',
        sections: [],
        recommendations: [],
        next_steps: []
      }

      try {
        const jsonMatch = result.text.match(/\{[\s\S]*\}/)
        if (jsonMatch) {
          report = JSON.parse(jsonMatch[0])
        }
      } catch {
        // Keep defaults
      }

      const confidence = report.sections.length >= 3 ? 0.8 : 0.6
      const requiresReview = true // All reports require review before finalization

      const runId = await this.logRun({
        user_id: params.user_id,
        child_id: params.child_id,
        engine_type: 'report_writer',
        input_data: { report_type: params.report_type, pattern_count: params.assessment.patterns.length },
        output_data: report,
        confidence_score: confidence,
        model_used: 'openai/gpt-5',
        tokens_used: result.usage?.totalTokens || 0,
        latency_ms: latency,
        status: 'review_required',
        requires_review: true
      })

      // Store report
      if (this.supabase) {
        await this.supabase
          .from('ai_reports')
          .insert({
            user_id: params.user_id,
            child_id: params.child_id,
            report_type: params.report_type,
            title: report.title,
            content: report,
            status: 'draft'
          })
      }

      return {
        run_id: runId,
        engine_type: 'report_writer',
        status: 'review_required',
        confidence_score: confidence,
        output: report,
        requires_review: true,
        tokens_used: result.usage?.totalTokens || 0,
        latency_ms: latency
      }
    } catch (error) {
      const latency = Date.now() - startTime
      const runId = await this.logRun({
        user_id: params.user_id,
        child_id: params.child_id,
        engine_type: 'report_writer',
        input_data: { report_type: params.report_type },
        model_used: 'openai/gpt-5',
        latency_ms: latency,
        status: 'failed',
        error_message: error instanceof Error ? error.message : 'Unknown error'
      })

      return {
        run_id: runId,
        engine_type: 'report_writer',
        status: 'failed',
        confidence_score: 0,
        output: null,
        requires_review: true,
        tokens_used: 0,
        latency_ms: latency
      }
    }
  }

  // Full Assessment Pipeline
  async runFullAssessment(params: {
    user_id: string
    child_id: string
    child_name: string
  }): Promise<{
    assessment_id: string
    patterns: AIRunResult
    risk: AIRunResult
    ehcp: AIRunResult
    strategies: AIRunResult[]
  }> {
    if (!this.supabase) await this.initialize()

    // Fetch observations
    const { data: observations } = await this.supabase!
      .from('observations')
      .select('*')
      .eq('child_id', params.child_id)
      .order('created_at', { ascending: false })
      .limit(100)

    if (!observations || observations.length === 0) {
      throw new Error('No observations found for this child')
    }

    // Fetch youth data if linked
    const { data: youthProfile } = await this.supabase!
      .from('youth_profiles')
      .select('id')
      .eq('linked_child_id', params.child_id)
      .single()

    let youthData = undefined
    if (youthProfile) {
      const [journalRes, crisisRes] = await Promise.all([
        this.supabase!
          .from('youth_journal_entries')
          .select('content, flagged_for_review')
          .eq('youth_profile_id', youthProfile.id)
          .eq('flagged_for_review', true)
          .limit(10),
        this.supabase!
          .from('youth_crisis_events')
          .select('severity_level, trigger_source')
          .eq('youth_profile_id', youthProfile.id)
          .limit(10)
      ])
      youthData = {
        journal_entries: journalRes.data || [],
        crisis_events: crisisRes.data || []
      }
    }

    // Run all engines in parallel
    const [patternsResult, riskResult, ehcpResult] = await Promise.all([
      this.analyzePatterns({
        user_id: params.user_id,
        child_id: params.child_id,
        child_name: params.child_name,
        observations
      }),
      this.assessRisk({
        user_id: params.user_id,
        child_id: params.child_id,
        observations,
        youth_data: youthData
      }),
      this.mapEHCPEvidence({
        user_id: params.user_id,
        child_id: params.child_id,
        observations
      })
    ])

    // Generate strategies for top 3 patterns
    const patterns = (patternsResult.output as PatternResult[]) || []
    const topPatterns = patterns
      .sort((a, b) => b.confidence_score - a.confidence_score)
      .slice(0, 3)

    const strategyResults = await Promise.all(
      topPatterns.map(pattern =>
        this.generateStrategies({
          user_id: params.user_id,
          child_id: params.child_id,
          child_name: params.child_name,
          pattern,
          target_setting: pattern.settings[0] || 'home'
        })
      )
    )

    // Calculate overall confidence
    const allConfidences = [
      patternsResult.confidence_score,
      riskResult.confidence_score,
      ehcpResult.confidence_score,
      ...strategyResults.map(s => s.confidence_score)
    ]
    const overallConfidence = allConfidences.reduce((a, b) => a + b, 0) / allConfidences.length

    // Determine dates
    const dates = observations.map(o => new Date(o.created_at))
    const dateRangeStart = new Date(Math.min(...dates.map(d => d.getTime())))
    const dateRangeEnd = new Date(Math.max(...dates.map(d => d.getTime())))

    // Create assessment record
    const riskAssessment = riskResult.output as RiskAssessment
    const { data: assessment } = await this.supabase!
      .from('ai_assessments')
      .insert({
        user_id: params.user_id,
        child_id: params.child_id,
        assessment_type: 'full',
        status: overallConfidence >= CONFIDENCE_THRESHOLDS.auto_approve ? 'draft' : 'pending_review',
        patterns: patterns,
        pattern_confidence: patternsResult.confidence_score,
        risk_status: riskAssessment?.status || 'green',
        risk_reasoning: riskAssessment?.reasoning || '',
        risk_score: riskAssessment?.score || 0,
        safeguarding_flags: riskAssessment?.concerns || [],
        requires_escalation: riskAssessment?.status === 'red',
        data_quality_score: observations.length >= 20 ? 0.9 : observations.length >= 10 ? 0.7 : 0.5,
        observation_count: observations.length,
        date_range_start: dateRangeStart.toISOString().split('T')[0],
        date_range_end: dateRangeEnd.toISOString().split('T')[0],
        settings_included: [...new Set(observations.map(o => o.setting).filter(Boolean))]
      })
      .select('id')
      .single()

    // Store patterns
    if (assessment && patterns.length > 0) {
      await this.supabase!
        .from('ai_patterns')
        .insert(
          patterns.map(p => ({
            assessment_id: assessment.id,
            child_id: params.child_id,
            domain: p.domain,
            pattern_name: p.pattern_name,
            description: p.description,
            frequency: p.frequency,
            severity: p.severity,
            triggers: p.triggers,
            protective_factors: p.protective_factors,
            settings: p.settings,
            confidence_score: p.confidence_score,
            evidence_count: p.evidence_count,
            trend: p.trend,
            first_observed: dateRangeStart.toISOString().split('T')[0],
            last_observed: dateRangeEnd.toISOString().split('T')[0]
          }))
        )
    }

    // Store strategies
    if (assessment) {
      const allStrategies = strategyResults.flatMap(r => (r.output as Strategy[]) || [])
      if (allStrategies.length > 0) {
        await this.supabase!
          .from('ai_strategies')
          .insert(
            allStrategies.map(s => ({
              assessment_id: assessment.id,
              child_id: params.child_id,
              domain: topPatterns[0]?.domain || 'General',
              strategy_name: s.name,
              description: s.description,
              implementation_steps: s.implementation_steps,
              target_setting: s.target_setting,
              evidence_base: s.evidence_base,
              priority: s.priority,
              status: 'suggested'
            }))
          )
      }
    }

    // Create human review if needed
    if (overallConfidence < CONFIDENCE_THRESHOLDS.auto_approve && assessment) {
      await this.supabase!
        .from('human_reviews')
        .insert({
          reviewable_type: 'assessment',
          reviewable_id: assessment.id,
          child_id: params.child_id,
          user_id: params.user_id,
          priority: riskAssessment?.status === 'red' ? 'urgent' : overallConfidence < CONFIDENCE_THRESHOLDS.review_required ? 'high' : 'medium',
          reason: `Auto-flagged: Overall confidence ${(overallConfidence * 100).toFixed(0)}% below threshold`,
          ai_confidence: overallConfidence,
          status: 'pending'
        })
    }

    return {
      assessment_id: assessment?.id || '',
      patterns: patternsResult,
      risk: riskResult,
      ehcp: ehcpResult,
      strategies: strategyResults
    }
  }
}

// Export singleton
export const aiOrchestrator = new AIOrchestrator()
