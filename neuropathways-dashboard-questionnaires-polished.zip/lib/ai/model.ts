import { createOpenAICompatible } from '@ai-sdk/openai-compatible'
import type { LanguageModel } from 'ai'

/**
 * Central model resolver for the NeuroPathway AI engines.
 *
 * When the Azure AI Foundry deployment ("neuropathway-ai") is configured via
 * environment variables, every engine is routed through it. Otherwise we fall
 * back to the Vercel AI Gateway model string stored against each prompt
 * (e.g. "openai/gpt-5"), so the app keeps working without Azure configured.
 *
 * The Foundry resource exposes the new OpenAI-compatible v1 surface at
 * `{host}/openai/v1`, which authenticates with an `api-key` header and does
 * NOT use the legacy `?api-version=` query scheme. We therefore route through
 * `@ai-sdk/openai-compatible` rather than `@ai-sdk/azure`.
 *
 * Env vars (any that contains the resource host works; values are tolerant of
 * being a bare host, an `/openai` URL, or a full `/openai/v1` URL):
 *  - AZURE_FOUNDRY_ENDPOINT
 *  - AZURE_FOUNDRY_DEPLOYMENT
 *  - AZURE_FOUNDRY_API_KEY      (required)
 * Optional:
 *  - AZURE_FOUNDRY_MODEL        explicit deployment/model name override
 */

const rawEndpoint = process.env.AZURE_FOUNDRY_ENDPOINT?.trim()
const rawDeployment = process.env.AZURE_FOUNDRY_DEPLOYMENT?.trim()
const apiKey = process.env.AZURE_FOUNDRY_API_KEY?.trim()
const explicitModel = process.env.AZURE_FOUNDRY_MODEL?.trim()

const DEFAULT_DEPLOYMENT = 'gpt-4.1-mini'

const looksLikeUrl = (v?: string): v is string => !!v && /^https?:\/\//i.test(v)

/**
 * Build the OpenAI-compatible base URL (must end in `/openai/v1`).
 * Prefers whichever env var actually contains the Azure resource host.
 */
function resolveBaseURL(): string | null {
  const candidate =
    [rawDeployment, rawEndpoint].find((v) => looksLikeUrl(v) && /\.openai\.azure\.com/i.test(v)) ??
    [rawEndpoint, rawDeployment].find(looksLikeUrl)

  if (!candidate) return null
  const base = candidate.replace(/\/+$/, '')

  if (/\/openai\/v1$/i.test(base)) return base
  if (/\/openai$/i.test(base)) return `${base}/v1`
  if (/\.openai\.azure\.com$/i.test(base)) return `${base}/openai/v1`
  return `${base.replace(/\/openai.*/i, '')}/openai/v1`
}

const baseURL = resolveBaseURL()

/**
 * The deployment/model name to call: an explicit override, a non-URL
 * "deployment" value, or the verified default deployment on the resource.
 */
export const azureDeployment =
  explicitModel ||
  (rawDeployment && !looksLikeUrl(rawDeployment) ? rawDeployment : undefined) ||
  DEFAULT_DEPLOYMENT

export const isAzureFoundryConfigured = Boolean(baseURL && apiKey)

const azure =
  isAzureFoundryConfigured && baseURL
    ? createOpenAICompatible({
        name: 'azure-foundry',
        baseURL,
        // Azure authenticates with the `api-key` header (not a Bearer token).
        headers: { 'api-key': apiKey as string },
      })
    : null

/**
 * Resolve the model to use for a generateText/streamText call.
 *
 * @param gatewayModel The AI Gateway model string stored on the prompt
 *                     (used as a fallback when Azure is not configured).
 */
export function resolveModel(gatewayModel?: string): LanguageModel {
  if (azure) {
    return azure(azureDeployment)
  }
  return (gatewayModel || 'openai/gpt-5') as LanguageModel
}

/** Human-readable description of the active AI backend (for health checks/UI). */
export function activeModelLabel(gatewayModel?: string): string {
  if (isAzureFoundryConfigured) {
    return `Azure AI Foundry · ${azureDeployment}`
  }
  return gatewayModel || 'openai/gpt-5'
}
