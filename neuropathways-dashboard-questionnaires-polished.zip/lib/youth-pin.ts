import { scryptSync, randomBytes, timingSafeEqual } from "crypto";

/**
 * Lightweight PIN hashing for the Safe Space child login.
 *
 * Children are NOT Supabase auth users. They identify themselves with their
 * link code plus a short PIN. We still never store the PIN in plain text:
 * each PIN is salted and hashed with scrypt. This is intentionally simple
 * (a 4+ digit numeric PIN, not a full password) to keep the child experience
 * low-friction while avoiding storing a recoverable secret.
 */

const KEYLEN = 64;

export function hashPin(pin: string): string {
  const salt = randomBytes(16).toString("hex");
  const derived = scryptSync(pin, salt, KEYLEN).toString("hex");
  return `${salt}:${derived}`;
}

export function verifyPin(pin: string, stored: string | null | undefined): boolean {
  if (!stored) return false;
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const derived = scryptSync(pin, salt, KEYLEN);
  const hashBuf = Buffer.from(hash, "hex");
  if (hashBuf.length !== derived.length) return false;
  return timingSafeEqual(hashBuf, derived);
}

/** A PIN must be 4-8 digits. */
export function isValidPin(pin: string): boolean {
  return /^\d{4,8}$/.test(pin);
}
