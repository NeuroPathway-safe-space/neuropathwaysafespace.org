/****************************************************************
 * NeuroPathway - Behavioural Pattern Engine (Deterministic)
 * ---------------------------------------------------------------
 * Rule-based, AI-free analysis of behavioural observations.
 * Fast, free, and fully explainable - complements the AI
 * orchestrator (lib/ai/orchestrator.ts) which uses LLMs.
 *
 * SAFE DESIGN:
 * - DOES NOT diagnose.
 * - ONLY identifies patterns, trends, and support needs.
 *
 * Mapped to the real `observations` table schema:
 *   id, created_at, setting, time_of_day, category,
 *   severity (1-4), antecedent (trigger), behaviour,
 *   consequence, intervention, outcome, safeguarding_concern
 ****************************************************************/

/***************************************************************
 * 1. OBSERVATION CATEGORIES (EHCP-aligned domains)
 ****************************************************************/

export const ObservationCategories = {
  emotional_regulation: [
    'overwhelm',
    'shutdown',
    'distress',
    'frustration',
    'anxiety',
    'anger',
    'mood_change',
  ],
  attention_executive: [
    'focus',
    'organisation',
    'task_completion',
    'memory',
    'following_instructions',
    'impulsivity',
  ],
  communication_social: [
    'friendships',
    'communication_style',
    'peer_interaction',
    'misunderstandings',
    'isolation',
    'confidence',
  ],
  attendance_engagement: [
    'school_refusal',
    'lateness',
    'avoidance',
    'participation',
    'engagement',
  ],
  sensory_environmental: [
    'noise_sensitivity',
    'crowds',
    'lighting',
    'transitions',
    'transport_stress',
    'unpredictability',
  ],
  wellbeing: [
    'sleep',
    'appetite',
    'motivation',
    'withdrawal',
    'emotional_wellbeing',
    'resilience',
  ],
  strengths_protective: [
    'hobbies',
    'trusted_adults',
    'pets',
    'positive_relationships',
    'emotional_awareness',
    'achievements',
  ],
} as const

export type DomainKey = keyof typeof ObservationCategories

/***************************************************************
 * 2. OBSERVATION INPUT TYPE (matches DB schema)
 ****************************************************************/

export interface ObservationInput {
  id?: string
  created_at?: string
  setting?: string | null
  time_of_day?: string | null
  category?: string | null
  /** 1-4 in the DB (mild..severe) */
  severity?: number | null
  /** how often this kind of behaviour occurs; 1-4 if recorded */
  frequency?: number | null
  /** antecedent / what came before */
  antecedent?: string | null
  trigger?: string | null
  behaviour?: string | null
  consequence?: string | null
  intervention?: string | null
  outcome?: string | null
  safeguarding_concern?: boolean | null
}

/***************************************************************
 * 3. RESULT TYPES
 ****************************************************************/

export interface DomainPattern {
  domain: string
  count: number
  averageSeverity: number
  environments: string[]
  topTriggers: Array<{ trigger: string; count: number }>
  topInterventions: Array<{ intervention: string; count: number }>
}

export interface EnvironmentComparison {
  environment: string
  observations: number
  totalSeverity: number
  averageSeverity: number
}

export interface EscalationMarker {
  concern: string
  level: 'HIGH' | 'CRITICAL'
  environment: string
  trigger: string | null
  observationId?: string
}

export interface InterventionStat {
  intervention: string
  used: number
  successful: number
  successRate: number
}

export interface ProtectiveFactor {
  name: string
  strength: 'Strong' | 'Moderate' | 'Emerging'
}

export interface EngineSummary {
  generatedAt: string
  observationCount: number
  detectedPatterns: DomainPattern[]
  environmentComparison: EnvironmentComparison[]
  escalationMarkers: EscalationMarker[]
  interventionEffectiveness: InterventionStat[]
  protectiveFactors: ProtectiveFactor[]
  professionalNote: string
  disclaimer: string
}

/***************************************************************
 * 4. HELPERS
 ****************************************************************/

function resolveTrigger(obs: ObservationInput): string | null {
  return obs.trigger ?? obs.antecedent ?? null
}

function sortCounts(map: Record<string, number>) {
  return Object.entries(map)
    .map(([key, count]) => ({ key, count }))
    .sort((a, b) => b.count - a.count)
}

/***************************************************************
 * 5. PATTERN DETECTION ENGINE
 ****************************************************************/

export function detectPatterns(observations: ObservationInput[]): DomainPattern[] {
  const patterns: Record<
    string,
    {
      count: number
      severityTotal: number
      environments: Set<string>
      triggers: Record<string, number>
      interventions: Record<string, number>
    }
  > = {}

  for (const obs of observations) {
    const key = obs.category || 'uncategorised'

    if (!patterns[key]) {
      patterns[key] = {
        count: 0,
        severityTotal: 0,
        environments: new Set<string>(),
        triggers: {},
        interventions: {},
      }
    }

    patterns[key].count += 1
    patterns[key].severityTotal += obs.severity ?? 0
    if (obs.setting) patterns[key].environments.add(obs.setting)

    const trigger = resolveTrigger(obs)
    if (trigger) {
      patterns[key].triggers[trigger] = (patterns[key].triggers[trigger] || 0) + 1
    }

    if (obs.intervention) {
      patterns[key].interventions[obs.intervention] =
        (patterns[key].interventions[obs.intervention] || 0) + 1
    }
  }

  return Object.entries(patterns)
    .map(([domain, data]) => ({
      domain,
      count: data.count,
      averageSeverity: data.count ? Number((data.severityTotal / data.count).toFixed(2)) : 0,
      environments: [...data.environments],
      topTriggers: sortCounts(data.triggers)
        .slice(0, 3)
        .map((t) => ({ trigger: t.key, count: t.count })),
      topInterventions: sortCounts(data.interventions)
        .slice(0, 3)
        .map((i) => ({ intervention: i.key, count: i.count })),
    }))
    .sort((a, b) => b.count - a.count)
}

/***************************************************************
 * 6. ENVIRONMENT COMPARISON
 ****************************************************************/

export function compareEnvironments(
  observations: ObservationInput[],
): EnvironmentComparison[] {
  const comparison: Record<string, { totalSeverity: number; observations: number }> = {}

  for (const obs of observations) {
    const env = obs.setting || 'unspecified'
    if (!comparison[env]) {
      comparison[env] = { totalSeverity: 0, observations: 0 }
    }
    comparison[env].totalSeverity += obs.severity ?? 0
    comparison[env].observations += 1
  }

  return Object.entries(comparison)
    .map(([environment, data]) => ({
      environment,
      observations: data.observations,
      totalSeverity: data.totalSeverity,
      averageSeverity: data.observations
        ? Number((data.totalSeverity / data.observations).toFixed(2))
        : 0,
    }))
    .sort((a, b) => b.averageSeverity - a.averageSeverity)
}

/***************************************************************
 * 7. ESCALATION DETECTION
 ****************************************************************/

export function detectEscalation(observations: ObservationInput[]): EscalationMarker[] {
  const escalation: EscalationMarker[] = []

  for (const obs of observations) {
    const severity = obs.severity ?? 0
    const frequency = obs.frequency ?? 0
    const safeguarding = obs.safeguarding_concern === true

    if (safeguarding || (severity >= 3 && frequency >= 3)) {
      escalation.push({
        concern: obs.behaviour || 'Unspecified concern',
        level: safeguarding || severity >= 4 ? 'CRITICAL' : 'HIGH',
        environment: obs.setting || 'unspecified',
        trigger: resolveTrigger(obs),
        observationId: obs.id,
      })
    }
  }

  return escalation
}

/***************************************************************
 * 8. INTERVENTION EFFECTIVENESS
 ****************************************************************/

export function interventionEffectiveness(
  observations: ObservationInput[],
): InterventionStat[] {
  const interventions: Record<string, { used: number; successful: number }> = {}

  for (const obs of observations) {
    if (!obs.intervention) continue

    if (!interventions[obs.intervention]) {
      interventions[obs.intervention] = { used: 0, successful: 0 }
    }

    interventions[obs.intervention].used += 1

    const outcome = (obs.outcome || '').toLowerCase()
    if (outcome.includes('improved') || outcome.includes('settled') || outcome.includes('calm')) {
      interventions[obs.intervention].successful += 1
    }
  }

  return Object.entries(interventions)
    .map(([intervention, data]) => ({
      intervention,
      used: data.used,
      successful: data.successful,
      successRate: data.used ? Number(((data.successful / data.used) * 100).toFixed(0)) : 0,
    }))
    .sort((a, b) => b.successRate - a.successRate)
}

/***************************************************************
 * 9. PROTECTIVE FACTOR ENGINE
 ****************************************************************/

export function deriveProtectiveFactors(
  observations: ObservationInput[],
): ProtectiveFactor[] {
  const counts: Record<string, number> = {}

  for (const obs of observations) {
    if (obs.category === 'strengths_protective') {
      const name = obs.intervention || obs.behaviour || 'Positive engagement'
      counts[name] = (counts[name] || 0) + 1
    }
  }

  return sortCounts(counts).map(({ key, count }) => ({
    name: key,
    strength: count >= 3 ? 'Strong' : count === 2 ? 'Moderate' : 'Emerging',
  }))
}

/***************************************************************
 * 10. SUMMARY GENERATOR (needs-first, non-diagnostic)
 ****************************************************************/

export function generateSummary(observations: ObservationInput[]): EngineSummary {
  const detectedPatterns = detectPatterns(observations)
  const environmentComparison = compareEnvironments(observations)
  const escalationMarkers = detectEscalation(observations)
  const interventionStats = interventionEffectiveness(observations)
  const protectiveFactors = deriveProtectiveFactors(observations)

  const highestEnv = environmentComparison[0]
  const dominantDomain = detectedPatterns[0]

  let professionalNote =
    'Observations indicate support needs may be present. Further monitoring and contextual exploration may help.'

  if (dominantDomain && highestEnv) {
    professionalNote =
      `Recorded observations most frequently relate to ${dominantDomain.domain.replace(/_/g, ' ')}, ` +
      `with the highest average severity seen in the ${highestEnv.environment} setting. ` +
      `This suggests support needs may be concentrated in specific environments and benefit from targeted, ` +
      `environment-aware strategies. These observations describe patterns and needs only and are not a diagnosis.`
  }

  return {
    generatedAt: new Date().toISOString(),
    observationCount: observations.length,
    detectedPatterns,
    environmentComparison,
    escalationMarkers,
    interventionEffectiveness: interventionStats,
    protectiveFactors,
    professionalNote,
    disclaimer:
      'This summary identifies patterns and support needs only. It does not diagnose. ' +
      'Safeguarding concerns must be reported to your DSL or local authority immediately.',
  }
}
