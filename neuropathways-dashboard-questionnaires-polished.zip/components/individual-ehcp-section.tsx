"use client";

import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, TrendingUp, Users, Shield, ArrowRight } from "lucide-react";
import Link from "next/link";

export function IndividualEHCPSection() {
  const features = [
    {
      icon: FileText,
      title: "Document Daily Observations",
      description: "Record behaviours, triggers, and patterns as they happen",
    },
    {
      icon: TrendingUp,
      title: "Pattern Recognition",
      description: "System identifies trends over time for stronger evidence",
    },
    {
      icon: Users,
      title: "Share with Professionals",
      description: "Export reports for schools, GPs, and CAMHS",
    },
    {
      icon: Shield,
      title: "Protect Your Rights",
      description: "Build legally enforceable EHCP evidence",
    },
  ];

  return (
    <section className="px-4 py-12 md:py-16">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-10">
          <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
            For Parents &amp; Individuals
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            EHCPs remain the only legally enforceable way to secure SEND support. 
            NeuroPathway helps you gather the evidence you need.
          </p>
        </div>

        {/* Info Box */}
        <Card className="bg-amber-500/10 border-amber-500/30 mb-8">
          <CardContent className="p-4 md:p-6">
            <p className="text-sm md:text-base text-foreground/90">
              <span className="font-semibold text-amber-500">Why this matters:</span>{" "}
              The Government&apos;s proposed Individual Support Plans (ISPs) do not provide 
              the same legal protections as EHCPs. Strong evidence is essential.
            </p>
          </CardContent>
        </Card>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {features.map((feature) => (
            <Card key={feature.title} className="bg-card border-border">
              <CardContent className="p-5">
                <div className="flex items-start gap-4">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <feature.icon className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground mb-1">
                      {feature.title}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {feature.description}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Priority Note */}
        <Card className="bg-secondary/50 border-border mt-8">
          <CardContent className="p-4 text-center">
            <p className="text-sm text-muted-foreground">
              <span className="font-medium text-foreground">Needs-based priority:</span>{" "}
              Cases are reviewed by level of need, not first-come-first-served. 
              Strong pattern evidence helps demonstrate urgency.
            </p>
          </CardContent>
        </Card>

        {/* CTA */}
        <div className="mt-8 text-center">
          <Link href="/auth/sign-up?type=parent">
            <Button size="lg" className="gap-2">
              Start Building Your Evidence
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
