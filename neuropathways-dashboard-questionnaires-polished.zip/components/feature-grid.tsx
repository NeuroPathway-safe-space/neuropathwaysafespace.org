import { Badge } from "@/components/ui/badge"
import {
  Brain,
  Cpu,
  Shield,
  Zap,
  RefreshCw,
  BarChart3,
} from "lucide-react"

const features = [
  {
    icon: Brain,
    title: "Cognitive Mapping",
    description:
      "Advanced algorithms map thought patterns in real-time, creating a digital mirror of cognitive processes.",
    tag: "System 1",
  },
  {
    icon: Cpu,
    title: "Neural Processing",
    description:
      "High-speed signal processing interprets neural data with unprecedented accuracy and minimal latency.",
    tag: "System 2",
  },
  {
    icon: RefreshCw,
    title: "Seamless Integration",
    description:
      "Both systems work together harmoniously, sharing data and insights for comprehensive analysis.",
    tag: "2-in-1",
  },
  {
    icon: Zap,
    title: "Real-time Response",
    description:
      "Sub-millisecond processing ensures immediate feedback for applications requiring instant interaction.",
    tag: "Performance",
  },
  {
    icon: Shield,
    title: "Privacy First",
    description:
      "End-to-end encryption and local processing options keep your neural data secure and private.",
    tag: "Security",
  },
  {
    icon: BarChart3,
    title: "Advanced Analytics",
    description:
      "Comprehensive dashboards and reports provide deep insights into cognitive patterns over time.",
    tag: "Insights",
  },
]

export function FeatureGrid() {
  return (
    <section id="features" className="bg-secondary/30 px-4 py-16 md:py-24">
      <div className="mx-auto max-w-6xl">
        <div className="mb-12 text-center">
          <Badge variant="secondary" className="mb-4">
            Features
          </Badge>
          <h2 className="mb-4 text-3xl font-bold text-foreground md:text-4xl">
            Why Choose NeuroPathway?
          </h2>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            Our 2-in-1 ecosystem offers unparalleled capabilities for
            brain-computer interface applications.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {features.map((feature) => (
            <div
              key={feature.title}
              className="group rounded-xl border border-border bg-card p-6 transition-all hover:border-primary/50 hover:bg-card/80"
            >
              <div className="mb-4 flex items-center justify-between">
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 text-primary transition-colors group-hover:bg-primary/20">
                  <feature.icon className="h-6 w-6" />
                </div>
                <Badge
                  variant="outline"
                  className="border-primary/30 text-primary"
                >
                  {feature.tag}
                </Badge>
              </div>
              <h3 className="mb-2 text-lg font-semibold text-foreground">
                {feature.title}
              </h3>
              <p className="text-sm leading-relaxed text-muted-foreground">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
