import { AlertCircle } from "lucide-react";

export function CrisisBanner() {
  return (
    <section className="px-4 py-4">
      <div className="max-w-2xl mx-auto">
        <div className="rounded-2xl bg-red-950/30 border border-red-900/50 p-5">
          <div className="flex gap-4">
            <div className="flex-shrink-0">
              <div className="w-10 h-10 rounded-full bg-red-900/50 flex items-center justify-center">
                <AlertCircle className="h-5 w-5 text-red-400" />
              </div>
            </div>
            <div>
              <h2 className="text-red-400 font-semibold text-lg mb-2">
                If you are in crisis or feel unsafe:
              </h2>
              <p className="text-foreground/80 text-base leading-relaxed">
                Call <span className="font-bold text-foreground">999</span> or go to{" "}
                <span className="font-bold text-foreground">A&E</span> immediately. You can also
                contact <span className="font-bold text-foreground">Samaritans (116 123)</span> or{" "}
                <span className="font-bold text-foreground">NHS 111</span> for urgent mental health
                support.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
