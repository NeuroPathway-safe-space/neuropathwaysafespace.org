"use client";

import { Card, CardContent } from "@/components/ui/card";
import { TrendingUp, Calendar, Target, Lightbulb } from "lucide-react";

export function PatternRecognitionSection() {
  return (
    <section className="px-4 py-12 bg-card/30">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-10">
          <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
            Understanding <span className="text-amber-500">Pattern Recognition</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Learn how identifying patterns strengthens your EHCP evidence
          </p>
        </div>

        {/* What is Pattern Recognition */}
        <Card className="bg-background border-border mb-8">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-amber-500/10 flex items-center justify-center flex-shrink-0">
                <Lightbulb className="h-6 w-6 text-amber-500" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  What is Pattern Recognition?
                </h3>
                <p className="text-muted-foreground mb-4">
                  Pattern recognition means identifying <span className="text-foreground font-medium">recurring behaviours</span>, 
                  their <span className="text-foreground font-medium">triggers</span>, and 
                  how they <span className="text-foreground font-medium">change over time</span>. 
                  Instead of scattered notes, you build a clear picture of needs.
                </p>
                <p className="text-sm text-cyan-400">
                  Local authorities often ask: &quot;What evidence shows this is a persistent need?&quot; Patterns answer that.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Key Pattern Types */}
        <h3 className="text-lg font-semibold text-foreground mb-4 text-center">
          What NeuroPathway Tracks
        </h3>
        
        <div className="grid gap-4 md:grid-cols-3 mb-8">
          <Card className="bg-background border-border">
            <CardContent className="p-5 text-center">
              <div className="w-10 h-10 rounded-lg bg-cyan-400/10 flex items-center justify-center mx-auto mb-3">
                <Calendar className="h-5 w-5 text-cyan-400" />
              </div>
              <h4 className="font-semibold text-foreground mb-2">Frequency</h4>
              <p className="text-sm text-muted-foreground">
                How often behaviours occur - daily, weekly, in specific situations
              </p>
            </CardContent>
          </Card>

          <Card className="bg-background border-border">
            <CardContent className="p-5 text-center">
              <div className="w-10 h-10 rounded-lg bg-emerald-400/10 flex items-center justify-center mx-auto mb-3">
                <Target className="h-5 w-5 text-emerald-400" />
              </div>
              <h4 className="font-semibold text-foreground mb-2">Triggers</h4>
              <p className="text-sm text-muted-foreground">
                What causes behaviours - transitions, sensory input, social situations
              </p>
            </CardContent>
          </Card>

          <Card className="bg-background border-border">
            <CardContent className="p-5 text-center">
              <div className="w-10 h-10 rounded-lg bg-amber-400/10 flex items-center justify-center mx-auto mb-3">
                <TrendingUp className="h-5 w-5 text-amber-400" />
              </div>
              <h4 className="font-semibold text-foreground mb-2">Changes Over Time</h4>
              <p className="text-sm text-muted-foreground">
                Whether needs are stable, improving, or getting more complex
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Example Insight */}
        <Card className="bg-gradient-to-br from-cyan-400/5 to-amber-500/5 border-cyan-400/20">
          <CardContent className="p-6">
            <p className="text-sm text-muted-foreground mb-2">Example insight from pattern data:</p>
            <blockquote className="text-foreground italic border-l-2 border-amber-500 pl-4">
              &quot;Emotional dysregulation observed 12 times over 6 weeks during unstructured activities.&quot;
            </blockquote>
            <p className="text-sm text-cyan-400 mt-3">
              This type of evidence is far stronger than &quot;child struggles with emotions&quot;.
            </p>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
