"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Play, Pause, RotateCcw, Waves } from "lucide-react"

export function InteractiveDemo() {
  const [isRunning, setIsRunning] = useState(false)
  const [sensitivity, setSensitivity] = useState([50])
  const [dualMode, setDualMode] = useState(true)
  const [waveData, setWaveData] = useState<number[]>([])

  useEffect(() => {
    if (!isRunning) return

    const interval = setInterval(() => {
      setWaveData((prev) => {
        const newValue = 
          50 + 
          Math.sin(Date.now() / 200) * 20 * (sensitivity[0] / 50) +
          Math.random() * 10 * (sensitivity[0] / 50)
        const newData = [...prev, newValue].slice(-50)
        return newData
      })
    }, 50)

    return () => clearInterval(interval)
  }, [isRunning, sensitivity])

  const handleReset = () => {
    setIsRunning(false)
    setWaveData([])
    setSensitivity([50])
  }

  return (
    <section id="interactive" className="px-4 py-16 md:py-24">
      <div className="mx-auto max-w-6xl">
        <div className="mb-12 text-center">
          <Badge variant="secondary" className="mb-4">
            Try It Yourself
          </Badge>
          <h2 className="mb-4 text-3xl font-bold text-foreground md:text-4xl">
            Interactive Neural Simulation
          </h2>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            Experience a simplified demonstration of how NeuroPathway processes
            and visualizes neural signals in real-time.
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Controls */}
          <Card className="border-border bg-card lg:col-span-1">
            <CardHeader>
              <CardTitle className="text-lg">Controls</CardTitle>
              <CardDescription>
                Adjust parameters to see how the system responds
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Play/Pause */}
              <div className="flex gap-2">
                <Button
                  onClick={() => setIsRunning(!isRunning)}
                  className="flex-1 gap-2"
                >
                  {isRunning ? (
                    <>
                      <Pause className="h-4 w-4" /> Pause
                    </>
                  ) : (
                    <>
                      <Play className="h-4 w-4" /> Start
                    </>
                  )}
                </Button>
                <Button variant="outline" onClick={handleReset}>
                  <RotateCcw className="h-4 w-4" />
                </Button>
              </div>

              {/* Sensitivity */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label>Sensitivity</Label>
                  <span className="text-sm text-muted-foreground">
                    {sensitivity[0]}%
                  </span>
                </div>
                <Slider
                  value={sensitivity}
                  onValueChange={setSensitivity}
                  max={100}
                  step={1}
                />
              </div>

              {/* Dual Mode Toggle */}
              <div className="flex items-center justify-between">
                <div>
                  <Label>Dual Mode</Label>
                  <p className="text-xs text-muted-foreground">
                    Enable 2-in-1 processing
                  </p>
                </div>
                <Switch checked={dualMode} onCheckedChange={setDualMode} />
              </div>

              {/* Status */}
              <div className="rounded-lg border border-border bg-secondary/30 p-4">
                <div className="mb-2 flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Status</span>
                  <Badge
                    variant={isRunning ? "default" : "secondary"}
                    className={isRunning ? "bg-primary" : ""}
                  >
                    {isRunning ? "Active" : "Idle"}
                  </Badge>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Mode</span>
                  <span className="text-foreground">
                    {dualMode ? "Dual Processing" : "Single Channel"}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Visualization */}
          <Card className="border-border bg-card lg:col-span-2">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Waves className="h-5 w-5 text-primary" />
                    Signal Visualization
                  </CardTitle>
                  <CardDescription>
                    Real-time neural wave pattern
                  </CardDescription>
                </div>
                {isRunning && (
                  <div className="flex items-center gap-2">
                    <span className="h-2 w-2 animate-pulse rounded-full bg-primary" />
                    <span className="text-sm text-muted-foreground">
                      Recording
                    </span>
                  </div>
                )}
              </div>
            </CardHeader>
            <CardContent>
              <div className="relative aspect-[2/1] w-full overflow-hidden rounded-lg bg-secondary/30">
                {/* Grid lines */}
                <svg className="absolute inset-0 h-full w-full">
                  {[...Array(5)].map((_, i) => (
                    <line
                      key={`h-${i}`}
                      x1="0"
                      y1={`${(i + 1) * 20}%`}
                      x2="100%"
                      y2={`${(i + 1) * 20}%`}
                      stroke="currentColor"
                      strokeWidth="0.5"
                      className="text-border"
                    />
                  ))}
                  {[...Array(10)].map((_, i) => (
                    <line
                      key={`v-${i}`}
                      x1={`${(i + 1) * 10}%`}
                      y1="0"
                      x2={`${(i + 1) * 10}%`}
                      y2="100%"
                      stroke="currentColor"
                      strokeWidth="0.5"
                      className="text-border"
                    />
                  ))}
                </svg>

                {/* Wave */}
                {waveData.length > 1 && (
                  <svg className="absolute inset-0 h-full w-full">
                    <polyline
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      className="text-primary"
                      points={waveData
                        .map(
                          (value, index) =>
                            `${(index / 50) * 100}%,${100 - value}%`
                        )
                        .join(" ")}
                    />
                    {dualMode && (
                      <polyline
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        className="text-chart-2 opacity-60"
                        points={waveData
                          .map(
                            (value, index) =>
                              `${(index / 50) * 100}%,${100 - (value * 0.8 + 10)}%`
                          )
                          .join(" ")}
                      />
                    )}
                  </svg>
                )}

                {/* Empty state */}
                {waveData.length === 0 && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <p className="text-muted-foreground">
                      Press Start to begin simulation
                    </p>
                  </div>
                )}
              </div>

              {/* Metrics */}
              {waveData.length > 0 && (
                <div className="mt-4 grid grid-cols-3 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">
                      {Math.round(waveData[waveData.length - 1] || 0)}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Current Amplitude
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-foreground">
                      {Math.round(
                        waveData.reduce((a, b) => a + b, 0) / waveData.length
                      )}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Average Level
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-foreground">
                      {waveData.length}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Data Points
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
