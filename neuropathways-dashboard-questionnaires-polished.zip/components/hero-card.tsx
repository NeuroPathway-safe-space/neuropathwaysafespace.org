import Image from "next/image";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

export function HeroCard() {
  return (
    <section className="px-4 py-8">
      <div className="max-w-2xl mx-auto">
        <div className="relative rounded-3xl bg-gradient-to-b from-[#0f2847] to-[#0a1c35] p-8 md:p-12 shadow-2xl border border-[#1a3a5c]/50">
          {/* Logo */}
          <div className="flex justify-center mb-8">
            <div className="relative w-48 h-48 md:w-56 md:h-56">
              <Image
                src="/logo.jpeg"
                alt="NeuroPathway Safe Space"
                fill
                className="object-contain"
                priority
              />
            </div>
          </div>

          {/* Main heading */}
          <h1 className="text-center text-xl md:text-2xl text-foreground/90 font-light leading-relaxed mb-6">
            A digital observation system designed to help{" "}
            <span className="text-foreground font-normal">schools</span> gather clear evidence for{" "}
            <span className="text-foreground font-normal">EHCP applications</span> by tracking everyday behaviours and patterns over time.
          </h1>

          {/* Tagline */}
          <p className="text-center text-lg md:text-xl font-medium mb-8">
            <span className="text-amber-500">Simple. Real problem.</span>
            <br />
            <span className="text-amber-500">Easy for schools to understand.</span>
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link href="/auth/sign-up">
              <Button size="lg" className="w-full sm:w-auto bg-amber-500 hover:bg-amber-600 text-background font-semibold rounded-full px-8">
                Get Started Free
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
            <Link href="/auth/login">
              <Button size="lg" variant="outline" className="w-full sm:w-auto rounded-full px-8 border-foreground/20 hover:bg-foreground/5">
                Sign In
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
