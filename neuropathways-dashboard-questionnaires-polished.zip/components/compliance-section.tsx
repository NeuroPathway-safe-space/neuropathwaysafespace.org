"use client";

import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield, Lock, FileCheck, Building2, GraduationCap, Heart, ArrowRight } from "lucide-react";
import Link from "next/link";

export function ComplianceSection() {
  const frameworks = [
    {
      icon: Shield,
      title: "GDPR Compliant",
      description: "Full UK GDPR and Data Protection Act 2018 compliance. Your data is encrypted, secure, and you control who sees it.",
      color: "cyan",
    },
    {
      icon: GraduationCap,
      title: "Education Frameworks",
      description: "Aligned with SEND Code of Practice 2015, Ofsted requirements, and DfE guidance on supporting pupils with SEND.",
      color: "amber",
    },
    {
      icon: Heart,
      title: "NHS & Health Standards",
      description: "Compatible with NHS Digital standards, CAMHS referral requirements, and multi-agency working protocols.",
      color: "emerald",
    },
    {
      icon: Building2,
      title: "Local Authority Ready",
      description: "Reports formatted for EHCP applications, annual reviews, and tribunal evidence requirements.",
      color: "purple",
    },
  ];

  const gdprRights = [
    "Right to access your data",
    "Right to be forgotten",
    "Right to data portability",
    "Right to rectification",
    "Explicit consent required",
    "Clear data retention policies",
  ];

  return (
    <section id="compliance" className="px-4 py-12 md:py-16 bg-card/50 scroll-mt-20">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 mb-4">
            <Lock className="h-4 w-4 text-emerald-500" />
            <span className="text-sm font-medium text-emerald-500">Secure & Compliant</span>
          </div>
          <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
            Built for UK Compliance
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            NeuroPathway meets all UK data protection and education framework requirements
          </p>
        </div>

        {/* Frameworks Grid */}
        <div className="grid gap-4 md:grid-cols-2 mb-10">
          {frameworks.map((framework) => (
            <Card key={framework.title} className="bg-background border-border">
              <CardContent className="p-5">
                <div className="flex items-start gap-4">
                  <div className={`w-10 h-10 rounded-lg bg-${framework.color}-400/10 flex items-center justify-center flex-shrink-0`}>
                    <framework.icon className={`h-5 w-5 text-${framework.color}-400`} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground mb-1">
                      {framework.title}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {framework.description}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* GDPR Rights */}
        <Card className="bg-gradient-to-br from-cyan-400/5 to-emerald-500/5 border-cyan-400/20">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <FileCheck className="h-5 w-5 text-cyan-400" />
              <h3 className="text-lg font-semibold text-foreground">Your GDPR Rights</h3>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {gdprRights.map((right) => (
                <div key={right} className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  <span className="text-sm text-muted-foreground">{right}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Additional Policies */}
        <div className="mt-8 grid gap-4 md:grid-cols-3">
          <Card className="bg-background border-border">
            <CardContent className="p-4 text-center">
              <h4 className="font-medium text-foreground text-sm mb-1">Data Encryption</h4>
              <p className="text-xs text-muted-foreground">AES-256 encryption at rest and in transit</p>
            </CardContent>
          </Card>
          <Card className="bg-background border-border">
            <CardContent className="p-4 text-center">
              <h4 className="font-medium text-foreground text-sm mb-1">UK Data Residency</h4>
              <p className="text-xs text-muted-foreground">All data stored on UK-based servers</p>
            </CardContent>
          </Card>
          <Card className="bg-background border-border">
            <CardContent className="p-4 text-center">
              <h4 className="font-medium text-foreground text-sm mb-1">Regular Audits</h4>
              <p className="text-xs text-muted-foreground">Independent security assessments</p>
            </CardContent>
          </Card>
        </div>

        {/* CTA */}
        <div className="mt-10 text-center">
          <Link href="/auth/sign-up">
            <Button size="lg" className="gap-2 bg-emerald-500 hover:bg-emerald-600 text-background">
              Get Started Securely
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
