"use client";

import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Shield, Lock, FileCheck, AlertTriangle, Users, Eye, Trash2 } from "lucide-react";

interface SafeguardingPolicyProps {
  onAccept?: () => void;
  showAcceptButton?: boolean;
  compact?: boolean;
}

const policies = [
  {
    icon: Shield,
    title: "Data Protection",
    description: "All data is processed in accordance with UK GDPR and the Data Protection Act 2018. We are committed to protecting the privacy and security of children's information.",
  },
  {
    icon: Lock,
    title: "Secure Storage",
    description: "Data is encrypted at rest and in transit. Access is restricted to authorised users only. All data is stored on secure UK/EU servers.",
  },
  {
    icon: Eye,
    title: "Access Control",
    description: "Only you can access your observations. Schools and parents maintain separate accounts. Data is never shared without explicit consent.",
  },
  {
    icon: Users,
    title: "Safeguarding Responsibility",
    description: "This tool supports evidence collection but does not replace safeguarding procedures. Concerns must be reported to your Designated Safeguarding Lead (DSL) or local authority.",
  },
  {
    icon: FileCheck,
    title: "Data Minimisation",
    description: "We only collect information necessary for EHCP evidence. No unnecessary personal data is stored. You control what information you record.",
  },
  {
    icon: Trash2,
    title: "Data Retention & Deletion",
    description: "You can delete your data at any time. Upon account deletion, all associated data is permanently removed within 30 days.",
  },
];

export function SafeguardingPolicy({ onAccept, showAcceptButton = false, compact = false }: SafeguardingPolicyProps) {
  const [acknowledged, setAcknowledged] = useState({
    gdpr: false,
    safeguarding: false,
    responsibility: false,
  });

  const allAcknowledged = Object.values(acknowledged).every(Boolean);

  if (compact) {
    return (
      <Card className="bg-emerald-500/10 border-emerald-500/30">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Shield className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" />
            <div className="space-y-2">
              <p className="text-sm text-foreground font-medium">Safeguarding & GDPR Compliant</p>
              <p className="text-xs text-muted-foreground">
                Your data is protected under UK GDPR. We follow safeguarding best practices. 
                Report concerns to your Designated Safeguarding Lead.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-card border-border">
      <CardContent className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-emerald-500/10 flex items-center justify-center">
            <Shield className="h-6 w-6 text-emerald-500" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">Safeguarding & Data Protection Policy</h3>
            <p className="text-sm text-muted-foreground">How we protect children and their data</p>
          </div>
        </div>

        {/* Policies Grid */}
        <div className="grid gap-4 md:grid-cols-2">
          {policies.map((policy) => {
            const Icon = policy.icon;
            return (
              <div key={policy.title} className="p-4 bg-secondary/50 rounded-lg space-y-2">
                <div className="flex items-center gap-2">
                  <Icon className="h-4 w-4 text-primary" />
                  <h4 className="font-medium text-foreground text-sm">{policy.title}</h4>
                </div>
                <p className="text-xs text-muted-foreground">{policy.description}</p>
              </div>
            );
          })}
        </div>

        {/* Safeguarding Notice */}
        <div className="p-4 bg-amber-500/10 border border-amber-500/30 rounded-lg">
          <div className="flex items-start gap-3">
            <AlertTriangle className="h-5 w-5 text-amber-500 shrink-0 mt-0.5" />
            <div className="space-y-2">
              <p className="font-medium text-amber-400 text-sm">Important Safeguarding Reminder</p>
              <p className="text-xs text-muted-foreground">
                If you identify a safeguarding concern through this observation tool, you MUST follow your 
                organisation&apos;s safeguarding procedures immediately. Report to your Designated Safeguarding 
                Lead (DSL) or contact your local authority safeguarding team. Do not rely solely on recording 
                concerns in this system.
              </p>
              <p className="text-xs text-amber-400">
                Emergency: 999 | NSPCC: 0808 800 5000 | Childline: 0800 1111
              </p>
            </div>
          </div>
        </div>

        {/* Acceptance */}
        {showAcceptButton && (
          <div className="space-y-4 pt-4 border-t border-border">
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <Checkbox
                  id="gdpr"
                  checked={acknowledged.gdpr}
                  onCheckedChange={(checked) => setAcknowledged(prev => ({ ...prev, gdpr: checked as boolean }))}
                />
                <label htmlFor="gdpr" className="text-sm text-muted-foreground cursor-pointer">
                  I understand that my data will be processed in accordance with UK GDPR and I consent to the 
                  collection and storage of observation data for EHCP evidence purposes.
                </label>
              </div>

              <div className="flex items-start gap-3">
                <Checkbox
                  id="safeguarding"
                  checked={acknowledged.safeguarding}
                  onCheckedChange={(checked) => setAcknowledged(prev => ({ ...prev, safeguarding: checked as boolean }))}
                />
                <label htmlFor="safeguarding" className="text-sm text-muted-foreground cursor-pointer">
                  I understand that safeguarding concerns must be reported through proper channels (DSL, local 
                  authority) and not just recorded in this system.
                </label>
              </div>

              <div className="flex items-start gap-3">
                <Checkbox
                  id="responsibility"
                  checked={acknowledged.responsibility}
                  onCheckedChange={(checked) => setAcknowledged(prev => ({ ...prev, responsibility: checked as boolean }))}
                />
                <label htmlFor="responsibility" className="text-sm text-muted-foreground cursor-pointer">
                  I take responsibility for the accuracy of observations I record and will use this tool 
                  ethically and in the best interests of the children I observe.
                </label>
              </div>
            </div>

            <Button 
              onClick={onAccept} 
              disabled={!allAcknowledged} 
              className="w-full"
            >
              I Accept - Continue
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
