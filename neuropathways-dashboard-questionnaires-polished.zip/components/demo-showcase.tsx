"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Brain, Activity, Cpu, Network } from "lucide-react"

export function DemoShowcase() {
  const [activeDemo, setActiveDemo] = useState("cognitive")

  return (
    <section id="demos" className="px-4 py-16 md:py-24">
      <div className="mx-auto max-w-6xl">
        <div className="mb-12 text-center">
          <Badge variant="secondary" className="mb-4">
            Interactive Demos
          </Badge>
          <h2 className="mb-4 text-3xl font-bold text-foreground md:text-4xl">
            See the 2-in-1 Ecosystem in Action
          </h2>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            Explore both systems working independently and together. Toggle
            between modes to see how NeuroPathway adapts to your needs.
          </p>
        </div>

        <Tabs value={activeDemo} onValueChange={setActiveDemo} className="w-full">
          <TabsList className="mb-8 grid w-full grid-cols-2 lg:w-auto lg:inline-flex">
            <TabsTrigger value="cognitive" className="gap-2">
              <Brain className="h-4 w-4" />
              Cognitive Mapping
            </TabsTrigger>
            <TabsTrigger value="neural" className="gap-2">
              <Network className="h-4 w-4" />
              Neural Processing
            </TabsTrigger>
          </TabsList>

          <TabsContent value="cognitive" className="mt-0">
            <Card className="border-border bg-card">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Brain className="h-5 w-5 text-primary" />
                      Cognitive Mapping Engine
                    </CardTitle>
                    <CardDescription>
                      Real-time thought pattern visualization and analysis
                    </CardDescription>
                  </div>
                  <Badge className="bg-primary/20 text-primary">Live</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <CognitiveMappingDemo />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="neural" className="mt-0">
            <Card className="border-border bg-card">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Cpu className="h-5 w-5 text-primary" />
                      Neural Processing Unit
                    </CardTitle>
                    <CardDescription>
                      Advanced signal processing and pattern recognition
                    </CardDescription>
                  </div>
                  <Badge className="bg-primary/20 text-primary">Active</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <NeuralProcessingDemo />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  )
}

function CognitiveMappingDemo() {
  const [nodes] = useState([
    { id: 1, label: "Memory", x: 20, y: 30, size: 60 },
    { id: 2, label: "Logic", x: 50, y: 20, size: 70 },
    { id: 3, label: "Emotion", x: 80, y: 35, size: 55 },
    { id: 4, label: "Creativity", x: 30, y: 60, size: 65 },
    { id: 5, label: "Focus", x: 70, y: 65, size: 75 },
    { id: 6, label: "Intuition", x: 50, y: 80, size: 50 },
  ])

  const connections = [
    [1, 2], [2, 3], [1, 4], [3, 5], [4, 5], [4, 6], [5, 6], [2, 5]
  ]

  return (
    <div className="relative aspect-video w-full overflow-hidden rounded-lg bg-secondary/30">
      <svg className="absolute inset-0 h-full w-full">
        {/* Connections */}
        {connections.map(([from, to], i) => {
          const fromNode = nodes.find(n => n.id === from)!
          const toNode = nodes.find(n => n.id === to)!
          return (
            <line
              key={i}
              x1={`${fromNode.x}%`}
              y1={`${fromNode.y}%`}
              x2={`${toNode.x}%`}
              y2={`${toNode.y}%`}
              stroke="currentColor"
              strokeWidth="1"
              className="text-primary/30 animate-pulse"
            />
          )
        })}
      </svg>
      
      {/* Nodes */}
      {nodes.map((node) => (
        <div
          key={node.id}
          className="absolute flex -translate-x-1/2 -translate-y-1/2 cursor-pointer flex-col items-center transition-transform hover:scale-110"
          style={{ left: `${node.x}%`, top: `${node.y}%` }}
        >
          <div
            className="flex items-center justify-center rounded-full border-2 border-primary bg-primary/20 text-xs font-medium text-foreground backdrop-blur-sm transition-colors hover:bg-primary/30"
            style={{ width: node.size, height: node.size }}
          >
            {node.label}
          </div>
        </div>
      ))}

      {/* Activity indicator */}
      <div className="absolute bottom-4 left-4 flex items-center gap-2 rounded-full bg-card/80 px-3 py-1.5 text-sm backdrop-blur-sm">
        <Activity className="h-4 w-4 animate-pulse text-primary" />
        <span className="text-foreground">Mapping active regions...</span>
      </div>
    </div>
  )
}

function NeuralProcessingDemo() {
  const [signals] = useState([
    { id: 1, frequency: "Alpha", value: 72, color: "bg-chart-1" },
    { id: 2, frequency: "Beta", value: 85, color: "bg-chart-2" },
    { id: 3, frequency: "Theta", value: 45, color: "bg-chart-3" },
    { id: 4, frequency: "Delta", value: 30, color: "bg-chart-4" },
    { id: 5, frequency: "Gamma", value: 92, color: "bg-chart-5" },
  ])

  return (
    <div className="space-y-6">
      {/* Signal bars */}
      <div className="space-y-4">
        {signals.map((signal) => (
          <div key={signal.id} className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-foreground">{signal.frequency} Waves</span>
              <span className="text-muted-foreground">{signal.value}%</span>
            </div>
            <div className="h-3 w-full overflow-hidden rounded-full bg-secondary">
              <div
                className={`h-full rounded-full ${signal.color} transition-all duration-1000`}
                style={{ width: `${signal.value}%` }}
              />
            </div>
          </div>
        ))}
      </div>

      {/* Processing status */}
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        {[
          { label: "Latency", value: "1.2ms" },
          { label: "Throughput", value: "1.2GB/s" },
          { label: "Accuracy", value: "99.8%" },
          { label: "Channels", value: "256" },
        ].map((stat) => (
          <div
            key={stat.label}
            className="rounded-lg border border-border bg-secondary/30 p-3 text-center"
          >
            <div className="text-lg font-semibold text-primary">{stat.value}</div>
            <div className="text-xs text-muted-foreground">{stat.label}</div>
          </div>
        ))}
      </div>
    </div>
  )
}
