"use client";

import { TrendingUp, FileText, ListOrdered, Clock, Users, CheckCircle, XCircle, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export function SolutionSection() {
  return (
    <section id="how-it-works" className="px-4 py-12 bg-card/50 scroll-mt-20">
      <div className="max-w-4xl mx-auto">
        {/* Main Value Prop */}
        <h2 className="text-2xl md:text-3xl font-bold text-center mb-4">
          <span className="text-amber-500">How It Works</span>
        </h2>
        <p className="text-center text-muted-foreground text-lg mb-10 max-w-2xl mx-auto">
          Pattern recognition that creates EHCP-ready evidence
        </p>

        {/* Core Flow - Simplified */}
        <div className="grid gap-6 md:grid-cols-3 mb-12">
          {/* Step 1 */}
          <div className="rounded-2xl bg-background border border-border p-5 text-center">
            <div className="w-10 h-10 rounded-full bg-amber-500 flex items-center justify-center text-background font-bold mx-auto mb-4">
              1
            </div>
            <div className="w-12 h-12 rounded-xl bg-cyan-400/10 flex items-center justify-center mx-auto mb-3">
              <ListOrdered className="h-6 w-6 text-cyan-400" />
            </div>
            <h3 className="font-semibold text-foreground mb-2">Select Category</h3>
            <p className="text-sm text-muted-foreground">
              Choose from attention, emotional regulation, sensory, social, or learning
            </p>
          </div>

          {/* Step 2 */}
          <div className="rounded-2xl bg-background border border-border p-5 text-center">
            <div className="w-10 h-10 rounded-full bg-amber-500 flex items-center justify-center text-background font-bold mx-auto mb-4">
              2
            </div>
            <div className="w-12 h-12 rounded-xl bg-emerald-400/10 flex items-center justify-center mx-auto mb-3">
              <TrendingUp className="h-6 w-6 text-emerald-400" />
            </div>
            <h3 className="font-semibold text-foreground mb-2">Pattern Recognition</h3>
            <p className="text-sm text-muted-foreground">
              System tracks frequency, triggers, and changes over time automatically
            </p>
          </div>

          {/* Step 3 */}
          <div className="rounded-2xl bg-background border border-border p-5 text-center">
            <div className="w-10 h-10 rounded-full bg-amber-500 flex items-center justify-center text-background font-bold mx-auto mb-4">
              3
            </div>
            <div className="w-12 h-12 rounded-xl bg-amber-400/10 flex items-center justify-center mx-auto mb-3">
              <FileText className="h-6 w-6 text-amber-400" />
            </div>
            <h3 className="font-semibold text-foreground mb-2">EHCP-Ready Report</h3>
            <p className="text-sm text-muted-foreground">
              Generates structured evidence report for applications and reviews
            </p>
          </div>
        </div>

        {/* Intervention Tracking */}
        <div className="rounded-2xl bg-background border border-border p-6 mb-8">
          <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
            Track What Works & What Doesn&apos;t
          </h3>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center flex-shrink-0">
                <CheckCircle className="h-4 w-4 text-emerald-500" />
              </div>
              <div>
                <p className="font-medium text-foreground text-sm">Successful Interventions</p>
                <p className="text-xs text-muted-foreground">Record strategies that help and when they work best</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-red-500/10 flex items-center justify-center flex-shrink-0">
                <XCircle className="h-4 w-4 text-red-500" />
              </div>
              <div>
                <p className="font-medium text-foreground text-sm">Unsuccessful Approaches</p>
                <p className="text-xs text-muted-foreground">Document what hasn&apos;t worked to avoid repeating</p>
              </div>
            </div>
          </div>
          <p className="text-sm text-muted-foreground mt-4 pt-4 border-t border-border">
            This evidence shows local authorities you&apos;ve tried multiple approaches - a key requirement for EHCP applications.
          </p>
        </div>

        {/* Needs-Based Priority - Key Differentiator */}
        <div className="rounded-2xl bg-gradient-to-br from-cyan-400/10 to-amber-500/10 border border-cyan-400/30 p-6 mb-12">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-cyan-400/20 flex items-center justify-center flex-shrink-0">
              <Clock className="h-6 w-6 text-cyan-400" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-foreground mb-2">
                Needs-Based Priority, Not First Come First Served
              </h3>
              <p className="text-muted-foreground mb-3">
                Forms are created based on category. The system prioritises cases by <span className="text-foreground font-medium">level of need</span>, not order of submission.
              </p>
              <p className="text-sm text-cyan-400">
                Children with the most urgent needs are seen first.
              </p>
            </div>
          </div>
        </div>

        {/* Who It's For - Unified */}
        <h3 className="text-xl font-semibold text-center text-foreground mb-6">
          For Schools <span className="text-muted-foreground">&</span> Parents
        </h3>
        
        <div className="grid gap-4 md:grid-cols-2">
          <div className="rounded-xl bg-background border border-border p-5">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center">
                <Users className="h-5 w-5 text-amber-500" />
              </div>
              <h4 className="font-semibold text-foreground">Schools & SENCOs</h4>
            </div>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>Quick observation logging (under 10 seconds)</li>
              <li>Consistent evidence building across staff</li>
              <li>One-click reports for SEND reviews</li>
            </ul>
          </div>

          <div className="rounded-xl bg-background border border-border p-5">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-lg bg-cyan-400/10 flex items-center justify-center">
                <Users className="h-5 w-5 text-cyan-400" />
              </div>
              <h4 className="font-semibold text-foreground">Parents & Individuals</h4>
            </div>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>Document daily observations at home</li>
              <li>Build evidence for tribunals and appeals</li>
              <li>Share organised data with professionals</li>
            </ul>
          </div>
        </div>

        {/* CTA */}
        <div className="mt-10 text-center">
          <Link href="/auth/sign-up">
            <Button size="lg" className="gap-2 bg-amber-500 hover:bg-amber-600 text-background">
              Start Building Evidence
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
