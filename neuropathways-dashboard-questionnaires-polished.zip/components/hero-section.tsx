"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Brain, Zap, ArrowRight, Menu, X } from "lucide-react"
import Link from "next/link"

export function HeroSection() {
  const [activeNode, setActiveNode] = useState(0)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
    setMobileMenuOpen(false)
  }

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveNode((prev) => (prev + 1) % 6)
    }, 800)
    return () => clearInterval(interval)
  }, [])

  const nodes = [
    { x: 50, y: 30 },
    { x: 25, y: 50 },
    { x: 75, y: 50 },
    { x: 35, y: 70 },
    { x: 65, y: 70 },
    { x: 50, y: 85 },
  ]

  return (
    <section className="relative overflow-hidden px-4 py-16 md:py-24">
      {/* Animated background */}
      <div className="absolute inset-0 overflow-hidden">
        <svg
          className="absolute h-full w-full opacity-20"
          viewBox="0 0 100 100"
          preserveAspectRatio="none"
        >
          {/* Neural network lines */}
          {nodes.map((node, i) =>
            nodes.slice(i + 1).map((target, j) => (
              <line
                key={`${i}-${j}`}
                x1={`${node.x}%`}
                y1={`${node.y}%`}
                x2={`${target.x}%`}
                y2={`${target.y}%`}
                stroke="currentColor"
                strokeWidth="0.1"
                className={`text-primary transition-opacity duration-500 ${
                  activeNode === i || activeNode === i + j + 1
                    ? "opacity-100"
                    : "opacity-30"
                }`}
              />
            ))
          )}
          {/* Nodes */}
          {nodes.map((node, i) => (
            <circle
              key={i}
              cx={`${node.x}%`}
              cy={`${node.y}%`}
              r="1"
              className={`transition-all duration-300 ${
                activeNode === i
                  ? "fill-primary"
                  : "fill-muted-foreground"
              }`}
            />
          ))}
        </svg>
      </div>

      <div className="relative mx-auto max-w-6xl">
        {/* Header */}
        <nav className="mb-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Brain className="h-8 w-8 text-primary" />
            <span className="text-xl font-semibold text-foreground">
              NeuroPathway
            </span>
          </div>
          <div className="hidden items-center gap-6 md:flex">
            <button onClick={() => scrollToSection("demos")} className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Demos
            </button>
            <button onClick={() => scrollToSection("features")} className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Features
            </button>
            <button onClick={() => scrollToSection("interactive")} className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Try It
            </button>
            <Link href="/auth/sign-up">
              <Button size="sm">Get Started</Button>
            </Link>
          </div>
          <Button size="sm" className="md:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            {mobileMenuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </Button>
        </nav>

        {/* Hero content */}
        <div className="text-center">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-border bg-secondary/50 px-4 py-1.5 text-sm text-muted-foreground">
            <Zap className="h-4 w-4 text-primary" />
            2-in-1 Neural Ecosystem
          </div>
          <h1 className="mb-6 text-balance text-4xl font-bold tracking-tight text-foreground md:text-6xl lg:text-7xl">
            One Platform.
            <br />
            <span className="text-primary">Two Powerful Systems.</span>
          </h1>
          <p className="mx-auto mb-8 max-w-2xl text-pretty text-lg text-muted-foreground md:text-xl">
            NeuroPathway combines cognitive mapping and neural processing into a
            unified ecosystem. Experience the future of brain-computer
            interfaces.
          </p>
          <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Button size="lg" className="min-w-44 gap-2" onClick={() => scrollToSection("demos")}>
              Watch Demo <ArrowRight className="h-4 w-4" />
            </Button>
            <Button size="lg" variant="outline" className="min-w-44 bg-transparent" onClick={() => scrollToSection("features")}>
              Explore Features
            </Button>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="fixed inset-0 z-50 bg-background/95 backdrop-blur-md pt-20 md:hidden">
              <nav className="flex flex-col items-center gap-6 p-6">
                <button onClick={() => scrollToSection("demos")} className="text-lg text-foreground hover:text-primary transition-colors">
                  Demos
                </button>
                <button onClick={() => scrollToSection("features")} className="text-lg text-foreground hover:text-primary transition-colors">
                  Features
                </button>
                <button onClick={() => scrollToSection("interactive")} className="text-lg text-foreground hover:text-primary transition-colors">
                  Try It
                </button>
                <Link href="/auth/sign-up" onClick={() => setMobileMenuOpen(false)}>
                  <Button size="lg" className="mt-4">Get Started</Button>
                </Link>
              </nav>
            </div>
          )}
        </div>

        {/* Stats */}
        <div className="mt-16 grid grid-cols-2 gap-4 md:grid-cols-4">
          {[
            { value: "99.7%", label: "Accuracy Rate" },
            { value: "2ms", label: "Response Time" },
            { value: "10M+", label: "Neural Patterns" },
            { value: "24/7", label: "Real-time Processing" },
          ].map((stat) => (
            <div
              key={stat.label}
              className="rounded-xl border border-border bg-card/50 p-4 text-center backdrop-blur-sm"
            >
              <div className="text-2xl font-bold text-primary md:text-3xl">
                {stat.value}
              </div>
              <div className="text-sm text-muted-foreground">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
