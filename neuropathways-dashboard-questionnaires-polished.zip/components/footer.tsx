"use client";

import Image from "next/image";
import Link from "next/link";
import { Heart, Phone, Shield, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Footer() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <footer className="border-t border-border bg-card/50">
      {/* Crisis Support Bar */}
      <div className="bg-amber-500/10 border-b border-amber-500/30">
        <div className="max-w-4xl mx-auto px-4 py-3">
          <div className="flex flex-col sm:flex-row items-center justify-center gap-2 text-sm">
            <div className="flex items-center gap-2 text-amber-400">
              <AlertTriangle className="h-4 w-4" />
              <span className="font-medium">Need support?</span>
            </div>
            <div className="flex items-center gap-4 text-muted-foreground">
              <a href="tel:116123" className="flex items-center gap-1 hover:text-amber-400 transition-colors">
                <Phone className="h-3 w-3" />
                Samaritans: 116 123
              </a>
              <a href="tel:08001111" className="hover:text-amber-400 transition-colors">
                Childline: 0800 1111
              </a>
              <a href="tel:999" className="text-red-400 hover:text-red-300 transition-colors">
                Emergency: 999
              </a>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="flex flex-col items-center text-center">
          {/* Logo */}
          <Link href="/">
            <div className="relative w-24 h-24 mb-4">
              <Image
                src="/logo.jpeg"
                alt="NeuroPathway Safe Space"
                fill
                className="object-contain"
              />
            </div>
          </Link>

          <h3 className="text-xl font-semibold text-foreground mb-2">NeuroPathway Safe Space</h3>
          <p className="text-muted-foreground text-sm mb-6 max-w-md">
            A digital observation and evidence tool that helps schools and parents build strong EHCP applications.
          </p>

          <div className="flex flex-wrap justify-center gap-4 text-sm mb-8">
            <button 
              onClick={() => scrollToSection("how-it-works")}
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              How It Works
            </button>
            <button 
              onClick={() => scrollToSection("compliance")}
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              Compliance
            </button>
            <button 
              onClick={() => scrollToSection("why-it-works")}
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              Why It Works
            </button>
            <Link href="/auth/login" className="text-muted-foreground hover:text-foreground transition-colors">
              Sign In
            </Link>
            <Link href="/auth/sign-up" className="text-muted-foreground hover:text-foreground transition-colors">
              Register
            </Link>
            <Link href="/privacy-policy" className="text-muted-foreground hover:text-foreground transition-colors">
              Privacy & Safeguarding
            </Link>
          </div>

          <Link href="/auth/sign-up">
            <Button className="mb-8 bg-amber-500 hover:bg-amber-600 text-background rounded-full px-6">
              Get Started Free
            </Button>
          </Link>

          <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
            <span>Made with</span>
            <Heart className="h-4 w-4 text-red-400 fill-red-400" />
            <span>for young people</span>
          </div>

          <p className="text-xs text-muted-foreground mt-4">
            &copy; {new Date().getFullYear()} NeuroPathway Safe Space. All rights reserved.
          </p>

          {/* Compliance Badges */}
          <div className="flex flex-wrap items-center justify-center gap-4 mt-6 pt-6 border-t border-border">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Shield className="h-4 w-4 text-emerald-500" />
              <span>UK GDPR Compliant</span>
            </div>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Shield className="h-4 w-4 text-emerald-500" />
              <span>Safeguarding Aware</span>
            </div>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Shield className="h-4 w-4 text-emerald-500" />
              <span>Data Encrypted</span>
            </div>
          </div>

          {/* Disclaimer */}
          <p className="text-xs text-muted-foreground mt-4 max-w-lg text-center">
            This tool is for observation tracking only and does not provide medical advice, diagnosis, or treatment. 
            Report safeguarding concerns to your DSL or local authority immediately.
          </p>

          {/* Neurodiversity Directory Verified Badge */}
          <div className="mt-8 pt-6 border-t border-border">
            <a 
              href="https://theneurodiversitydirectory.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-block hover:opacity-80 transition-opacity"
            >
              <Image
                src="/neurodiversity-directory-verified.jpeg"
                alt="The Neurodiversity Directory - Verified"
                width={220}
                height={88}
                className="rounded-lg bg-white p-1"
              />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
