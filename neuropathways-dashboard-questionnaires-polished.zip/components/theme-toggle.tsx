'use client'

import * as React from 'react'
import { Moon, Sun } from 'lucide-react'
import { useTheme } from 'next-themes'
import { Button } from '@/components/ui/button'

export function ThemeToggle() {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = React.useState(false)

  React.useEffect(() => {
    setMounted(true)
  }, [])

  const toggle = () => setTheme(theme === 'dark' ? 'light' : 'dark')

  return (
    <Button
      variant="secondary"
      size="icon"
      onClick={toggle}
      aria-label="Toggle light and dark theme"
      className="rounded-full bg-secondary h-7 w-7"
    >
      {mounted && theme === 'dark' ? (
        <Sun className="h-3.5 w-3.5" />
      ) : (
        <Moon className="h-3.5 w-3.5" />
      )}
      <span className="sr-only">Toggle theme</span>
    </Button>
  )
}
