"use client";

import { FileX, Clock, Search, AlertTriangle, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export function ChallengeSection() {
  const challenges = [
    {
      icon: FileX,
      title: "Recording evidence consistently",
      description: "Staff struggle to document observations in a structured, usable format",
    },
    {
      icon: Search,
      title: "Organising observations",
      description: "Notes scattered across systems, making patterns hard to identify",
    },
    {
      icon: AlertTriangle,
      title: "Proving patterns to local authorities",
      description: "Councils need clear evidence that's difficult to compile manually",
    },
    {
      icon: Clock,
      title: "Time-consuming EHCP applications",
      description: "Teachers spend hours gathering evidence for each application",
    },
  ];

  return (
    <section className="px-4 py-12">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">
          <span className="text-cyan-400">The Challenge</span>
        </h2>
        <p className="text-center text-muted-foreground text-lg mb-10 max-w-2xl mx-auto">
          Schools struggle with EHCP evidence gathering. NeuroPathway solves exactly that.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {challenges.map((item, index) => (
            <div
              key={index}
              className="rounded-2xl bg-card border border-border p-6 hover:border-cyan-400/50 transition-colors"
            >
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-cyan-400/10 flex items-center justify-center flex-shrink-0">
                  <item.icon className="h-6 w-6 text-cyan-400" />
                </div>
                <div>
                  <p className="text-lg font-semibold text-foreground mb-1">{item.title}</p>
                  <p className="text-muted-foreground text-sm">{item.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-8 text-center">
          <p className="text-xl text-foreground font-medium mb-4">
            NeuroPathway becomes{" "}
            <span className="text-amber-500">a digital evidence builder for EHCPs</span>
          </p>
          <Link href="/auth/sign-up">
            <Button size="lg" variant="outline" className="gap-2 border-cyan-400 text-cyan-400 hover:bg-cyan-400/10">
              See How It Works
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
