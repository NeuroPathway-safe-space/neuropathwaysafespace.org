"use client";

import { CheckCircle, Building, FlaskConical, Coins, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export function WhyItWorks() {
  const benefits = [
    {
      icon: CheckCircle,
      title: "SENCOs understand it immediately",
      description: "Solves a problem they face every day",
    },
    {
      icon: Building,
      title: "Councils see the value",
      description: "Clear, consistent evidence format",
    },
    {
      icon: FlaskConical,
      title: "Researchers can study it",
      description: "Structured data enables insights",
    },
    {
      icon: Coins,
      title: "Funding bodies recognise the problem",
      description: "Addresses a known gap in SEND support",
    },
  ];

  return (
    <section id="why-it-works" className="px-4 py-12 scroll-mt-20">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">
          <span className="text-cyan-400">Why This Is Strategically Strong</span>
        </h2>
        <p className="text-center text-muted-foreground text-lg mb-10 max-w-2xl mx-auto">
          It aligns with something every school struggles with:{" "}
          <span className="text-foreground font-medium">EHCP evidence gathering</span>
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          {benefits.map((item, index) => (
            <div
              key={index}
              className="rounded-2xl bg-card border border-border p-5 hover:border-cyan-400/50 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-cyan-400/10 flex items-center justify-center flex-shrink-0">
                  <item.icon className="h-5 w-5 text-cyan-400" />
                </div>
                <div>
                  <p className="font-semibold text-foreground">{item.title}</p>
                  <p className="text-muted-foreground text-sm">{item.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="rounded-2xl bg-gradient-to-r from-amber-500/10 to-cyan-400/10 border border-amber-500/30 p-6 text-center">
          <p className="text-lg text-foreground mb-4">
            If NeuroPathway became the{" "}
            <span className="text-amber-500 font-semibold">best tool for EHCP evidence</span>, it could
            eventually become the{" "}
            <span className="text-amber-500 font-semibold">default system councils use nationally</span>.
          </p>
          <Link href="/auth/sign-up">
            <Button size="lg" className="gap-2">
              Join the Movement
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
