"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { FileText, Loader2, Users, School, Stethoscope, FileCheck, Sparkles } from "lucide-react";

interface ReportData {
  child: {
    firstName: string;
    lastName: string | null;
    schoolYear: string | null;
    dateOfBirth: string | null;
  };
  summary: {
    totalObservations: number;
    totalInterventions: number;
    dateRange: { from: string; to: string } | null;
  };
  patterns: Array<{ name: string; count: number; avgSeverity: number }>;
  timePatterns: Array<{ time: string; count: number }>;
  interventions: {
    successful: Array<{ name: string; notes: string | null }>;
    unsuccessful: Array<{ name: string; notes: string | null }>;
  };
  observations: Array<{
    category: string;
    severity: number;
    notes: string | null;
    triggers: string | null;
    date: string;
    timeOfDay: string | null;
  }> | undefined;
}

const reportTypes = [
  { id: 'parent_summary', label: 'Parent Summary', icon: Users, color: 'bg-blue-500/10 text-blue-500 hover:bg-blue-500/20' },
  { id: 'teacher_summary', label: 'Teacher Summary', icon: School, color: 'bg-green-500/10 text-green-500 hover:bg-green-500/20' },
  { id: 'clinical_summary', label: 'Clinical Summary', icon: Stethoscope, color: 'bg-purple-500/10 text-purple-500 hover:bg-purple-500/20' },
  { id: 'ehcp_evidence', label: 'EHCP Evidence', icon: FileCheck, color: 'bg-amber-500/10 text-amber-500 hover:bg-amber-500/20' },
];

export function GenerateReportButton({
  childId,
  reportData,
  assessmentId,
}: {
  childId: string;
  reportData: ReportData;
  assessmentId?: string;
}) {
  const router = useRouter();
  const [isLoading, setIsLoading] = useState<string | null>(null);
  const [selectedType, setSelectedType] = useState<string | null>(null);

  const handleGenerateLegacy = async () => {
    setIsLoading('legacy');

    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      setIsLoading(null);
      return;
    }

    // Save legacy report to database
    const { data: report, error } = await supabase
      .from("ehcp_reports")
      .insert({
        user_id: user.id,
        child_id: childId,
        report_data: reportData,
        status: "generated",
        generated_at: new Date().toISOString(),
      })
      .select()
      .single();

    if (error) {
      console.error("Error saving report:", error);
      setIsLoading(null);
      return;
    }

    router.push(`/dashboard/reports/view/${report.id}`);
  };

  const handleGenerateAI = async (reportType: string) => {
    setIsLoading(reportType);

    try {
      const res = await fetch('/api/ai/reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          child_id: childId,
          report_type: reportType,
          assessment_id: assessmentId
        })
      });

      if (res.ok) {
        router.push('/dashboard/reports');
        router.refresh();
      } else {
        const data = await res.json();
        console.error('Report generation failed:', data.error);
        // Fall back to legacy if AI fails
        if (!assessmentId) {
          await handleGenerateLegacy();
        }
      }
    } catch (error) {
      console.error('Report generation error:', error);
    } finally {
      setIsLoading(null);
    }
  };

  return (
    <div className="space-y-4">
      {/* AI Report Generation */}
      {assessmentId && (
        <Card className="border-primary/30">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="h-5 w-5 text-primary" />
              <span className="font-medium">Generate AI-Powered Report</span>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {reportTypes.map((type) => {
                const Icon = type.icon;
                const isCurrentLoading = isLoading === type.id;
                return (
                  <Button
                    key={type.id}
                    variant="outline"
                    className={`h-auto py-3 px-4 justify-start gap-3 ${selectedType === type.id ? 'ring-2 ring-primary' : ''}`}
                    onClick={() => handleGenerateAI(type.id)}
                    disabled={isLoading !== null}
                  >
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${type.color}`}>
                      {isCurrentLoading ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Icon className="h-4 w-4" />
                      )}
                    </div>
                    <span className="text-left">
                      {isCurrentLoading ? 'Generating...' : type.label}
                    </span>
                  </Button>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Legacy Report Button */}
      <Button
        size="lg"
        variant={assessmentId ? "outline" : "default"}
        className="w-full gap-2"
        onClick={handleGenerateLegacy}
        disabled={isLoading !== null}
      >
        {isLoading === 'legacy' ? (
          <>
            <Loader2 className="h-5 w-5 animate-spin" />
            Generating Report...
          </>
        ) : (
          <>
            <FileText className="h-5 w-5" />
            {assessmentId ? 'Generate Basic EHCP Report' : 'Generate EHCP Evidence Report'}
          </>
        )}
      </Button>
    </div>
  );
}
