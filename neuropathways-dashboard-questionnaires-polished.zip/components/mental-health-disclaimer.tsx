"use client";

import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { AlertTriangle, Phone, Heart, Shield, ExternalLink } from "lucide-react";
import Link from "next/link";

interface MentalHealthDisclaimerProps {
  onAccept?: () => void;
  showAcceptButton?: boolean;
  compact?: boolean;
}

const crisisResources = [
  {
    name: "Samaritans",
    phone: "116 123",
    description: "24/7 emotional support for anyone in distress",
    url: "https://www.samaritans.org",
  },
  {
    name: "Childline",
    phone: "0800 1111",
    description: "For children and young people under 19",
    url: "https://www.childline.org.uk",
  },
  {
    name: "PAPYRUS",
    phone: "0800 068 4141",
    description: "Prevention of young suicide",
    url: "https://www.papyrus-uk.org",
  },
  {
    name: "Mind",
    phone: "0300 123 3393",
    description: "Mental health charity support line",
    url: "https://www.mind.org.uk",
  },
  {
    name: "Crisis Text Line",
    phone: "Text SHOUT to 85258",
    description: "Free, 24/7 text support",
    url: "https://giveusashout.org",
  },
];

export function MentalHealthDisclaimer({ onAccept, showAcceptButton = false, compact = false }: MentalHealthDisclaimerProps) {
  const [acknowledged, setAcknowledged] = useState(false);

  if (compact) {
    return (
      <Card className="bg-amber-500/10 border-amber-500/30">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="h-5 w-5 text-amber-500 shrink-0 mt-0.5" />
            <div className="space-y-2">
              <p className="text-sm text-foreground font-medium">Important Mental Health Notice</p>
              <p className="text-xs text-muted-foreground">
                This tool is for observation tracking only and does not provide medical advice, diagnosis, or treatment. 
                If you have concerns about a child&apos;s mental health or wellbeing, please contact a qualified professional.
              </p>
              <p className="text-xs text-amber-500 font-medium">
                In a crisis? Call Samaritans: 116 123 (24/7, free)
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-card border-border">
      <CardContent className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-amber-500/10 flex items-center justify-center">
            <Heart className="h-6 w-6 text-amber-500" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">Mental Health & Safeguarding Notice</h3>
            <p className="text-sm text-muted-foreground">Important information before you continue</p>
          </div>
        </div>

        {/* Main Disclaimer */}
        <div className="space-y-4 text-sm">
          <div className="p-4 bg-secondary/50 rounded-lg space-y-3">
            <div className="flex items-start gap-2">
              <Shield className="h-4 w-4 text-primary shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-foreground">Purpose of NeuroPathway</p>
                <p className="text-muted-foreground">
                  This platform is designed to help document observations and build evidence for EHCP applications. 
                  It is NOT a diagnostic tool, therapy service, or substitute for professional mental health support.
                </p>
              </div>
            </div>
          </div>

          <div className="p-4 bg-red-500/5 border border-red-500/20 rounded-lg space-y-3">
            <div className="flex items-start gap-2">
              <AlertTriangle className="h-4 w-4 text-red-500 shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-red-400">Emergency Situations</p>
                <p className="text-muted-foreground">
                  If you believe a child is in immediate danger, experiencing a mental health crisis, or there are 
                  safeguarding concerns, please contact emergency services (999) or your local authority 
                  safeguarding team immediately.
                </p>
              </div>
            </div>
          </div>

          <div className="p-4 bg-blue-500/5 border border-blue-500/20 rounded-lg space-y-3">
            <div className="flex items-start gap-2">
              <Phone className="h-4 w-4 text-blue-500 shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-blue-400">Professional Support</p>
                <p className="text-muted-foreground">
                  For mental health concerns, please consult with your GP, school SENCO, CAMHS, or other 
                  qualified professionals. Observations recorded here should be shared with relevant professionals 
                  to inform their assessments.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Crisis Resources */}
        <div className="space-y-3">
          <h4 className="font-medium text-foreground text-sm">24/7 Crisis Support Lines</h4>
          <div className="grid gap-2">
            {crisisResources.map((resource) => (
              <Link
                key={resource.name}
                href={resource.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-between p-3 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors group"
              >
                <div>
                  <p className="font-medium text-foreground text-sm">{resource.name}</p>
                  <p className="text-xs text-muted-foreground">{resource.description}</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-primary font-mono text-sm">{resource.phone}</span>
                  <ExternalLink className="h-3 w-3 text-muted-foreground group-hover:text-primary" />
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Acceptance */}
        {showAcceptButton && (
          <div className="space-y-4 pt-4 border-t border-border">
            <div className="flex items-start gap-3">
              <Checkbox
                id="acknowledge"
                checked={acknowledged}
                onCheckedChange={(checked) => setAcknowledged(checked as boolean)}
              />
              <label htmlFor="acknowledge" className="text-sm text-muted-foreground cursor-pointer">
                I understand that NeuroPathway is an observation tracking tool, not a mental health service. 
                I will seek professional help for any mental health or safeguarding concerns. I acknowledge the 
                emergency contact information provided above.
              </label>
            </div>
            <Button 
              onClick={onAccept} 
              disabled={!acknowledged} 
              className="w-full"
            >
              I Understand - Continue
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export function CrisisBannerCompact() {
  return (
    <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3 text-center">
      <p className="text-sm text-red-400">
        <span className="font-medium">In a crisis?</span>{" "}
        <a href="tel:116123" className="underline">Call Samaritans: 116 123</a> (24/7, free) |{" "}
        <a href="tel:999" className="underline">Emergency: 999</a>
      </p>
    </div>
  );
}
