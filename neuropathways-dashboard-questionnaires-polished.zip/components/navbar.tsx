"use client";

import Image from "next/image";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/theme-toggle";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  ChevronDown,
  Sparkles,
  LogIn,
  LayoutDashboard,
  Home,
  FileText,
  Shield,
  HelpCircle,
} from "lucide-react";

export function Navbar() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <>
      <header className="sticky top-0 z-50 w-full bg-background/80 backdrop-blur-md border-b border-border">
        <nav className="grid grid-cols-3 items-center px-3 py-3 max-w-7xl mx-auto">
          {/* Left side - Dashboard menu */}
          <div className="flex items-center gap-1.5">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="secondary"
                  size="sm"
                  className="rounded-full bg-secondary text-foreground hover:bg-secondary/80 font-medium h-7 px-3 text-xs"
                >
                  <LayoutDashboard className="mr-1 h-3 w-3" />
                  Dashboard
                  <ChevronDown className="ml-1 h-3 w-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-56">
                <DropdownMenuItem asChild>
                  <Link href="/dashboard">
                    <LayoutDashboard className="mr-2 h-4 w-4" />
                    Dashboard
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/">
                    <Home className="mr-2 h-4 w-4" />
                    Home
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem onSelect={() => scrollToSection("how-it-works")}>
                  <FileText className="mr-2 h-4 w-4" />
                  How It Works
                </DropdownMenuItem>
                <DropdownMenuItem onSelect={() => scrollToSection("compliance")}>
                  <Shield className="mr-2 h-4 w-4" />
                  Compliance &amp; GDPR
                </DropdownMenuItem>
                <DropdownMenuItem onSelect={() => scrollToSection("why-it-works")}>
                  <HelpCircle className="mr-2 h-4 w-4" />
                  Why It Works
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          {/* Center - Logo */}
          <div className="flex justify-center">
            <Link href="/">
              <div className="relative w-14 h-14 md:w-16 md:h-16 rounded-2xl overflow-hidden bg-[#0a1628] border border-border shadow-lg">
                <Image
                  src="/logo.jpeg"
                  alt="NeuroPathway Safe Space"
                  fill
                  className="object-cover"
                  priority
                />
              </div>
            </Link>
          </div>

          {/* Right side - Login, Register and Tour */}
          <div className="flex items-center justify-end gap-1.5">
            <ThemeToggle />
            <Link href="/auth/login">
              <Button
                variant="ghost"
                size="sm"
                className="rounded-full font-medium h-7 px-2 text-xs"
              >
                <LogIn className="mr-1 h-3 w-3" />
                Login
              </Button>
            </Link>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="outline"
                  className="rounded-full border-amber-600/50 text-amber-500 hover:bg-amber-500/10 font-medium bg-transparent h-6 px-2 text-[10px]"
                >
                  Register
                  <ChevronDown className="ml-0.5 h-2.5 w-2.5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem asChild>
                  <Link href="/auth/sign-up?type=parent">Individual / Parent</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/auth/sign-up?type=school">School / Organisation</Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Button
              size="sm"
              className="rounded-full bg-secondary text-foreground hover:bg-secondary/80 font-medium h-7 px-2 text-xs hidden md:flex"
              onClick={() => scrollToSection("how-it-works")}
            >
              <Sparkles className="mr-1 h-3 w-3" />
              Tour
            </Button>
          </div>
        </nav>
      </header>

    </>
  );
}
