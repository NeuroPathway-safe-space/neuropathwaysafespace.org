import { readFileSync } from "node:fs";
import { Client } from "pg";

const file = process.argv[2];
if (!file) {
  console.error("Usage: node scripts/run-sql.mjs <path-to-sql>");
  process.exit(1);
}

const connectionString =
  process.env.POSTGRES_URL_NON_POOLING || process.env.POSTGRES_URL;

if (!connectionString) {
  console.error("No POSTGRES_URL / POSTGRES_URL_NON_POOLING in env");
  process.exit(1);
}

const sql = readFileSync(file, "utf8");

const client = new Client({
  connectionString,
  ssl: { rejectUnauthorized: false },
});

try {
  await client.connect();
  await client.query(sql);
  console.log("[run-sql] Executed successfully:", file);
} catch (err) {
  console.error("[run-sql] FAILED:", err.message);
  process.exitCode = 1;
} finally {
  await client.end();
}
