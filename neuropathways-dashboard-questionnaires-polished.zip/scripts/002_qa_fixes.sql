-- ============================================================================
-- NeuroPathway QA fixes (idempotent / non-destructive)
-- 1. Create missing rate_limits table used by lib/security.ts
-- 2. Add missing user_agent column to audit_logs
-- 3. Add missing RLS policies to actively-used youth tables
--    (mood_logs, journal_entries, coping_tools) mirroring the youth_* model
-- 4. Lock down exposed legacy template tables (posts, comments, users)
-- ============================================================================

-- ---------------------------------------------------------------------------
-- 1. RATE LIMITS (referenced by lib/security.ts checkRateLimit)
-- ---------------------------------------------------------------------------
create table if not exists public.rate_limits (
  id uuid primary key default gen_random_uuid(),
  identifier text not null,
  endpoint text not null,
  request_count integer not null default 1,
  window_start timestamptz not null default now(),
  created_at timestamptz default now()
);
create index if not exists rate_limits_identifier_endpoint_idx
  on public.rate_limits (identifier, endpoint);
alter table public.rate_limits enable row level security;
-- Managed only by trusted server (service role bypasses RLS). No anon access.

-- ---------------------------------------------------------------------------
-- 2. AUDIT LOGS missing column (lib/security.ts logAuditEvent inserts user_agent)
-- ---------------------------------------------------------------------------
alter table public.audit_logs add column if not exists user_agent text;

-- ---------------------------------------------------------------------------
-- 3. RLS POLICIES for the actively-used youth self-report tables.
--    The Safe Space app is unauthenticated (PIN-gated at the app layer) and
--    writes via the anon client, so INSERT is open (with_check true) exactly
--    like youth_mood_checkins / youth_journal_entries. SELECT is restricted to
--    the linked parent/professional or an admin.
-- ---------------------------------------------------------------------------

-- mood_logs
drop policy if exists "mood_logs_insert" on public.mood_logs;
create policy "mood_logs_insert" on public.mood_logs for insert to public with check (true);
drop policy if exists "mood_logs_select" on public.mood_logs;
create policy "mood_logs_select" on public.mood_logs for select to public using (
  exists (
    select 1 from public.youth_profiles yp
    where yp.id = mood_logs.youth_profile_id
      and (yp.linked_by_user_id = auth.uid() or yp.linked_by_user_id is null)
  )
  or exists (select 1 from public.profiles p where p.id = auth.uid() and p.is_admin = true)
);

-- journal_entries
drop policy if exists "journal_entries_insert" on public.journal_entries;
create policy "journal_entries_insert" on public.journal_entries for insert to public with check (true);
drop policy if exists "journal_entries_select" on public.journal_entries;
create policy "journal_entries_select" on public.journal_entries for select to public using (
  exists (
    select 1 from public.youth_profiles yp
    where yp.id = journal_entries.youth_profile_id
      and (yp.linked_by_user_id = auth.uid() or yp.linked_by_user_id is null)
  )
  or exists (select 1 from public.profiles p where p.id = auth.uid() and p.is_admin = true)
);

-- coping_tools
drop policy if exists "coping_tools_insert" on public.coping_tools;
create policy "coping_tools_insert" on public.coping_tools for insert to public with check (true);
drop policy if exists "coping_tools_select" on public.coping_tools;
create policy "coping_tools_select" on public.coping_tools for select to public using (
  exists (
    select 1 from public.youth_profiles yp
    where yp.id = coping_tools.youth_profile_id
      and (yp.linked_by_user_id = auth.uid() or yp.linked_by_user_id is null)
  )
  or exists (select 1 from public.profiles p where p.id = auth.uid() and p.is_admin = true)
);

-- ---------------------------------------------------------------------------
-- 4. Lock down exposed legacy template tables (posts/comments/users had RLS
--    DISABLED and no policies -> publicly readable/writable). Not referenced by
--    any app code. Enabling RLS with no policies denies all anon/auth access
--    (reversible). Dropping them is left for explicit confirmation.
-- ---------------------------------------------------------------------------
do $$
begin
  if to_regclass('public.posts') is not null then execute 'alter table public.posts enable row level security'; end if;
  if to_regclass('public.comments') is not null then execute 'alter table public.comments enable row level security'; end if;
  if to_regclass('public.users') is not null then execute 'alter table public.users enable row level security'; end if;
end $$;
