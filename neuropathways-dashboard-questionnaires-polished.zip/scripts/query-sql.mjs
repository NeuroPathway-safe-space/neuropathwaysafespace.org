import { readFileSync } from "node:fs";
import { Client } from "pg";

const file = process.argv[2];
const connectionString =
  process.env.POSTGRES_URL_NON_POOLING || process.env.POSTGRES_URL;
const sql = readFileSync(file, "utf8");
const client = new Client({ connectionString, ssl: { rejectUnauthorized: false } });

try {
  await client.connect();
  const res = await client.query(sql);
  console.table(res.rows);
} catch (err) {
  console.error("[query-sql] FAILED:", err.message);
  process.exitCode = 1;
} finally {
  await client.end();
}
