-- ============================================================================
-- NeuroPathway Safe Space - full database schema
-- Idempotent: safe to run multiple times.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- PROFILES + AUTH
-- ---------------------------------------------------------------------------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  first_name text,
  last_name text,
  user_type text,
  role text default 'parent',
  is_admin boolean default false,
  organisation_name text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
alter table public.profiles enable row level security;

create or replace function public.is_admin()
returns boolean language sql security definer set search_path = public as $$
  select coalesce((select p.is_admin from public.profiles p where p.id = auth.uid()), false);
$$;

create or replace function public.owns_child(target_child uuid)
returns boolean language plpgsql security definer set search_path = public as $$
declare
  result boolean;
begin
  execute 'select exists (select 1 from public.children c where c.id = $1 and c.user_id = auth.uid())'
    into result using target_child;
  return result;
exception when undefined_table then
  return false;
end;
$$;

drop policy if exists "profiles_select" on public.profiles;
create policy "profiles_select" on public.profiles for select using (auth.uid() = id or public.is_admin());
drop policy if exists "profiles_insert" on public.profiles;
create policy "profiles_insert" on public.profiles for insert with check (auth.uid() = id);
drop policy if exists "profiles_update" on public.profiles;
create policy "profiles_update" on public.profiles for update using (auth.uid() = id or public.is_admin());

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  meta jsonb := coalesce(new.raw_user_meta_data, '{}'::jsonb);
  assigned_role text := nullif(meta ->> 'assigned_role', '');
  resolved_role text := coalesce(assigned_role, nullif(meta ->> 'user_type', ''), 'parent');
begin
  insert into public.profiles (id, email, first_name, last_name, user_type, role, is_admin, organisation_name)
  values (
    new.id, new.email,
    nullif(meta ->> 'first_name', ''),
    nullif(meta ->> 'last_name', ''),
    nullif(meta ->> 'user_type', ''),
    resolved_role,
    (resolved_role = 'admin'),
    nullif(meta ->> 'organisation_name', '')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users for each row execute function public.handle_new_user();

-- ---------------------------------------------------------------------------
-- INVITE CODES
-- ---------------------------------------------------------------------------
create table if not exists public.invite_codes (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  role text default 'parent',
  max_uses integer,
  uses_count integer default 0,
  expires_at timestamptz,
  is_active boolean default true,
  created_at timestamptz default now()
);
alter table public.invite_codes enable row level security;
drop policy if exists "invite_codes_select" on public.invite_codes;
create policy "invite_codes_select" on public.invite_codes for select using (true);
drop policy if exists "invite_codes_admin" on public.invite_codes;
create policy "invite_codes_admin" on public.invite_codes for all using (public.is_admin()) with check (public.is_admin());

create table if not exists public.admin_invite_codes (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  is_active boolean default true,
  expires_at timestamptz,
  max_uses integer default 1,
  current_uses integer default 0,
  used_by uuid references auth.users(id) on delete set null,
  used_at timestamptz,
  created_at timestamptz default now()
);
alter table public.admin_invite_codes enable row level security;
drop policy if exists "admin_invite_codes_select" on public.admin_invite_codes;
create policy "admin_invite_codes_select" on public.admin_invite_codes for select using (true);
drop policy if exists "admin_invite_codes_update" on public.admin_invite_codes;
create policy "admin_invite_codes_update" on public.admin_invite_codes for update using (true) with check (true);

-- ---------------------------------------------------------------------------
-- CHILDREN
-- ---------------------------------------------------------------------------
create table if not exists public.children (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  first_name text not null,
  last_name text,
  date_of_birth date,
  school_year text,
  created_at timestamptz default now()
);
alter table public.children enable row level security;
drop policy if exists "children_all_own" on public.children;
create policy "children_all_own" on public.children for all
  using (user_id = auth.uid() or public.is_admin())
  with check (user_id = auth.uid());

-- ---------------------------------------------------------------------------
-- OBSERVATION CATEGORIES
-- ---------------------------------------------------------------------------
create table if not exists public.observation_categories (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  priority_level integer default 3,
  created_at timestamptz default now()
);
alter table public.observation_categories enable row level security;
drop policy if exists "obs_cats_select" on public.observation_categories;
create policy "obs_cats_select" on public.observation_categories for select using (true);

-- ---------------------------------------------------------------------------
-- OBSERVATIONS (supports both detailed form + quick check-in shapes)
-- ---------------------------------------------------------------------------
create table if not exists public.observations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  child_id uuid references public.children(id) on delete cascade,
  category_id uuid references public.observation_categories(id) on delete set null,
  category_name text,
  severity integer,
  notes text,
  context text,
  time_of_day text,
  triggers text,
  title text,
  behaviour text,
  setting text,
  observed_at timestamptz default now(),
  created_at timestamptz default now()
);
alter table public.observations enable row level security;
drop policy if exists "observations_all_own" on public.observations;
create policy "observations_all_own" on public.observations for all
  using (user_id = auth.uid() or public.is_admin())
  with check (user_id = auth.uid());

-- ---------------------------------------------------------------------------
-- INTERVENTIONS
-- ---------------------------------------------------------------------------
create table if not exists public.interventions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  child_id uuid references public.children(id) on delete cascade,
  name text not null,
  description text,
  outcome text default 'ongoing',
  notes text,
  started_at date,
  ended_at date,
  created_at timestamptz default now()
);
alter table public.interventions enable row level security;
drop policy if exists "interventions_all_own" on public.interventions;
create policy "interventions_all_own" on public.interventions for all
  using (user_id = auth.uid() or public.is_admin())
  with check (user_id = auth.uid());

-- ---------------------------------------------------------------------------
-- CHECK-INS
-- ---------------------------------------------------------------------------
create table if not exists public.check_ins (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  child_id uuid references public.children(id) on delete cascade,
  cadence text not null,
  responses jsonb,
  summary text,
  overall_score integer,
  check_in_date date default current_date,
  observation_id uuid references public.observations(id) on delete set null,
  created_at timestamptz default now(),
  unique (child_id, cadence, check_in_date)
);
alter table public.check_ins enable row level security;
drop policy if exists "check_ins_all_own" on public.check_ins;
create policy "check_ins_all_own" on public.check_ins for all
  using (user_id = auth.uid() or public.is_admin())
  with check (user_id = auth.uid());

-- ---------------------------------------------------------------------------
-- EHCP REPORTS (legacy)
-- ---------------------------------------------------------------------------
create table if not exists public.ehcp_reports (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  child_id uuid references public.children(id) on delete cascade,
  report_data jsonb,
  report_type text default 'ehcp_evidence',
  title text,
  status text default 'final',
  version integer default 1,
  generated_at timestamptz default now(),
  created_at timestamptz default now()
);
alter table public.ehcp_reports enable row level security;
drop policy if exists "ehcp_reports_all_own" on public.ehcp_reports;
create policy "ehcp_reports_all_own" on public.ehcp_reports for all
  using (user_id = auth.uid() or public.is_admin())
  with check (user_id = auth.uid());

-- ---------------------------------------------------------------------------
-- AI ASSESSMENTS + children-scoped AI tables
-- ---------------------------------------------------------------------------
create table if not exists public.ai_assessments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  child_id uuid references public.children(id) on delete cascade,
  assessment_type text default 'full',
  status text default 'draft',
  risk_status text default 'green',
  risk_reasoning text,
  risk_score numeric,
  pattern_confidence numeric,
  patterns jsonb,
  cross_setting_consistency jsonb,
  data_quality_score numeric,
  data_quality_issues jsonb,
  safeguarding_flags jsonb,
  requires_escalation boolean default false,
  summary text,
  key_findings jsonb,
  recommended_actions jsonb,
  observation_count integer,
  date_range_start date,
  date_range_end date,
  settings_included text[],
  created_at timestamptz default now()
);
alter table public.ai_assessments enable row level security;
drop policy if exists "ai_assessments_all" on public.ai_assessments;
create policy "ai_assessments_all" on public.ai_assessments for all
  using (user_id = auth.uid() or public.owns_child(child_id) or public.is_admin())
  with check (user_id = auth.uid() or public.owns_child(child_id));

create table if not exists public.ai_patterns (
  id uuid primary key default gen_random_uuid(),
  assessment_id uuid references public.ai_assessments(id) on delete cascade,
  child_id uuid references public.children(id) on delete cascade,
  domain text,
  pattern_name text,
  description text,
  frequency text,
  severity text,
  triggers text[],
  protective_factors text[],
  settings text[],
  confidence_score numeric,
  evidence_count integer,
  trend text,
  first_observed date,
  last_observed date,
  created_at timestamptz default now()
);
alter table public.ai_patterns enable row level security;
drop policy if exists "ai_patterns_all" on public.ai_patterns;
create policy "ai_patterns_all" on public.ai_patterns for all
  using (public.owns_child(child_id) or public.is_admin())
  with check (public.owns_child(child_id));

create table if not exists public.ai_strategies (
  id uuid primary key default gen_random_uuid(),
  assessment_id uuid references public.ai_assessments(id) on delete cascade,
  child_id uuid references public.children(id) on delete cascade,
  domain text,
  strategy_name text,
  description text,
  implementation_steps text[],
  target_setting text,
  evidence_base text,
  priority text,
  status text default 'suggested',
  created_at timestamptz default now()
);
alter table public.ai_strategies enable row level security;
drop policy if exists "ai_strategies_all" on public.ai_strategies;
create policy "ai_strategies_all" on public.ai_strategies for all
  using (public.owns_child(child_id) or public.is_admin())
  with check (public.owns_child(child_id));

create table if not exists public.ai_reports (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  child_id uuid references public.children(id) on delete cascade,
  assessment_id uuid references public.ai_assessments(id) on delete set null,
  report_type text,
  title text,
  content jsonb,
  status text default 'draft',
  version integer default 1,
  approved_by uuid references auth.users(id) on delete set null,
  approved_at timestamptz,
  created_at timestamptz default now()
);
alter table public.ai_reports enable row level security;
drop policy if exists "ai_reports_all" on public.ai_reports;
create policy "ai_reports_all" on public.ai_reports for all
  using (user_id = auth.uid() or public.owns_child(child_id) or public.is_admin())
  with check (user_id = auth.uid() or public.owns_child(child_id));

create table if not exists public.ai_runs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  child_id uuid references public.children(id) on delete cascade,
  prompt_id uuid,
  engine_type text,
  input_data jsonb,
  output_data jsonb,
  confidence_score numeric,
  model_used text,
  tokens_used integer,
  latency_ms integer,
  status text,
  error_message text,
  requires_review boolean default false,
  created_at timestamptz default now()
);
alter table public.ai_runs enable row level security;
drop policy if exists "ai_runs_all" on public.ai_runs;
create policy "ai_runs_all" on public.ai_runs for all
  using (user_id = auth.uid() or public.owns_child(child_id) or public.is_admin())
  with check (user_id = auth.uid() or public.owns_child(child_id));

-- ---------------------------------------------------------------------------
-- AI PROMPTS (admin managed)
-- ---------------------------------------------------------------------------
create table if not exists public.ai_prompts (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique not null,
  purpose text,
  category text,
  system_prompt text,
  user_prompt_template text,
  model text default 'openai/gpt-4o-mini',
  temperature numeric default 0.3,
  is_active boolean default true,
  test_status text default 'draft',
  version integer default 1,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
alter table public.ai_prompts enable row level security;
drop policy if exists "ai_prompts_select" on public.ai_prompts;
create policy "ai_prompts_select" on public.ai_prompts for select using (true);
drop policy if exists "ai_prompts_admin" on public.ai_prompts;
create policy "ai_prompts_admin" on public.ai_prompts for all using (public.is_admin()) with check (public.is_admin());

-- ---------------------------------------------------------------------------
-- HUMAN REVIEWS
-- ---------------------------------------------------------------------------
create table if not exists public.human_reviews (
  id uuid primary key default gen_random_uuid(),
  reviewable_type text,
  reviewable_id uuid,
  child_id uuid references public.children(id) on delete cascade,
  user_id uuid references auth.users(id) on delete cascade,
  priority text default 'medium',
  reason text,
  ai_confidence numeric,
  status text default 'pending',
  created_at timestamptz default now()
);
alter table public.human_reviews enable row level security;
drop policy if exists "human_reviews_all" on public.human_reviews;
create policy "human_reviews_all" on public.human_reviews for all
  using (user_id = auth.uid() or public.owns_child(child_id) or public.is_admin())
  with check (user_id = auth.uid() or public.owns_child(child_id));

-- ---------------------------------------------------------------------------
-- SAFEGUARDING ALERTS
-- ---------------------------------------------------------------------------
create table if not exists public.safeguarding_alerts (
  id uuid primary key default gen_random_uuid(),
  child_id uuid not null references public.children(id) on delete cascade,
  user_id uuid references auth.users(id) on delete set null,
  source text,
  source_id uuid,
  severity text,
  alert_type text,
  description text,
  ai_reasoning text,
  status text default 'new',
  created_at timestamptz default now()
);
alter table public.safeguarding_alerts enable row level security;
drop policy if exists "safeguarding_alerts_all" on public.safeguarding_alerts;
create policy "safeguarding_alerts_all" on public.safeguarding_alerts for all
  using (user_id = auth.uid() or public.owns_child(child_id) or public.is_admin())
  with check (user_id = auth.uid() or public.owns_child(child_id));

-- ---------------------------------------------------------------------------
-- PATTERN ANALYSIS (cross-boundary summaries)
-- ---------------------------------------------------------------------------
create table if not exists public.pattern_analysis (
  id uuid primary key default gen_random_uuid(),
  child_id uuid references public.children(id) on delete cascade,
  domain text,
  pattern_name text,
  summary text,
  trend text,
  frequency text,
  severity text,
  evidence_count integer,
  period_start date,
  period_end date,
  source text,
  created_at timestamptz default now()
);
alter table public.pattern_analysis enable row level security;
drop policy if exists "pattern_analysis_all" on public.pattern_analysis;
create policy "pattern_analysis_all" on public.pattern_analysis for all
  using (public.owns_child(child_id) or public.is_admin())
  with check (public.owns_child(child_id));

-- ---------------------------------------------------------------------------
-- AUDIT LOGS
-- ---------------------------------------------------------------------------
create table if not exists public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  action text,
  entity_type text,
  entity_id text,
  old_data jsonb,
  new_data jsonb,
  details jsonb,
  created_at timestamptz default now()
);
alter table public.audit_logs enable row level security;
drop policy if exists "audit_logs_select_own" on public.audit_logs;
create policy "audit_logs_select_own" on public.audit_logs for select using (user_id = auth.uid() or public.is_admin());
drop policy if exists "audit_logs_insert_own" on public.audit_logs;
create policy "audit_logs_insert_own" on public.audit_logs for insert with check (user_id = auth.uid() or user_id is null);

-- ---------------------------------------------------------------------------
-- YOUTH (Safe Space) TABLES - accessed by the unauthenticated youth app
-- (PIN-gated at the app layer; server routes use the service-role client)
-- ---------------------------------------------------------------------------
create table if not exists public.youth_profiles (
  id uuid primary key default gen_random_uuid(),
  display_name text,
  age_range text,
  link_code text unique,
  pin_hash text,
  linked_child_id uuid references public.children(id) on delete set null,
  linked_by_user_id uuid references auth.users(id) on delete set null,
  consent_given boolean default false,
  consent_timestamp timestamptz,
  parental_consent boolean default false,
  parental_consent_timestamp timestamptz,
  last_active timestamptz,
  created_at timestamptz default now()
);
alter table public.youth_profiles enable row level security;
drop policy if exists "youth_profiles_public" on public.youth_profiles;
create policy "youth_profiles_public" on public.youth_profiles for all using (true) with check (true);

create table if not exists public.mood_logs (
  id uuid primary key default gen_random_uuid(),
  youth_profile_id uuid references public.youth_profiles(id) on delete cascade,
  mood_score integer,
  mood_emoji text,
  energy_level integer,
  anxiety_level integer,
  sleep_quality integer,
  feelings jsonb,
  notes text,
  created_at timestamptz default now()
);
alter table public.mood_logs enable row level security;
drop policy if exists "mood_logs_public" on public.mood_logs;
create policy "mood_logs_public" on public.mood_logs for all using (true) with check (true);

create table if not exists public.journal_entries (
  id uuid primary key default gen_random_uuid(),
  youth_profile_id uuid references public.youth_profiles(id) on delete cascade,
  content text,
  ai_response text,
  detected_emotions text[],
  detected_themes text[],
  flagged_for_review boolean default false,
  flag_reason text,
  created_at timestamptz default now()
);
alter table public.journal_entries enable row level security;
drop policy if exists "journal_entries_public" on public.journal_entries;
create policy "journal_entries_public" on public.journal_entries for all using (true) with check (true);

create table if not exists public.coping_tools (
  id uuid primary key default gen_random_uuid(),
  youth_profile_id uuid references public.youth_profiles(id) on delete cascade,
  exercise_type text,
  duration_seconds integer,
  created_at timestamptz default now()
);
alter table public.coping_tools enable row level security;
drop policy if exists "coping_tools_public" on public.coping_tools;
create policy "coping_tools_public" on public.coping_tools for all using (true) with check (true);

-- ---------------------------------------------------------------------------
-- SEED DATA
-- ---------------------------------------------------------------------------
insert into public.invite_codes (code, role, max_uses, is_active) values
  ('PARENT2026', 'parent', 1000, true),
  ('SCHOOL2026', 'school', 1000, true),
  ('NEUROADMIN', 'admin', 50, true)
on conflict (code) do nothing;

insert into public.admin_invite_codes (code, is_active, max_uses) values
  ('NEURO-ADMIN-DEMO2026', true, 50)
on conflict (code) do nothing;

insert into public.observation_categories (name, description, priority_level) values
  ('Communication & Interaction', 'Difficulties with speech, language, and social communication', 1),
  ('Cognition & Learning', 'Challenges with learning, memory, and processing', 2),
  ('Social, Emotional & Mental Health', 'Emotional regulation, anxiety, behaviour', 1),
  ('Sensory & Physical', 'Sensory processing and physical needs', 2),
  ('Emotional Regulation', 'Managing and responding to emotions', 1),
  ('Attention & Focus', 'Concentration, attention, and task completion', 3),
  ('Social Skills', 'Interaction with peers and adults', 3),
  ('Daily Living', 'Self-care and independence skills', 4)
on conflict do nothing;

insert into public.ai_prompts (name, slug, purpose, category, system_prompt, user_prompt_template, model, temperature, is_active, test_status) values
  ('Pattern Recognition v1', 'pattern-recognition-v1', 'Identify behavioural patterns from observations', 'pattern_recognition',
   'You are an expert SEND analyst. Identify objective, needs-led behavioural patterns from observation data. Never diagnose. Be evidence-based and cautious.',
   'Analyse {{observation_count}} observations for {{child_name}} over {{date_range}}. Identify recurring patterns.',
   'openai/gpt-4o-mini', 0.3, true, 'production'),
  ('Risk Stratification v1', 'risk-stratification-v1', 'Assess safeguarding/wellbeing risk level', 'risk_stratification',
   'You are a cautious safeguarding triage assistant. Assess risk conservatively (green/amber/red). When in doubt, escalate. Never diagnose.',
   'Review the following observations and any youth-reported data to assess current risk level.',
   'openai/gpt-4o-mini', 0.2, true, 'production'),
  ('EHCP Evidence Mapper v1', 'ehcp-evidence-v1', 'Map observations to the four EHCP areas of need', 'ehcp_evidence',
   'You are an EHCP evidence specialist. Map observations to the four areas of need and rate evidence strength objectively.',
   'Map the following observations to the four EHCP areas of need.',
   'openai/gpt-4o-mini', 0.3, true, 'production'),
  ('Strategy Generator v1', 'strategy-generator-v1', 'Generate practical support strategies', 'strategies',
   'You are a SEND strategy specialist. Generate practical, evidence-based support strategies tailored to the setting.',
   'Generate support strategies for pattern "{{pattern_name}}" for {{child_name}} in {{target_setting}}.',
   'openai/gpt-4o-mini', 0.4, true, 'production'),
  ('Cross-Setting Correlation v1', 'cross-setting-v1', 'Correlate behaviours across settings', 'cross_setting',
   'You analyse how behaviours differ across settings ({{settings}}) to surface environmental factors. Be objective.',
   'Analyse behaviour consistency across these settings: {{settings}}.',
   'openai/gpt-4o-mini', 0.3, true, 'production'),
  ('Safe Space Insights v1', 'safe-space-insights-v1', 'Summarise youth wellbeing trends', 'safe_space_insights',
   'You summarise youth self-reported wellbeing into trends only. Never expose raw journal text. Be protective and gentle.',
   'Summarise wellbeing trends from the provided mood and journal metadata.',
   'openai/gpt-4o-mini', 0.3, true, 'production')
on conflict (slug) do nothing;
