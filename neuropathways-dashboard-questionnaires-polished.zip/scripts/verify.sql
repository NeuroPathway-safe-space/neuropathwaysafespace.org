select 'tables' as kind, count(*)::text as value from information_schema.tables where table_schema = 'public'
union all
select 'invite_codes', string_agg(code, ', ') from public.invite_codes
union all
select 'obs_categories', count(*)::text from public.observation_categories
union all
select 'ai_prompts', count(*)::text from public.ai_prompts
union all
select 'profiles_trigger', tgname from pg_trigger where tgname = 'on_auth_user_created';
