"use client";

import { useState, useEffect } from "react";
import { createClient } from "@/lib/supabase/client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Link2, Heart, CheckCircle2 } from "lucide-react";
import Link from "next/link";

type Child = { id: string; first_name: string; last_name: string | null };

type LinkedProfile = {
  id: string;
  display_name: string;
  link_code: string;
  linked_child_id: string | null;
  children?: { first_name: string; last_name: string | null } | null;
  stats?: { moodCheckins: number; journalEntries: number };
};

export default function ConnectChildPage() {
  const [children, setChildren] = useState<Child[]>([]);
  const [linkedProfiles, setLinkedProfiles] = useState<LinkedProfile[]>([]);
  const [childId, setChildId] = useState("");
  const [linkCode, setLinkCode] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const loadData = async () => {
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data: kids } = await supabase
      .from("children")
      .select("id, first_name, last_name")
      .eq("user_id", user.id)
      .order("first_name");
    setChildren(kids || []);

    const res = await fetch("/api/youth/sync");
    if (res.ok) {
      const data = await res.json();
      setLinkedProfiles(data.profiles || []);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleLink = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    if (!childId || !linkCode) {
      setError("Choose a child and enter their Safe Space code.");
      return;
    }
    setIsLoading(true);
    try {
      const res = await fetch("/api/youth/sync", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "link",
          childId,
          linkCode: linkCode.trim().toUpperCase(),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Could not link this code.");
        return;
      }
      setSuccess(data.message || "Linked successfully.");
      setLinkCode("");
      setChildId("");
      await loadData();
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-xl mx-auto px-4 py-6">
      <Link href="/dashboard" className="flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6">
        <ArrowLeft className="h-4 w-4" />
        Back to Dashboard
      </Link>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Link2 className="h-5 w-5 text-emerald-500" />
            Connect a Safe Space
          </CardTitle>
          <CardDescription>
            Enter the link code the young person sees in their Safe Space app to connect their
            wellbeing summaries to a child&apos;s record. You will only ever see summaries and
            safeguarding alerts, never their private journal entries.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {children.length === 0 ? (
            <div className="text-sm text-muted-foreground">
              You need to add a child first.{" "}
              <Link href="/dashboard/children/new" className="text-emerald-500 hover:underline">
                Add a child
              </Link>
              .
            </div>
          ) : (
            <form onSubmit={handleLink} className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="child">Child / Student</Label>
                <select
                  id="child"
                  value={childId}
                  onChange={(e) => setChildId(e.target.value)}
                  className="h-10 rounded-md border border-input bg-background px-3 text-sm"
                >
                  <option value="">Select a child...</option>
                  {children.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.first_name} {c.last_name || ""}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid gap-2">
                <Label htmlFor="code">Safe Space link code</Label>
                <Input
                  id="code"
                  value={linkCode}
                  onChange={(e) => setLinkCode(e.target.value.toUpperCase())}
                  placeholder="e.g. AB12CD"
                  maxLength={6}
                  className="tracking-widest"
                />
              </div>

              {error && <p className="text-sm text-red-500">{error}</p>}
              {success && (
                <p className="text-sm text-emerald-500 flex items-center gap-1">
                  <CheckCircle2 className="h-4 w-4" />
                  {success}
                </p>
              )}

              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? "Connecting..." : "Connect Safe Space"}
              </Button>
            </form>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Heart className="h-4 w-4 text-emerald-500" />
            Connected Safe Spaces
          </CardTitle>
        </CardHeader>
        <CardContent>
          {linkedProfiles.length === 0 ? (
            <p className="text-sm text-muted-foreground">No Safe Space profiles connected yet.</p>
          ) : (
            <ul className="space-y-3">
              {linkedProfiles.map((p) => (
                <li
                  key={p.id}
                  className="flex items-center justify-between gap-3 rounded-lg border border-border p-3"
                >
                  <div>
                    <p className="font-medium text-sm text-foreground">{p.display_name}</p>
                    <p className="text-xs text-muted-foreground">
                      {p.children
                        ? `Linked to ${p.children.first_name} ${p.children.last_name || ""}`
                        : "Not linked to a child"}
                    </p>
                  </div>
                  {p.stats && (
                    <p className="text-xs text-muted-foreground shrink-0">
                      {p.stats.moodCheckins} check-ins · {p.stats.journalEntries} entries
                    </p>
                  )}
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
