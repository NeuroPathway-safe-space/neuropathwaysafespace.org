import { createClient } from "@/lib/supabase/server";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import Link from "next/link";
import {
  AlertTriangle,
  ArrowRight,
  BarChart3,
  Brain,
  CalendarCheck,
  CheckCircle2,
  ClipboardList,
  FileText,
  HeartPulse,
  MessageSquareText,
  Phone,
  Plus,
  Shield,
  Sparkles,
  Users,
  Wand2,
} from "lucide-react";

const questionnaireCards = [
  {
    title: "Daily check-in",
    description: "Mood, regulation, focus, social connection and energy.",
    href: "/dashboard/check-in",
    icon: CalendarCheck,
    badge: "2 mins",
    className: "from-cyan-500/15 via-teal-500/10 to-transparent border-cyan-500/20",
  },
  {
    title: "Weekly review",
    description: "Attendance, learning, relationships and independence patterns.",
    href: "/dashboard/check-in?type=weekly",
    icon: BarChart3,
    badge: "EHCP evidence",
    className: "from-violet-500/15 via-fuchsia-500/10 to-transparent border-violet-500/20",
  },
  {
    title: "Quick observation",
    description: "Capture what happened, what triggered it and what helped.",
    href: "/dashboard/observations/new",
    icon: MessageSquareText,
    badge: "Live note",
    className: "from-emerald-500/15 via-green-500/10 to-transparent border-emerald-500/20",
  },
];

const evidenceSteps = [
  "Everyday questionnaire",
  "Observation record",
  "Pattern summary",
  "EHCP-ready report",
];

export default async function DashboardPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: children } = await supabase
    .from("children")
    .select("*")
    .order("created_at", { ascending: false });

  const { count: observationCount } = await supabase
    .from("observations")
    .select("*", { count: "exact", head: true });

  const { count: interventionCount } = await supabase
    .from("interventions")
    .select("*", { count: "exact", head: true });

  const { count: reportCount } = await supabase
    .from("ehcp_reports")
    .select("*", { count: "exact", head: true });

  const { count: checkInCount } = await supabase
    .from("check_ins")
    .select("*", { count: "exact", head: true });

  const { data: recentCheckIns } = await supabase
    .from("check_ins")
    .select("id, child_id, cadence, overall_score, summary, check_in_date, created_at")
    .order("created_at", { ascending: false })
    .limit(3);

  const { data: recentAssessment } = await supabase
    .from("ai_assessments")
    .select("id, risk_status, pattern_confidence, created_at")
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  const { count: pendingReviews } = await supabase
    .from("human_reviews")
    .select("*", { count: "exact", head: true })
    .eq("status", "pending");

  const { count: activeAlerts } = await supabase
    .from("safeguarding_alerts")
    .select("*", { count: "exact", head: true })
    .in("status", ["new", "acknowledged", "investigating", "escalated"]);

  const { data: profile } = await supabase
    .from("profiles")
    .select("is_admin")
    .eq("id", user?.id)
    .maybeSingle();

  const isAdmin = profile?.is_admin || false;
  const hasChildren = Boolean(children && children.length > 0);
  const isSchoolUser = user?.user_metadata?.user_type === "school";
  const childLabel = isSchoolUser ? "Students" : "Children";
  const childSingular = isSchoolUser ? "Student" : "Child";
  const evidenceTotal = (observationCount || 0) + (checkInCount || 0) + (interventionCount || 0);
  const progressValue = Math.min(100, evidenceTotal * 8);

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 py-6 space-y-8">
        <div className="rounded-2xl border border-amber-500/25 bg-amber-500/10 px-4 py-3 shadow-sm">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-amber-500 shrink-0" />
              <span className="text-sm text-muted-foreground">
                <span className="font-semibold text-amber-500">Need support?</span> This tool builds evidence but does not replace professional help.
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-3 text-xs">
              <a href="tel:116123" className="inline-flex items-center gap-1 text-amber-500 hover:underline">
                <Phone className="h-3 w-3" />
                Samaritans: 116 123
              </a>
              <a href="tel:999" className="font-medium text-red-500 hover:underline">Emergency: 999</a>
            </div>
          </div>
        </div>

        <section className="grid gap-6 lg:grid-cols-[1.45fr_0.75fr]">
          <Card className="overflow-hidden border-primary/20 bg-gradient-to-br from-primary/15 via-background to-background shadow-xl">
            <CardContent className="p-6 sm:p-8">
              <div className="mb-5 flex flex-wrap items-center gap-2">
                <Badge className="gap-1 rounded-full px-3 py-1" variant="secondary">
                  <Sparkles className="h-3.5 w-3.5" />
                  EHCP evidence builder
                </Badge>
                <Badge className="rounded-full px-3 py-1 bg-background/70" variant="outline">
                  Needs first, not diagnosis
                </Badge>
              </div>
              <h1 className="max-w-3xl text-3xl font-bold tracking-tight text-foreground sm:text-4xl text-balance">
                Turn everyday moments into clear NeuroPathway evidence.
              </h1>
              <p className="mt-3 max-w-2xl text-base text-muted-foreground text-pretty">
                Use daily and weekly questionnaires to capture patterns across home, school and professional support, then turn them into EHCP-ready summaries.
              </p>

              <div className="mt-6 flex flex-col gap-3 sm:flex-row">
                <Link href={hasChildren ? "/dashboard/check-in" : "/dashboard/children/new"}>
                  <Button size="lg" className="w-full gap-2 sm:w-auto">
                    {hasChildren ? "Start everyday check-in" : `Add first ${childSingular}`}
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
                <Link href="/dashboard/reports">
                  <Button size="lg" variant="outline" className="w-full gap-2 bg-background/70 sm:w-auto">
                    <FileText className="h-4 w-4" />
                    Build EHCP report
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>

          <Card className="border-primary/15 bg-card/85 shadow-lg backdrop-blur">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <HeartPulse className="h-5 w-5 text-primary" />
                Evidence progress
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              <div>
                <div className="mb-2 flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Record strength</span>
                  <span className="font-medium">{progressValue}%</span>
                </div>
                <Progress value={progressValue} />
              </div>
              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="rounded-xl border bg-background/60 p-3">
                  <p className="text-2xl font-bold">{checkInCount || 0}</p>
                  <p className="text-xs text-muted-foreground">Check-ins</p>
                </div>
                <div className="rounded-xl border bg-background/60 p-3">
                  <p className="text-2xl font-bold">{observationCount || 0}</p>
                  <p className="text-xs text-muted-foreground">Notes</p>
                </div>
                <div className="rounded-xl border bg-background/60 p-3">
                  <p className="text-2xl font-bold">{reportCount || 0}</p>
                  <p className="text-xs text-muted-foreground">Reports</p>
                </div>
              </div>
              <div className="space-y-2">
                {evidenceSteps.map((step, index) => (
                  <div key={step} className="flex items-center gap-2 text-sm">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary/10 text-xs font-semibold text-primary">
                      {index + 1}
                    </span>
                    <span className="text-muted-foreground">{step}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </section>

        {hasChildren && (
          <section className="space-y-4">
            <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
              <div>
                <p className="text-sm font-medium uppercase tracking-wide text-primary">Everyday questionnaires</p>
                <h2 className="text-2xl font-bold text-foreground">Capture what usually gets missed</h2>
                <p className="text-muted-foreground">Small snapshots create the strongest pattern evidence over time.</p>
              </div>
              <Link href="/dashboard/check-in">
                <Button variant="outline" className="gap-2">
                  Open questionnaire
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
            </div>

            <div className="grid gap-4 md:grid-cols-3">
              {questionnaireCards.map((item) => {
                const Icon = item.icon;
                return (
                  <Link key={item.title} href={item.href}>
                    <Card className={`group h-full overflow-hidden bg-gradient-to-br ${item.className} shadow-sm transition-all hover:-translate-y-1 hover:shadow-xl`}>
                      <CardContent className="p-5">
                        <div className="mb-5 flex items-start justify-between gap-3">
                          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-background/80 shadow-sm">
                            <Icon className="h-6 w-6 text-primary" />
                          </div>
                          <Badge variant="secondary" className="rounded-full">{item.badge}</Badge>
                        </div>
                        <h3 className="text-lg font-semibold text-foreground">{item.title}</h3>
                        <p className="mt-2 text-sm text-muted-foreground">{item.description}</p>
                        <div className="mt-5 flex items-center text-sm font-medium text-primary">
                          Start now
                          <ArrowRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                );
              })}
            </div>
          </section>
        )}

        <section className="grid gap-4 md:grid-cols-4">
          <Card className="shadow-sm">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total observations</CardTitle>
            </CardHeader>
            <CardContent className="flex items-center gap-3">
              <div className="rounded-xl bg-primary/10 p-2"><ClipboardList className="h-5 w-5 text-primary" /></div>
              <span className="text-3xl font-bold">{observationCount || 0}</span>
            </CardContent>
          </Card>
          <Card className="shadow-sm">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Questionnaires</CardTitle>
            </CardHeader>
            <CardContent className="flex items-center gap-3">
              <div className="rounded-xl bg-cyan-500/10 p-2"><CalendarCheck className="h-5 w-5 text-cyan-500" /></div>
              <span className="text-3xl font-bold">{checkInCount || 0}</span>
            </CardContent>
          </Card>
          <Card className="shadow-sm">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Interventions</CardTitle>
            </CardHeader>
            <CardContent className="flex items-center gap-3">
              <div className="rounded-xl bg-amber-500/10 p-2"><Users className="h-5 w-5 text-amber-500" /></div>
              <span className="text-3xl font-bold">{interventionCount || 0}</span>
            </CardContent>
          </Card>
          <Card className="shadow-sm">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">EHCP reports</CardTitle>
            </CardHeader>
            <CardContent className="flex items-center gap-3">
              <div className="rounded-xl bg-emerald-500/10 p-2"><FileText className="h-5 w-5 text-emerald-500" /></div>
              <span className="text-3xl font-bold">{reportCount || 0}</span>
            </CardContent>
          </Card>
        </section>

        {hasChildren && (
          <section className="grid gap-6 lg:grid-cols-[1fr_0.95fr]">
            <Card className="border-violet-500/20 bg-gradient-to-br from-violet-500/10 to-background shadow-sm">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Sparkles className="h-5 w-5 text-violet-500" />
                    AI pattern insights
                  </CardTitle>
                  <Link href="/dashboard/ai"><Button variant="outline" size="sm">View all</Button></Link>
                </div>
              </CardHeader>
              <CardContent className="grid gap-4 md:grid-cols-3">
                <div className="rounded-xl border bg-background/70 p-4">
                  <p className="mb-2 text-sm text-muted-foreground">Latest assessment</p>
                  {recentAssessment ? (
                    <div className="space-y-2">
                      <Badge variant={recentAssessment.risk_status === "red" ? "destructive" : recentAssessment.risk_status === "amber" ? "secondary" : "default"}>
                        {recentAssessment.risk_status?.toUpperCase()}
                      </Badge>
                      <p className="text-xs text-muted-foreground">
                        {Math.round((recentAssessment.pattern_confidence || 0) * 100)}% confidence
                      </p>
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground">No assessments yet</p>
                  )}
                </div>
                <div className="rounded-xl border bg-background/70 p-4">
                  <p className="mb-2 text-sm text-muted-foreground">Pending reviews</p>
                  <div className="flex items-center gap-2">
                    <span className="text-3xl font-bold">{pendingReviews || 0}</span>
                    {(pendingReviews || 0) > 0 && <Badge variant="secondary">Review</Badge>}
                  </div>
                </div>
                <div className="rounded-xl border bg-background/70 p-4">
                  <p className="mb-2 text-sm text-muted-foreground">Safeguarding</p>
                  <div className="flex items-center gap-2">
                    {(activeAlerts || 0) > 0 ? (
                      <>
                        <Shield className="h-5 w-5 text-red-500" />
                        <span className="text-3xl font-bold text-red-500">{activeAlerts}</span>
                      </>
                    ) : (
                      <>
                        <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                        <span className="text-sm font-medium text-emerald-500">All clear</span>
                      </>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-sm">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Wand2 className="h-5 w-5 text-primary" />
                  Recent questionnaire evidence
                </CardTitle>
              </CardHeader>
              <CardContent>
                {recentCheckIns && recentCheckIns.length > 0 ? (
                  <div className="space-y-3">
                    {recentCheckIns.map((item) => (
                      <div key={item.id} className="rounded-xl border bg-background/60 p-3">
                        <div className="mb-1 flex items-center justify-between gap-2">
                          <Badge variant="outline" className="capitalize">{item.cadence}</Badge>
                          <span className="text-xs text-muted-foreground">Score {item.overall_score || "-"}/5</span>
                        </div>
                        <p className="line-clamp-2 text-sm text-muted-foreground">{item.summary}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="rounded-xl border border-dashed p-5 text-center">
                    <p className="font-medium">No questionnaire evidence yet</p>
                    <p className="mt-1 text-sm text-muted-foreground">Start with a daily check-in to begin building patterns.</p>
                    <Link href="/dashboard/check-in" className="mt-4 inline-block">
                      <Button size="sm" className="gap-2"><CalendarCheck className="h-4 w-4" /> Start check-in</Button>
                    </Link>
                  </div>
                )}
              </CardContent>
            </Card>
          </section>
        )}

        {isAdmin && (
          <Card className="border-amber-500/20 bg-gradient-to-br from-amber-500/10 to-background shadow-sm">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Shield className="h-5 w-5 text-amber-500" />
                Admin tools
              </CardTitle>
            </CardHeader>
            <CardContent className="flex flex-wrap gap-3">
              <Link href="/dashboard/admin/prompts"><Button variant="outline" size="sm" className="gap-2"><Brain className="h-4 w-4" /> Manage AI prompts</Button></Link>
              <Link href="/dashboard/ai?tab=reviews"><Button variant="outline" size="sm" className="gap-2"><ClipboardList className="h-4 w-4" /> Review queue ({pendingReviews || 0})</Button></Link>
              <Link href="/dashboard/ai?tab=alerts"><Button variant="outline" size="sm" className="gap-2"><Shield className="h-4 w-4" /> Safeguarding ({activeAlerts || 0})</Button></Link>
            </CardContent>
          </Card>
        )}

        <Card className="shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>{childLabel}</CardTitle>
            <Link href="/dashboard/children/new">
              <Button size="sm" className="gap-2"><Plus className="h-4 w-4" /> Add {childSingular}</Button>
            </Link>
          </CardHeader>
          <CardContent>
            {hasChildren ? (
              <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
                {children?.map((child) => (
                  <Card key={child.id} className="border-primary/10 bg-gradient-to-br from-card to-primary/5 transition-all hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-md">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-primary/10 shadow-sm">
                          <span className="text-sm font-bold text-primary">{child.first_name?.charAt(0) || "?"}</span>
                        </div>
                        <div className="min-w-0">
                          <p className="truncate font-semibold text-foreground">{child.first_name} {child.last_name}</p>
                          <p className="text-sm text-muted-foreground">{child.school_year ? `Year ${child.school_year}` : "Evidence profile"}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="rounded-2xl border border-dashed bg-muted/20 py-10 text-center">
                <p className="mb-2 text-lg font-semibold">No {childLabel.toLowerCase()} added yet</p>
                <p className="mx-auto mb-5 max-w-md text-sm text-muted-foreground">
                  Add a child or student first, then the questionnaires will feed their EHCP evidence record.
                </p>
                <Link href="/dashboard/children/new">
                  <Button className="gap-2"><Plus className="h-4 w-4" /> Add your first {childSingular}</Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
