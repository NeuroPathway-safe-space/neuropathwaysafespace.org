"use client";

import { useState, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { ArrowLeft, Check, AlertTriangle, Shield, Info } from "lucide-react";
import Link from "next/link";

interface Child {
  id: string;
  first_name: string;
  last_name: string | null;
}

interface Category {
  id: string;
  name: string;
  description: string;
  priority_level: number;
}

const severityLevels = [
  { value: 1, label: "Mild", color: "bg-emerald-500", description: "Minor difficulty, minimal impact on learning" },
  { value: 2, label: "Low", color: "bg-lime-500", description: "Some difficulty, occasional impact" },
  { value: 3, label: "Moderate", color: "bg-amber-500", description: "Regular difficulty, affects daily activities" },
  { value: 4, label: "High", color: "bg-orange-500", description: "Significant difficulty, requires support" },
  { value: 5, label: "Severe", color: "bg-red-500", description: "Major difficulty, intensive support needed" },
];

const timeOptions = ["Morning (8-10am)", "Mid-morning (10-12pm)", "Lunchtime (12-1pm)", "Afternoon (1-3pm)", "After school (3-5pm)", "Evening (5pm+)"];

const settingOptions = ["Classroom", "Playground", "Assembly", "Dining hall", "Corridor", "PE/Sports", "Art/Music", "Home", "Transport", "Other"];

// EHCP-aligned prompt questions for each category
const categoryPrompts: Record<string, string[]> = {
  "Attention / Focus": [
    "How long could they sustain attention?",
    "What strategies helped them refocus?",
    "Were they distracted by specific stimuli?",
  ],
  "Emotional Regulation": [
    "What emotions were displayed?",
    "How long did it take to calm down?",
    "What de-escalation strategies were tried?",
  ],
  "Social Interaction": [
    "How did they interact with peers?",
    "Were there communication difficulties?",
    "Did they understand social cues?",
  ],
  "Sensory Needs": [
    "What sensory input triggered the response?",
    "Were they seeking or avoiding sensory input?",
    "What accommodations helped?",
  ],
  "Learning Engagement": [
    "What task were they working on?",
    "What barriers to learning were observed?",
    "What adaptations supported engagement?",
  ],
  "Communication": [
    "How did they express their needs?",
    "Were they understood by others?",
    "What communication support was provided?",
  ],
  "Physical / Motor": [
    "What physical activity was involved?",
    "Were there coordination difficulties?",
    "What equipment or support was needed?",
  ],
  "Self-Care": [
    "What self-care task was involved?",
    "What level of prompting was needed?",
    "What independence skills were demonstrated?",
  ],
};

// Safeguarding checklist
const safeguardingChecks = [
  { id: "no_harm", label: "No signs of self-harm or harm to others", required: true },
  { id: "no_disclosure", label: "No safeguarding disclosures made", required: true },
  { id: "appropriate_response", label: "Appropriate adult response was provided", required: false },
  { id: "followed_up", label: "Incident has been followed up if needed", required: false },
];

export default function NewObservationPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const preselectedChildId = searchParams.get("child");

  const [children, setChildren] = useState<Child[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedChild, setSelectedChild] = useState<string>(preselectedChildId || "");
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [selectedCategoryName, setSelectedCategoryName] = useState<string>("");
  const [severity, setSeverity] = useState<number>(3);
  const [timeOfDay, setTimeOfDay] = useState("");
  const [setting, setSetting] = useState("");
  
  // EHCP Evidence fields
  const [whatHappened, setWhatHappened] = useState("");
  const [antecedent, setAntecedent] = useState("");
  const [behaviour, setBehaviour] = useState("");
  const [consequence, setConsequence] = useState("");
  const [supportProvided, setSupportProvided] = useState("");
  const [outcome, setOutcome] = useState("");
  const [duration, setDuration] = useState("");
  const [frequency, setFrequency] = useState("");
  
  // Safeguarding
  const [safeguardingChecked, setSafeguardingChecked] = useState<Record<string, boolean>>({});
  const [safeguardingConcern, setSafeguardingConcern] = useState(false);
  const [safeguardingNotes, setSafeguardingNotes] = useState("");
  
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);

  useEffect(() => {
    async function loadData() {
      const supabase = createClient();
      
      const [childrenRes, categoriesRes] = await Promise.all([
        supabase.from("children").select("id, first_name, last_name").order("first_name"),
        supabase.from("observation_categories").select("*").order("priority_level"),
      ]);

      if (childrenRes.data) setChildren(childrenRes.data);
      if (categoriesRes.data) setCategories(categoriesRes.data);
    }
    loadData();
  }, []);

  const handleCategorySelect = (categoryId: string) => {
    setSelectedCategory(categoryId);
    const cat = categories.find(c => c.id === categoryId);
    setSelectedCategoryName(cat?.name || "");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedChild || !selectedCategory) {
      setError("Please select a child and category");
      return;
    }

    // Check required safeguarding items
    const requiredSafeguarding = safeguardingChecks.filter(s => s.required);
    const allRequiredChecked = requiredSafeguarding.every(s => safeguardingChecked[s.id]);
    
    if (!allRequiredChecked && !safeguardingConcern) {
      setError("Please complete the safeguarding checklist or mark as a safeguarding concern");
      return;
    }

    setIsLoading(true);
    setError(null);

    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      setError("You must be logged in");
      setIsLoading(false);
      return;
    }

    // Compile comprehensive notes for EHCP evidence
    const compiledNotes = [
      whatHappened && `What happened: ${whatHappened}`,
      antecedent && `Antecedent (before): ${antecedent}`,
      behaviour && `Behaviour observed: ${behaviour}`,
      consequence && `Consequence (after): ${consequence}`,
      supportProvided && `Support provided: ${supportProvided}`,
      outcome && `Outcome: ${outcome}`,
      duration && `Duration: ${duration}`,
      frequency && `Frequency: ${frequency}`,
      setting && `Setting: ${setting}`,
    ].filter(Boolean).join("\n\n");

    const { error: insertError } = await supabase.from("observations").insert({
      user_id: user.id,
      child_id: selectedChild,
      category_id: selectedCategory,
      category_name: selectedCategoryName,
      severity,
      notes: compiledNotes || null,
      context: setting || null,
      time_of_day: timeOfDay || null,
      triggers: antecedent || null,
    });

    if (insertError) {
      setError(insertError.message);
      setIsLoading(false);
      return;
    }

    // Log audit entry
    await supabase.from("audit_logs").insert({
      user_id: user.id,
      action: "create_observation",
      entity_type: "observation",
      new_data: { 
        child_id: selectedChild, 
        category: selectedCategoryName,
        severity,
        safeguarding_concern: safeguardingConcern,
      },
    });

    // If safeguarding concern, log separately
    if (safeguardingConcern) {
      await supabase.from("audit_logs").insert({
        user_id: user.id,
        action: "safeguarding_concern",
        entity_type: "observation",
        new_data: { 
          child_id: selectedChild,
          notes: safeguardingNotes,
        },
      });
    }

    setSuccess(true);
    setTimeout(() => {
      router.push("/dashboard/observations");
      router.refresh();
    }, 1500);
  };

  if (success) {
    return (
      <div className="max-w-xl mx-auto px-4 py-6 flex items-center justify-center min-h-[60vh]">
        <Card className="w-full text-center">
          <CardContent className="py-12">
            <div className="w-16 h-16 rounded-full bg-emerald-500/10 flex items-center justify-center mx-auto mb-4">
              <Check className="h-8 w-8 text-emerald-500" />
            </div>
            <h2 className="text-xl font-semibold text-foreground mb-2">Observation Logged!</h2>
            <p className="text-muted-foreground">EHCP evidence recorded successfully</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <Link href="/dashboard" className="flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6">
        <ArrowLeft className="h-4 w-4" />
        Back to Dashboard
      </Link>

      <Card>
        <CardHeader>
          <CardTitle>Log EHCP Observation</CardTitle>
          <CardDescription>
            Record behaviour observations with EHCP-ready evidence format
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Child Selection */}
            <div className="space-y-2">
              <Label>Select Child *</Label>
              {children.length === 0 ? (
                <div className="text-center py-4 bg-secondary/50 rounded-lg">
                  <p className="text-muted-foreground text-sm mb-2">No children added yet</p>
                  <Link href="/dashboard/children/new">
                    <Button variant="outline" size="sm">Add a Child First</Button>
                  </Link>
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-2">
                  {children.map((child) => (
                    <button
                      key={child.id}
                      type="button"
                      onClick={() => setSelectedChild(child.id)}
                      className={`p-3 rounded-lg border-2 text-left transition-all ${
                        selectedChild === child.id
                          ? "border-primary bg-primary/10"
                          : "border-border hover:border-primary/50"
                      }`}
                    >
                      <span className="font-medium text-foreground">
                        {child.first_name} {child.last_name}
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Category Selection */}
            <div className="space-y-2">
              <Label>Observation Category *</Label>
              <div className="grid grid-cols-2 gap-2">
                {categories.map((category) => (
                  <button
                    key={category.id}
                    type="button"
                    onClick={() => handleCategorySelect(category.id)}
                    className={`p-3 rounded-lg border-2 text-left transition-all ${
                      selectedCategory === category.id
                        ? "border-primary bg-primary/10"
                        : "border-border hover:border-primary/50"
                    }`}
                  >
                    <span className="font-medium text-foreground text-sm">{category.name}</span>
                    {category.description && (
                      <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{category.description}</p>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Category-specific prompts */}
            {selectedCategoryName && categoryPrompts[selectedCategoryName] && (
              <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-3">
                <div className="flex items-center gap-2 text-blue-500 text-sm font-medium mb-2">
                  <Info className="h-4 w-4" />
                  Consider documenting:
                </div>
                <ul className="text-xs text-blue-400 space-y-1">
                  {categoryPrompts[selectedCategoryName].map((prompt, idx) => (
                    <li key={idx}>• {prompt}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Time and Setting */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Time of Day</Label>
                <div className="flex flex-wrap gap-1.5">
                  {timeOptions.map((time) => (
                    <button
                      key={time}
                      type="button"
                      onClick={() => setTimeOfDay(time)}
                      className={`px-2 py-1 rounded-full text-xs border transition-all ${
                        timeOfDay === time
                          ? "border-primary bg-primary/10 text-primary"
                          : "border-border text-muted-foreground hover:border-primary/50"
                      }`}
                    >
                      {time.split(" ")[0]}
                    </button>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <Label>Setting</Label>
                <div className="flex flex-wrap gap-1.5">
                  {settingOptions.slice(0, 6).map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => setSetting(s)}
                      className={`px-2 py-1 rounded-full text-xs border transition-all ${
                        setting === s
                          ? "border-primary bg-primary/10 text-primary"
                          : "border-border text-muted-foreground hover:border-primary/50"
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Severity */}
            <div className="space-y-2">
              <Label>Severity Level</Label>
              <div className="flex gap-2">
                {severityLevels.map((level) => (
                  <button
                    key={level.value}
                    type="button"
                    onClick={() => setSeverity(level.value)}
                    className={`flex-1 p-2 rounded-lg border-2 text-center transition-all ${
                      severity === level.value
                        ? "border-primary bg-primary/10"
                        : "border-border hover:border-primary/50"
                    }`}
                  >
                    <div className={`w-3 h-3 rounded-full ${level.color} mx-auto mb-1`} />
                    <span className="text-xs text-foreground">{level.label}</span>
                  </button>
                ))}
              </div>
              <p className="text-xs text-muted-foreground">{severityLevels.find(l => l.value === severity)?.description}</p>
            </div>

            {/* ABC Model - EHCP Evidence Format */}
            <div className="space-y-4 pt-2 border-t border-border">
              <h3 className="font-medium text-foreground flex items-center gap-2">
                ABC Observation Record
                <span className="text-xs font-normal text-muted-foreground">(EHCP Evidence Format)</span>
              </h3>
              
              <div className="space-y-2">
                <Label htmlFor="antecedent">A - Antecedent (What happened before?)</Label>
                <Textarea
                  id="antecedent"
                  value={antecedent}
                  onChange={(e) => setAntecedent(e.target.value)}
                  placeholder="Describe what was happening before the behaviour occurred..."
                  className="min-h-[60px]"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="behaviour">B - Behaviour (What did you observe?)</Label>
                <Textarea
                  id="behaviour"
                  value={behaviour}
                  onChange={(e) => setBehaviour(e.target.value)}
                  placeholder="Describe the specific behaviour observed objectively..."
                  className="min-h-[80px]"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="consequence">C - Consequence (What happened after?)</Label>
                <Textarea
                  id="consequence"
                  value={consequence}
                  onChange={(e) => setConsequence(e.target.value)}
                  placeholder="Describe what happened immediately after the behaviour..."
                  className="min-h-[60px]"
                />
              </div>
            </div>

            {/* Support and Outcome */}
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="supportProvided">Support Provided</Label>
                <Textarea
                  id="supportProvided"
                  value={supportProvided}
                  onChange={(e) => setSupportProvided(e.target.value)}
                  placeholder="What strategies or interventions were used?"
                  className="min-h-[60px]"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="outcome">Outcome</Label>
                <Textarea
                  id="outcome"
                  value={outcome}
                  onChange={(e) => setOutcome(e.target.value)}
                  placeholder="How did the situation resolve? What was the result?"
                  className="min-h-[60px]"
                />
              </div>
            </div>

            {/* Advanced fields toggle */}
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => setShowAdvanced(!showAdvanced)}
              className="text-muted-foreground"
            >
              {showAdvanced ? "Hide" : "Show"} additional details
            </Button>

            {showAdvanced && (
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="duration">Duration</Label>
                  <Textarea
                    id="duration"
                    value={duration}
                    onChange={(e) => setDuration(e.target.value)}
                    placeholder="e.g. 5 minutes, ongoing for 30 mins"
                    className="min-h-[40px]"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="frequency">Frequency</Label>
                  <Textarea
                    id="frequency"
                    value={frequency}
                    onChange={(e) => setFrequency(e.target.value)}
                    placeholder="e.g. 3rd time today, happens daily"
                    className="min-h-[40px]"
                  />
                </div>
              </div>
            )}

            {/* Safeguarding Section */}
            <div className="space-y-4 pt-4 border-t border-border">
              <div className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-amber-500" />
                <h3 className="font-medium text-foreground">Safeguarding Checklist</h3>
              </div>
              
              <div className="space-y-3 bg-secondary/50 rounded-lg p-4">
                {safeguardingChecks.map((check) => (
                  <div key={check.id} className="flex items-start gap-3">
                    <Checkbox
                      id={check.id}
                      checked={safeguardingChecked[check.id] || false}
                      onCheckedChange={(checked) => 
                        setSafeguardingChecked(prev => ({ ...prev, [check.id]: !!checked }))
                      }
                    />
                    <label htmlFor={check.id} className="text-sm text-foreground cursor-pointer">
                      {check.label}
                      {check.required && <span className="text-red-500 ml-1">*</span>}
                    </label>
                  </div>
                ))}
              </div>

              <div className="flex items-start gap-3 p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
                <Checkbox
                  id="safeguarding_concern"
                  checked={safeguardingConcern}
                  onCheckedChange={(checked) => setSafeguardingConcern(!!checked)}
                />
                <div className="flex-1">
                  <label htmlFor="safeguarding_concern" className="text-sm font-medium text-red-500 cursor-pointer flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4" />
                    This is a safeguarding concern
                  </label>
                  <p className="text-xs text-red-400 mt-1">
                    Check this if you have observed signs of abuse, neglect, or the child made a disclosure
                  </p>
                </div>
              </div>

              {safeguardingConcern && (
                <div className="space-y-2">
                  <Label htmlFor="safeguardingNotes" className="text-red-500">
                    Safeguarding Notes (Confidential)
                  </Label>
                  <Textarea
                    id="safeguardingNotes"
                    value={safeguardingNotes}
                    onChange={(e) => setSafeguardingNotes(e.target.value)}
                    placeholder="Record what was observed or disclosed. Use the child's exact words where possible."
                    className="min-h-[80px] border-red-500/50"
                  />
                  <p className="text-xs text-red-400">
                    This will be flagged for immediate review by your Designated Safeguarding Lead.
                  </p>
                </div>
              )}
            </div>

            {error && (
              <p className="text-sm text-red-500 flex items-center gap-2">
                <AlertTriangle className="h-4 w-4" />
                {error}
              </p>
            )}

            <Button type="submit" className="w-full" disabled={isLoading || children.length === 0}>
              {isLoading ? "Saving..." : "Log Observation"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
