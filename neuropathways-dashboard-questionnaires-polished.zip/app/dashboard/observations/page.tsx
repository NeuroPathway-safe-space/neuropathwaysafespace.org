import { createClient } from "@/lib/supabase/server";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { Plus, Calendar, Clock, ArrowLeft } from "lucide-react";

const severityColors: Record<number, string> = {
  1: "bg-emerald-500",
  2: "bg-lime-500",
  3: "bg-amber-500",
  4: "bg-orange-500",
  5: "bg-red-500",
};

export default async function ObservationsPage() {
  const supabase = await createClient();

  const { data: observations } = await supabase
    .from("observations")
    .select(`
      *,
      children (first_name, last_name)
    `)
    .order("observed_at", { ascending: false })
    .limit(50);

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <Link href="/dashboard" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4">
        <ArrowLeft className="h-4 w-4" />
        Back to Dashboard
      </Link>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Observations</h1>
          <p className="text-muted-foreground">All recorded observations</p>
        </div>
        <Link href="/dashboard/observations/new">
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            Log Observation
          </Button>
        </Link>
      </div>

      {observations && observations.length > 0 ? (
        <div className="space-y-3">
          {observations.map((observation) => (
            <Card key={observation.id}>
              <CardContent className="p-4">
                <div className="flex items-start gap-4">
                  <div className={`w-3 h-3 rounded-full mt-1.5 ${severityColors[observation.severity] || "bg-gray-400"}`} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium text-foreground">
                        {observation.children?.first_name} {observation.children?.last_name}
                      </span>
                      <span className="text-xs px-2 py-0.5 rounded-full bg-secondary text-secondary-foreground">
                        {observation.category_name}
                      </span>
                    </div>
                    {observation.notes && (
                      <p className="text-sm text-muted-foreground mb-2">{observation.notes}</p>
                    )}
                    {observation.triggers && (
                      <p className="text-xs text-muted-foreground mb-2">
                        <span className="font-medium">Triggers:</span> {observation.triggers}
                      </p>
                    )}
                    <div className="flex items-center gap-4 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {new Date(observation.observed_at).toLocaleDateString("en-GB")}
                      </span>
                      {observation.time_of_day && (
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {observation.time_of_day}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-muted-foreground mb-4">No observations recorded yet</p>
            <Link href="/dashboard/observations/new">
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Log Your First Observation
              </Button>
            </Link>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
