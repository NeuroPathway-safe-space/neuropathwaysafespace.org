'use client'

import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Progress } from '@/components/ui/progress'
import { Textarea } from '@/components/ui/textarea'
import { 
  Brain, 
  Shield, 
  FileText, 
  Lightbulb, 
  AlertTriangle,
  CheckCircle,
  Clock,
  TrendingUp,
  TrendingDown,
  Minus,
  Play,
  Eye,
  ChevronRight,
  RefreshCw,
  Users,
  Activity
} from 'lucide-react'
import Link from 'next/link'

interface Child {
  id: string
  first_name: string
  last_name?: string
}

interface Assessment {
  id: string
  child_id: string
  assessment_type: string
  status: string
  risk_status: string | null
  risk_score: number | null
  pattern_confidence: number | null
  data_quality_score: number | null
  observation_count: number | null
  created_at: string
  children?: { first_name: string; last_name?: string }
}

interface Review {
  id: string
  reviewable_type: string
  priority: string
  reason: string
  ai_confidence: number | null
  status: string
  created_at: string
  children?: { first_name: string; last_name?: string }
}

interface Alert {
  id: string
  alert_type: string
  severity: string
  description: string
  status: string
  source: string
  created_at: string
  children?: { first_name: string; last_name?: string }
}

interface AIRun {
  id: string
  engine_type: string
  status: string
  confidence_score: number | null
  tokens_used: number | null
  latency_ms: number | null
  created_at: string
}

export default function AIControlCentrePage() {
  const [children, setChildren] = useState<Child[]>([])
  const [selectedChild, setSelectedChild] = useState<string>('')
  const [assessments, setAssessments] = useState<Assessment[]>([])
  const [reviews, setReviews] = useState<Review[]>([])
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [recentRuns, setRecentRuns] = useState<AIRun[]>([])
  const [loading, setLoading] = useState(true)
  const [runningAssessment, setRunningAssessment] = useState(false)
  const [activeTab, setActiveTab] = useState('overview')
  const supabase = createClient()

  useEffect(() => {
    loadData()
  }, [])

  useEffect(() => {
    if (selectedChild) {
      loadChildAssessments(selectedChild)
    }
  }, [selectedChild])

  async function loadData() {
    setLoading(true)
    try {
      // Load children
      const { data: childrenData } = await supabase
        .from('children')
        .select('id, first_name, last_name')
        .order('first_name')

      if (childrenData) {
        setChildren(childrenData)
        if (childrenData.length > 0 && !selectedChild) {
          setSelectedChild(childrenData[0].id)
        }
      }

      // Load pending reviews
      const reviewsRes = await fetch('/api/ai/reviews?status=pending')
      if (reviewsRes.ok) {
        const reviewsData = await reviewsRes.json()
        setReviews(reviewsData)
      }

      // Load active alerts
      const alertsRes = await fetch('/api/ai/alerts')
      if (alertsRes.ok) {
        const alertsData = await alertsRes.json()
        setAlerts(alertsData)
      }

      // Load recent AI runs
      const { data: runsData } = await supabase
        .from('ai_runs')
        .select('id, engine_type, status, confidence_score, tokens_used, latency_ms, created_at')
        .order('created_at', { ascending: false })
        .limit(20)

      if (runsData) {
        setRecentRuns(runsData)
      }
    } catch (error) {
      console.error('Error loading data:', error)
    } finally {
      setLoading(false)
    }
  }

  async function loadChildAssessments(childId: string) {
    const res = await fetch(`/api/ai/assessment?child_id=${childId}`)
    if (res.ok) {
      const data = await res.json()
      setAssessments(data)
    }
  }

  async function runAssessment() {
    if (!selectedChild) return
    setRunningAssessment(true)
    try {
      const res = await fetch('/api/ai/assessment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ child_id: selectedChild })
      })
      if (res.ok) {
        await loadData()
        await loadChildAssessments(selectedChild)
      }
    } catch (error) {
      console.error('Error running assessment:', error)
    } finally {
      setRunningAssessment(false)
    }
  }

  const selectedChildName = children.find(c => c.id === selectedChild)
  const childDisplayName = selectedChildName 
    ? [selectedChildName.first_name, selectedChildName.last_name].filter(Boolean).join(' ')
    : 'Select a child'

  const criticalAlerts = alerts.filter(a => a.severity === 'critical' || a.severity === 'high')
  const pendingReviews = reviews.filter(r => r.status === 'pending')
  const urgentReviews = pendingReviews.filter(r => r.priority === 'urgent' || r.priority === 'high')

  const stats = {
    totalAssessments: assessments.length,
    pendingReviews: pendingReviews.length,
    activeAlerts: alerts.filter(a => a.status !== 'resolved' && a.status !== 'false_positive').length,
    avgConfidence: recentRuns.length > 0 
      ? (recentRuns.reduce((acc, r) => acc + (r.confidence_score || 0), 0) / recentRuns.length * 100).toFixed(0)
      : 0
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="h-8 w-8 animate-spin text-primary mx-auto mb-4" />
          <p className="text-muted-foreground">Loading AI Control Centre...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b">
        <div className="container py-4">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold flex items-center gap-2">
                <Brain className="h-6 w-6 text-primary" />
                AI Control Centre
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Pattern recognition, risk assessment, and evidence mapping
              </p>
            </div>
            <div className="flex items-center gap-3">
              <Select value={selectedChild} onValueChange={setSelectedChild}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Select child" />
                </SelectTrigger>
                <SelectContent>
                  {children.map(child => (
                    <SelectItem key={child.id} value={child.id}>
                      {child.first_name} {child.last_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button 
                onClick={runAssessment} 
                disabled={!selectedChild || runningAssessment}
                className="gap-2"
              >
                {runningAssessment ? (
                  <RefreshCw className="h-4 w-4 animate-spin" />
                ) : (
                  <Play className="h-4 w-4" />
                )}
                Run Assessment
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container py-6">
        {/* Stats Overview */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Assessments</p>
                  <p className="text-2xl font-bold">{stats.totalAssessments}</p>
                </div>
                <FileText className="h-8 w-8 text-muted-foreground/30" />
              </div>
            </CardContent>
          </Card>
          <Card className={pendingReviews.length > 0 ? 'border-amber-500/50' : ''}>
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Pending Reviews</p>
                  <p className="text-2xl font-bold">{stats.pendingReviews}</p>
                </div>
                <Eye className="h-8 w-8 text-muted-foreground/30" />
              </div>
            </CardContent>
          </Card>
          <Card className={criticalAlerts.length > 0 ? 'border-red-500/50' : ''}>
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Active Alerts</p>
                  <p className="text-2xl font-bold">{stats.activeAlerts}</p>
                </div>
                <AlertTriangle className="h-8 w-8 text-muted-foreground/30" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Avg Confidence</p>
                  <p className="text-2xl font-bold">{stats.avgConfidence}%</p>
                </div>
                <Activity className="h-8 w-8 text-muted-foreground/30" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Critical Alerts Banner */}
        {criticalAlerts.length > 0 && (
          <Card className="mb-6 border-red-500 bg-red-500/5">
            <CardContent className="py-4">
              <div className="flex items-center gap-3">
                <AlertTriangle className="h-5 w-5 text-red-500" />
                <div className="flex-1">
                  <p className="font-semibold text-red-500">
                    {criticalAlerts.length} Critical Alert{criticalAlerts.length > 1 ? 's' : ''} Require Attention
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {criticalAlerts[0].description.substring(0, 100)}...
                  </p>
                </div>
                <Link href="/dashboard/safeguarding">
                  <Button variant="destructive" size="sm" className="gap-2">
                    Review Now <ChevronRight className="h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="assessments">Assessments</TabsTrigger>
            <TabsTrigger value="reviews">Reviews ({pendingReviews.length})</TabsTrigger>
            <TabsTrigger value="alerts">Alerts ({stats.activeAlerts})</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Latest Assessment */}
              {assessments.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Latest Assessment</CardTitle>
                    <CardDescription>
                      {childDisplayName} - {new Date(assessments[0].created_at).toLocaleDateString()}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Risk Status</span>
                      <Badge 
                        variant={
                          assessments[0].risk_status === 'green' ? 'default' :
                          assessments[0].risk_status === 'amber' ? 'secondary' : 'destructive'
                        }
                        className={
                          assessments[0].risk_status === 'green' ? 'bg-green-500' :
                          assessments[0].risk_status === 'amber' ? 'bg-amber-500' : ''
                        }
                      >
                        {assessments[0].risk_status?.toUpperCase() || 'N/A'}
                      </Badge>
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm">Pattern Confidence</span>
                        <span className="text-sm font-medium">
                          {((assessments[0].pattern_confidence || 0) * 100).toFixed(0)}%
                        </span>
                      </div>
                      <Progress value={(assessments[0].pattern_confidence || 0) * 100} />
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm">Data Quality</span>
                        <span className="text-sm font-medium">
                          {((assessments[0].data_quality_score || 0) * 100).toFixed(0)}%
                        </span>
                      </div>
                      <Progress value={(assessments[0].data_quality_score || 0) * 100} />
                    </div>
                    <div className="flex items-center justify-between pt-2">
                      <span className="text-sm text-muted-foreground">
                        Based on {assessments[0].observation_count || 0} observations
                      </span>
                      <Link href={`/dashboard/ai/assessment/${assessments[0].id}`}>
                        <Button variant="outline" size="sm" className="gap-1">
                          View Details <ChevronRight className="h-4 w-4" />
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* AI Engines Status */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">AI Engines</CardTitle>
                  <CardDescription>System status and recent activity</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {[
                    { name: 'Pattern Recognition', icon: Brain, color: 'text-blue-500' },
                    { name: 'Risk Stratification', icon: Shield, color: 'text-red-500' },
                    { name: 'EHCP Evidence Mapper', icon: FileText, color: 'text-green-500' },
                    { name: 'Strategy Generator', icon: Lightbulb, color: 'text-amber-500' },
                  ].map(engine => {
                    const recentRun = recentRuns.find(r => 
                      r.engine_type.toLowerCase().includes(engine.name.toLowerCase().split(' ')[0])
                    )
                    return (
                      <div key={engine.name} className="flex items-center justify-between py-2 border-b last:border-0">
                        <div className="flex items-center gap-3">
                          <engine.icon className={`h-5 w-5 ${engine.color}`} />
                          <span className="text-sm">{engine.name}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          {recentRun ? (
                            <>
                              <Badge variant="outline" className="text-xs">
                                {recentRun.latency_ms}ms
                              </Badge>
                              <CheckCircle className="h-4 w-4 text-green-500" />
                            </>
                          ) : (
                            <Badge variant="outline" className="text-xs">Ready</Badge>
                          )}
                        </div>
                      </div>
                    )
                  })}
                </CardContent>
              </Card>
            </div>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Recent AI Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {recentRuns.slice(0, 5).map(run => (
                    <div key={run.id} className="flex items-center justify-between py-2 border-b last:border-0">
                      <div className="flex items-center gap-3">
                        <Badge variant="outline" className="capitalize">
                          {run.engine_type.replace(/_/g, ' ')}
                        </Badge>
                        <span className="text-sm text-muted-foreground">
                          {new Date(run.created_at).toLocaleString()}
                        </span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-sm">
                          {((run.confidence_score || 0) * 100).toFixed(0)}% confidence
                        </span>
                        <Badge 
                          variant={run.status === 'completed' ? 'default' : run.status === 'failed' ? 'destructive' : 'secondary'}
                        >
                          {run.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="assessments" className="space-y-4">
            {assessments.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <Brain className="h-12 w-12 mx-auto text-muted-foreground/30 mb-4" />
                  <h3 className="font-semibold mb-2">No Assessments Yet</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Run your first AI assessment to analyze patterns and generate insights.
                  </p>
                  <Button onClick={runAssessment} disabled={!selectedChild || runningAssessment}>
                    Run First Assessment
                  </Button>
                </CardContent>
              </Card>
            ) : (
              assessments.map(assessment => (
                <Card key={assessment.id}>
                  <CardContent className="py-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <Badge 
                          variant={
                            assessment.risk_status === 'green' ? 'default' :
                            assessment.risk_status === 'amber' ? 'secondary' : 'destructive'
                          }
                          className={
                            assessment.risk_status === 'green' ? 'bg-green-500' :
                            assessment.risk_status === 'amber' ? 'bg-amber-500' : ''
                          }
                        >
                          {assessment.risk_status?.toUpperCase() || 'N/A'}
                        </Badge>
                        <div>
                          <p className="font-medium capitalize">{assessment.assessment_type} Assessment</p>
                          <p className="text-sm text-muted-foreground">
                            {new Date(assessment.created_at).toLocaleDateString()} - {assessment.observation_count} observations
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <p className="text-sm">
                            {((assessment.pattern_confidence || 0) * 100).toFixed(0)}% confidence
                          </p>
                          <Badge variant={assessment.status === 'approved' ? 'default' : 'secondary'}>
                            {assessment.status}
                          </Badge>
                        </div>
                        <Link href={`/dashboard/ai/assessment/${assessment.id}`}>
                          <Button variant="outline" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                        </Link>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>

          <TabsContent value="reviews" className="space-y-4">
            {pendingReviews.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <CheckCircle className="h-12 w-12 mx-auto text-green-500/30 mb-4" />
                  <h3 className="font-semibold mb-2">All Caught Up!</h3>
                  <p className="text-sm text-muted-foreground">
                    No pending reviews at the moment.
                  </p>
                </CardContent>
              </Card>
            ) : (
              pendingReviews.map(review => (
                <Card key={review.id} className={review.priority === 'urgent' ? 'border-red-500/50' : ''}>
                  <CardContent className="py-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <Badge 
                          variant={review.priority === 'urgent' ? 'destructive' : review.priority === 'high' ? 'secondary' : 'outline'}
                        >
                          {review.priority}
                        </Badge>
                        <div>
                          <p className="font-medium capitalize">{review.reviewable_type} Review</p>
                          <p className="text-sm text-muted-foreground">
                            {review.children?.first_name} {review.children?.last_name} - {review.reason}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-sm text-muted-foreground">
                          {((review.ai_confidence || 0) * 100).toFixed(0)}% AI confidence
                        </span>
                        <Link href={`/dashboard/ai/review/${review.id}`}>
                          <Button variant="outline" size="sm" className="gap-1">
                            Review <ChevronRight className="h-4 w-4" />
                          </Button>
                        </Link>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>

          <TabsContent value="alerts" className="space-y-4">
            {alerts.filter(a => a.status !== 'resolved' && a.status !== 'false_positive').length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <Shield className="h-12 w-12 mx-auto text-green-500/30 mb-4" />
                  <h3 className="font-semibold mb-2">No Active Alerts</h3>
                  <p className="text-sm text-muted-foreground">
                    All safeguarding alerts have been reviewed.
                  </p>
                </CardContent>
              </Card>
            ) : (
              alerts
                .filter(a => a.status !== 'resolved' && a.status !== 'false_positive')
                .map(alert => (
                  <Card 
                    key={alert.id} 
                    className={
                      alert.severity === 'critical' ? 'border-red-500' :
                      alert.severity === 'high' ? 'border-orange-500/50' : ''
                    }
                  >
                    <CardContent className="py-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <AlertTriangle className={
                            alert.severity === 'critical' ? 'h-5 w-5 text-red-500' :
                            alert.severity === 'high' ? 'h-5 w-5 text-orange-500' :
                            'h-5 w-5 text-amber-500'
                          } />
                          <div>
                            <p className="font-medium">{alert.alert_type}</p>
                            <p className="text-sm text-muted-foreground">
                              {alert.children?.first_name} {alert.children?.last_name} - {alert.description.substring(0, 80)}...
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Badge variant="outline" className="capitalize">
                            {alert.source.replace(/_/g, ' ')}
                          </Badge>
                          <Badge 
                            variant={
                              alert.severity === 'critical' ? 'destructive' :
                              alert.severity === 'high' ? 'secondary' : 'outline'
                            }
                          >
                            {alert.severity}
                          </Badge>
                          <Link href={`/dashboard/safeguarding?alert=${alert.id}`}>
                            <Button 
                              variant={alert.severity === 'critical' ? 'destructive' : 'outline'} 
                              size="sm"
                            >
                              Review
                            </Button>
                          </Link>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
            )}
          </TabsContent>

          <TabsContent value="activity" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">AI Run History</CardTitle>
                <CardDescription>Last 20 AI engine executions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {recentRuns.map(run => (
                    <div key={run.id} className="flex items-center justify-between py-3 border-b last:border-0">
                      <div className="flex items-center gap-4">
                        <Badge variant="outline" className="capitalize min-w-32">
                          {run.engine_type.replace(/_/g, ' ')}
                        </Badge>
                        <span className="text-sm text-muted-foreground">
                          {new Date(run.created_at).toLocaleString()}
                        </span>
                      </div>
                      <div className="flex items-center gap-4">
                        <span className="text-sm">
                          {((run.confidence_score || 0) * 100).toFixed(0)}%
                        </span>
                        <span className="text-sm text-muted-foreground">
                          {run.latency_ms}ms
                        </span>
                        <span className="text-sm text-muted-foreground">
                          {run.tokens_used || 0} tokens
                        </span>
                        <Badge 
                          variant={
                            run.status === 'completed' ? 'default' : 
                            run.status === 'failed' ? 'destructive' : 
                            'secondary'
                          }
                        >
                          {run.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
