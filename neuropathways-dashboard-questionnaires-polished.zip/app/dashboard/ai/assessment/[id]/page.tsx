'use client'

import { useState, useEffect, use } from 'react'
import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Progress } from '@/components/ui/progress'
import { 
  Brain, 
  Shield, 
  FileText, 
  Lightbulb, 
  AlertTriangle,
  CheckCircle,
  TrendingUp,
  TrendingDown,
  Minus,
  ArrowLeft,
  Download,
  Clock,
  MapPin,
  Target,
  BookOpen
} from 'lucide-react'
import Link from 'next/link'

interface PageProps {
  params: Promise<{ id: string }>
}

interface Pattern {
  id: string
  domain: string
  pattern_name: string
  description: string
  frequency: string
  severity: string
  triggers: string[]
  protective_factors: string[]
  settings: string[]
  confidence_score: number
  evidence_count: number
  trend: string
}

interface Strategy {
  id: string
  domain: string
  strategy_name: string
  description: string
  implementation_steps: string[]
  target_setting: string
  evidence_base: string
  priority: string
  status: string
}

interface Assessment {
  id: string
  child_id: string
  assessment_type: string
  status: string
  risk_status: string | null
  risk_reasoning: string | null
  risk_score: number | null
  pattern_confidence: number | null
  patterns: Pattern[] | null
  cross_setting_consistency: unknown | null
  data_quality_score: number | null
  data_quality_issues: unknown | null
  safeguarding_flags: unknown[] | null
  requires_escalation: boolean
  summary: string | null
  key_findings: unknown | null
  recommended_actions: unknown | null
  observation_count: number | null
  date_range_start: string | null
  date_range_end: string | null
  settings_included: string[] | null
  created_at: string
  ai_patterns: Pattern[]
  ai_strategies: Strategy[]
  children?: { first_name: string; last_name?: string }
}

const trendIcon = (trend: string) => {
  switch (trend) {
    case 'improving':
      return <TrendingUp className="h-4 w-4 text-green-500" />
    case 'worsening':
      return <TrendingDown className="h-4 w-4 text-red-500" />
    default:
      return <Minus className="h-4 w-4 text-muted-foreground" />
  }
}

const severityColor = (severity: string) => {
  switch (severity) {
    case 'severe':
      return 'text-red-500 bg-red-500/10'
    case 'significant':
      return 'text-orange-500 bg-orange-500/10'
    case 'moderate':
      return 'text-amber-500 bg-amber-500/10'
    default:
      return 'text-green-500 bg-green-500/10'
  }
}

const frequencyLabel = (freq: string) => {
  const labels: Record<string, string> = {
    rare: '< 1x/week',
    occasional: '1-2x/week',
    frequent: '3-5x/week',
    very_frequent: 'Daily',
    constant: 'Multiple times daily'
  }
  return labels[freq] || freq
}

export default function AssessmentDetailPage({ params }: PageProps) {
  const { id } = use(params)
  const [assessment, setAssessment] = useState<Assessment | null>(null)
  const [loading, setLoading] = useState(true)
  const supabase = createClient()

  useEffect(() => {
    loadAssessment()
  }, [id])

  async function loadAssessment() {
    setLoading(true)
    try {
      const { data, error } = await supabase
        .from('ai_assessments')
        .select(`
          *,
          ai_patterns(*),
          ai_strategies(*),
          children(first_name, last_name)
        `)
        .eq('id', id)
        .single()

      if (data) {
        setAssessment(data)
      }
    } catch (error) {
      console.error('Error loading assessment:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Brain className="h-8 w-8 animate-pulse text-primary mx-auto mb-4" />
          <p className="text-muted-foreground">Loading assessment...</p>
        </div>
      </div>
    )
  }

  if (!assessment) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card>
          <CardContent className="py-8 text-center">
            <AlertTriangle className="h-12 w-12 mx-auto text-muted-foreground/30 mb-4" />
            <h3 className="font-semibold mb-2">Assessment Not Found</h3>
            <Link href="/dashboard/ai">
              <Button variant="outline">Back to AI Control Centre</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  const childName = assessment.children 
    ? [assessment.children.first_name, assessment.children.last_name].filter(Boolean).join(' ')
    : 'Unknown Child'

  const patterns = assessment.ai_patterns || []
  const strategies = assessment.ai_strategies || []

  // Group patterns by domain
  const patternsByDomain = patterns.reduce((acc, p) => {
    if (!acc[p.domain]) acc[p.domain] = []
    acc[p.domain].push(p)
    return acc
  }, {} as Record<string, Pattern[]>)

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b">
        <div className="container py-4">
          <div className="flex items-center gap-4 mb-4">
            <Link href="/dashboard/ai">
              <Button variant="ghost" size="sm" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                Back
              </Button>
            </Link>
          </div>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold flex items-center gap-2">
                <Brain className="h-6 w-6 text-primary" />
                AI Assessment for {childName}
              </h1>
              <p className="text-sm text-muted-foreground mt-1 flex items-center gap-4">
                <span className="flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  {new Date(assessment.created_at).toLocaleDateString()}
                </span>
                <span>
                  {assessment.date_range_start && assessment.date_range_end && (
                    <>Data from {assessment.date_range_start} to {assessment.date_range_end}</>
                  )}
                </span>
              </p>
            </div>
            <div className="flex items-center gap-3">
              <Badge 
                variant={
                  assessment.risk_status === 'green' ? 'default' :
                  assessment.risk_status === 'amber' ? 'secondary' : 'destructive'
                }
                className={`text-sm ${
                  assessment.risk_status === 'green' ? 'bg-green-500' :
                  assessment.risk_status === 'amber' ? 'bg-amber-500' : ''
                }`}
              >
                {assessment.risk_status?.toUpperCase() || 'N/A'} Risk
              </Badge>
              <Badge variant={assessment.status === 'approved' ? 'default' : 'secondary'}>
                {assessment.status}
              </Badge>
              <Button variant="outline" className="gap-2">
                <Download className="h-4 w-4" />
                Export
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container py-6">
        {/* Overview Cards */}
        <div className="grid md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-4">
              <p className="text-sm text-muted-foreground">Observations Analyzed</p>
              <p className="text-3xl font-bold">{assessment.observation_count || 0}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <p className="text-sm text-muted-foreground">Patterns Identified</p>
              <p className="text-3xl font-bold">{patterns.length}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <p className="text-sm text-muted-foreground">Pattern Confidence</p>
              <p className="text-3xl font-bold">
                {((assessment.pattern_confidence || 0) * 100).toFixed(0)}%
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <p className="text-sm text-muted-foreground">Data Quality</p>
              <p className="text-3xl font-bold">
                {((assessment.data_quality_score || 0) * 100).toFixed(0)}%
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Risk Alert */}
        {assessment.risk_status !== 'green' && (
          <Card className={`mb-6 ${assessment.risk_status === 'red' ? 'border-red-500 bg-red-500/5' : 'border-amber-500 bg-amber-500/5'}`}>
            <CardContent className="py-4">
              <div className="flex items-start gap-3">
                <Shield className={`h-5 w-5 mt-0.5 ${assessment.risk_status === 'red' ? 'text-red-500' : 'text-amber-500'}`} />
                <div>
                  <p className={`font-semibold ${assessment.risk_status === 'red' ? 'text-red-500' : 'text-amber-500'}`}>
                    {assessment.risk_status === 'red' ? 'High Risk - Escalation Required' : 'Moderate Risk - Review Recommended'}
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">
                    {assessment.risk_reasoning || 'Risk factors detected in behavioral patterns.'}
                  </p>
                  {assessment.safeguarding_flags && (assessment.safeguarding_flags as unknown[]).length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-2">
                      {(assessment.safeguarding_flags as { type: string }[]).map((flag, i) => (
                        <Badge key={i} variant="outline" className="text-xs">
                          {flag.type || 'Concern flagged'}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <Tabs defaultValue="patterns">
          <TabsList className="mb-6">
            <TabsTrigger value="patterns">Patterns ({patterns.length})</TabsTrigger>
            <TabsTrigger value="strategies">Strategies ({strategies.length})</TabsTrigger>
            <TabsTrigger value="ehcp">EHCP Mapping</TabsTrigger>
            <TabsTrigger value="data">Data Quality</TabsTrigger>
          </TabsList>

          <TabsContent value="patterns" className="space-y-6">
            {Object.entries(patternsByDomain).map(([domain, domainPatterns]) => (
              <Card key={domain}>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Brain className="h-5 w-5 text-primary" />
                    {domain}
                  </CardTitle>
                  <CardDescription>
                    {domainPatterns.length} pattern{domainPatterns.length > 1 ? 's' : ''} identified
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {domainPatterns.map(pattern => (
                    <div key={pattern.id} className="border rounded-lg p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h4 className="font-semibold flex items-center gap-2">
                            {pattern.pattern_name}
                            {trendIcon(pattern.trend)}
                          </h4>
                          <p className="text-sm text-muted-foreground">{pattern.description}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge className={severityColor(pattern.severity)}>
                            {pattern.severity}
                          </Badge>
                          <Badge variant="outline">
                            {((pattern.confidence_score || 0) * 100).toFixed(0)}%
                          </Badge>
                        </div>
                      </div>

                      <div className="grid md:grid-cols-3 gap-4 text-sm">
                        <div>
                          <p className="font-medium text-muted-foreground mb-1">Frequency</p>
                          <p>{frequencyLabel(pattern.frequency)}</p>
                        </div>
                        <div>
                          <p className="font-medium text-muted-foreground mb-1">Evidence Count</p>
                          <p>{pattern.evidence_count} observations</p>
                        </div>
                        <div>
                          <p className="font-medium text-muted-foreground mb-1">Settings</p>
                          <p>{pattern.settings?.join(', ') || 'Various'}</p>
                        </div>
                      </div>

                      {pattern.triggers && pattern.triggers.length > 0 && (
                        <div className="mt-3">
                          <p className="font-medium text-sm text-muted-foreground mb-1">Triggers</p>
                          <div className="flex flex-wrap gap-1">
                            {pattern.triggers.map((t, i) => (
                              <Badge key={i} variant="outline" className="text-xs bg-red-500/5">
                                {t}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}

                      {pattern.protective_factors && pattern.protective_factors.length > 0 && (
                        <div className="mt-3">
                          <p className="font-medium text-sm text-muted-foreground mb-1">Protective Factors</p>
                          <div className="flex flex-wrap gap-1">
                            {pattern.protective_factors.map((f, i) => (
                              <Badge key={i} variant="outline" className="text-xs bg-green-500/5">
                                {f}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </CardContent>
              </Card>
            ))}

            {patterns.length === 0 && (
              <Card>
                <CardContent className="py-12 text-center">
                  <Brain className="h-12 w-12 mx-auto text-muted-foreground/30 mb-4" />
                  <h3 className="font-semibold mb-2">No Patterns Identified</h3>
                  <p className="text-sm text-muted-foreground">
                    More observations may be needed to identify patterns.
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="strategies" className="space-y-4">
            {strategies.map(strategy => (
              <Card key={strategy.id}>
                <CardContent className="py-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-start gap-3">
                      <Lightbulb className={`h-5 w-5 mt-0.5 ${
                        strategy.priority === 'high' ? 'text-red-500' :
                        strategy.priority === 'medium' ? 'text-amber-500' : 'text-green-500'
                      }`} />
                      <div>
                        <h4 className="font-semibold">{strategy.strategy_name}</h4>
                        <p className="text-sm text-muted-foreground">{strategy.description}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={
                        strategy.priority === 'high' ? 'destructive' :
                        strategy.priority === 'medium' ? 'secondary' : 'outline'
                      }>
                        {strategy.priority} priority
                      </Badge>
                      <Badge variant="outline">
                        {strategy.status}
                      </Badge>
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4 mt-4">
                    <div>
                      <p className="font-medium text-sm flex items-center gap-2 mb-2">
                        <Target className="h-4 w-4" />
                        Implementation Steps
                      </p>
                      <ol className="text-sm space-y-1 list-decimal list-inside">
                        {strategy.implementation_steps?.map((step, i) => (
                          <li key={i} className="text-muted-foreground">{step}</li>
                        ))}
                      </ol>
                    </div>
                    <div>
                      <p className="font-medium text-sm flex items-center gap-2 mb-2">
                        <BookOpen className="h-4 w-4" />
                        Evidence Base
                      </p>
                      <p className="text-sm text-muted-foreground">{strategy.evidence_base}</p>
                      <p className="text-sm mt-2">
                        <span className="text-muted-foreground">Target setting:</span>{' '}
                        <Badge variant="outline">{strategy.target_setting}</Badge>
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

            {strategies.length === 0 && (
              <Card>
                <CardContent className="py-12 text-center">
                  <Lightbulb className="h-12 w-12 mx-auto text-muted-foreground/30 mb-4" />
                  <h3 className="font-semibold mb-2">No Strategies Generated</h3>
                  <p className="text-sm text-muted-foreground">
                    Strategies are generated based on identified patterns.
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="ehcp" className="space-y-4">
            {['Communication & Interaction', 'Cognition & Learning', 'Social, Emotional & Mental Health', 'Sensory & Physical'].map(area => {
              const areaPatterns = patterns.filter(p => 
                p.domain.toLowerCase().includes(area.split(' ')[0].toLowerCase()) ||
                p.domain.toLowerCase().includes(area.split(',')[0].toLowerCase())
              )
              return (
                <Card key={area}>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <FileText className="h-5 w-5 text-primary" />
                      {area}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {areaPatterns.length > 0 ? (
                      <div className="space-y-3">
                        {areaPatterns.map(p => (
                          <div key={p.id} className="flex items-center justify-between py-2 border-b last:border-0">
                            <div>
                              <p className="font-medium">{p.pattern_name}</p>
                              <p className="text-sm text-muted-foreground">{p.evidence_count} supporting observations</p>
                            </div>
                            <Badge className={severityColor(p.severity)}>
                              {p.severity}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-sm text-muted-foreground py-4 text-center">
                        No evidence mapped to this area yet. More observations may be needed.
                      </p>
                    )}
                  </CardContent>
                </Card>
              )
            })}
          </TabsContent>

          <TabsContent value="data" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Data Quality Analysis</CardTitle>
                <CardDescription>
                  Assessment of the evidence base quality
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span>Overall Quality Score</span>
                    <span className="font-bold">{((assessment.data_quality_score || 0) * 100).toFixed(0)}%</span>
                  </div>
                  <Progress value={(assessment.data_quality_score || 0) * 100} />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-medium mb-2">Observation Count</h4>
                    <p className="text-2xl font-bold">{assessment.observation_count || 0}</p>
                    <p className="text-sm text-muted-foreground">
                      {(assessment.observation_count || 0) >= 20 ? 'Good sample size' : 
                       (assessment.observation_count || 0) >= 10 ? 'Moderate sample size' : 
                       'Limited data - more observations recommended'}
                    </p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-medium mb-2">Settings Covered</h4>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {assessment.settings_included?.map((s, i) => (
                        <Badge key={i} variant="outline" className="capitalize">
                          <MapPin className="h-3 w-3 mr-1" />
                          {s}
                        </Badge>
                      ))}
                      {(!assessment.settings_included || assessment.settings_included.length === 0) && (
                        <p className="text-sm text-muted-foreground">No settings recorded</p>
                      )}
                    </div>
                  </div>
                </div>

                <div className="p-4 border rounded-lg">
                  <h4 className="font-medium mb-2">Recommendations</h4>
                  <ul className="text-sm space-y-2">
                    {(assessment.observation_count || 0) < 20 && (
                      <li className="flex items-start gap-2">
                        <AlertTriangle className="h-4 w-4 text-amber-500 mt-0.5" />
                        <span>Add more observations for higher confidence analysis</span>
                      </li>
                    )}
                    {(!assessment.settings_included || assessment.settings_included.length < 2) && (
                      <li className="flex items-start gap-2">
                        <AlertTriangle className="h-4 w-4 text-amber-500 mt-0.5" />
                        <span>Record observations from multiple settings for cross-setting comparison</span>
                      </li>
                    )}
                    {(assessment.data_quality_score || 0) >= 0.8 && (
                      <li className="flex items-start gap-2">
                        <CheckCircle className="h-4 w-4 text-green-500 mt-0.5" />
                        <span>Data quality is sufficient for reliable analysis</span>
                      </li>
                    )}
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
