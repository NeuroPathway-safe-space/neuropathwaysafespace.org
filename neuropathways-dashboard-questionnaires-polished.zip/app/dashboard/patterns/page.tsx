import { createClient } from "@/lib/supabase/server";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { TrendingUp, Clock, AlertTriangle, Calendar, ArrowLeft, Heart, ShieldCheck } from "lucide-react";
import Link from "next/link";

interface PatternData {
  category_name: string;
  count: number;
  avg_severity: number;
}

interface TimePattern {
  time_of_day: string;
  count: number;
}

export default async function PatternsPage() {
  const supabase = await createClient();

  // Get all observations
  const { data: observations } = await supabase
    .from("observations")
    .select(`
      *,
      children (first_name, last_name)
    `)
    .order("observed_at", { ascending: false });

  // Get children for filter
  const { data: children } = await supabase
    .from("children")
    .select("id, first_name, last_name");

  // Safe Space wellbeing summaries (cross-boundary). These are AI-generated
  // SUMMARIES + trends only - raw journal text never crosses into this view.
  const { data: wellbeingSummaries } = await supabase
    .from("pattern_analysis")
    .select(`
      id, summary, trend, frequency, severity, evidence_count,
      period_start, period_end, source, created_at,
      children (first_name, last_name)
    `)
    .order("created_at", { ascending: false })
    .limit(12);

  // Calculate patterns
  const categoryPatterns: Record<string, { count: number; totalSeverity: number }> = {};
  const timePatterns: Record<string, number> = {};
  const triggerPatterns: Record<string, number> = {};
  const weeklyData: Record<string, number> = {};

  observations?.forEach((obs) => {
    // Category patterns
    if (!categoryPatterns[obs.category_name]) {
      categoryPatterns[obs.category_name] = { count: 0, totalSeverity: 0 };
    }
    categoryPatterns[obs.category_name].count++;
    categoryPatterns[obs.category_name].totalSeverity += obs.severity;

    // Time patterns
    if (obs.time_of_day) {
      timePatterns[obs.time_of_day] = (timePatterns[obs.time_of_day] || 0) + 1;
    }

    // Trigger patterns (simple word extraction)
    if (obs.triggers) {
      const words = obs.triggers.toLowerCase().split(/[\s,]+/);
      words.forEach((word: string) => {
        if (word.length > 3) {
          triggerPatterns[word] = (triggerPatterns[word] || 0) + 1;
        }
      });
    }

    // Weekly data
    const date = new Date(obs.observed_at);
    const weekKey = `${date.getFullYear()}-W${Math.ceil((date.getDate() + new Date(date.getFullYear(), date.getMonth(), 1).getDay()) / 7)}`;
    weeklyData[weekKey] = (weeklyData[weekKey] || 0) + 1;
  });

  // Sort and format patterns
  const sortedCategories = Object.entries(categoryPatterns)
    .map(([name, data]) => ({
      name,
      count: data.count,
      avgSeverity: Math.round((data.totalSeverity / data.count) * 10) / 10,
    }))
    .sort((a, b) => b.count - a.count);

  const sortedTimes = Object.entries(timePatterns)
    .map(([time, count]) => ({ time, count }))
    .sort((a, b) => b.count - a.count);

  const sortedTriggers = Object.entries(triggerPatterns)
    .map(([trigger, count]) => ({ trigger, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);

  const totalObservations = observations?.length || 0;
  const avgSeverity = observations?.length
    ? Math.round((observations.reduce((sum, o) => sum + o.severity, 0) / observations.length) * 10) / 10
    : 0;

  const severityColor = (severity: number) => {
    if (severity <= 2) return "text-emerald-500";
    if (severity <= 3) return "text-amber-500";
    return "text-red-500";
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      <Link href="/dashboard" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4">
        <ArrowLeft className="h-4 w-4" />
        Back to Dashboard
      </Link>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">Pattern Recognition</h1>
        <p className="text-muted-foreground">
          Understand behaviours over time - this becomes evidence for EHCPs
        </p>
      </div>

      {wellbeingSummaries && wellbeingSummaries.length > 0 && (
        <Card className="mb-6 border-cyan-500/30 bg-cyan-500/5">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Heart className="h-5 w-5 text-cyan-500" />
              Safe Space Wellbeing Summaries
            </CardTitle>
            <CardDescription className="flex items-center gap-1.5">
              <ShieldCheck className="h-3.5 w-3.5" />
              AI-generated summaries and trends from the child&apos;s self-reported
              wellbeing. Raw journal entries remain private and are never shown here.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3 md:grid-cols-2">
              {wellbeingSummaries.map((s) => {
                const child = Array.isArray(s.children) ? s.children[0] : s.children;
                const trendColor =
                  s.trend === "declining"
                    ? "text-red-500"
                    : s.trend === "monitor"
                      ? "text-amber-500"
                      : "text-emerald-500";
                return (
                  <div key={s.id} className="rounded-lg border border-border bg-background/50 p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-foreground">
                        {child ? `${child.first_name} ${child.last_name}` : "Unlinked profile"}
                      </span>
                      <span className={`text-xs font-medium uppercase tracking-wide ${trendColor}`}>
                        {s.trend ?? "n/a"}
                      </span>
                    </div>
                    <p className="text-sm text-foreground/90 text-pretty leading-relaxed">{s.summary}</p>
                    <div className="flex flex-wrap gap-2 mt-3 text-xs text-muted-foreground">
                      {s.frequency && (
                        <span className="px-2 py-0.5 rounded-full bg-secondary">{s.frequency}</span>
                      )}
                      <span className="px-2 py-0.5 rounded-full bg-secondary">
                        {s.evidence_count} data points
                      </span>
                      {s.source && (
                        <span className="px-2 py-0.5 rounded-full bg-secondary">{s.source}</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {totalObservations === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <TrendingUp className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium text-foreground mb-2">No patterns yet</h3>
            <p className="text-muted-foreground">
              Start logging observations to see patterns emerge over time
            </p>
          </CardContent>
        </Card>
      ) : (
        <>
          {/* Overview Stats */}
          <div className="grid gap-4 md:grid-cols-3 mb-6">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <TrendingUp className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-foreground">{totalObservations}</p>
                    <p className="text-sm text-muted-foreground">Total Observations</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center">
                    <AlertTriangle className="h-5 w-5 text-amber-500" />
                  </div>
                  <div>
                    <p className={`text-2xl font-bold ${severityColor(avgSeverity)}`}>{avgSeverity}</p>
                    <p className="text-sm text-muted-foreground">Average Severity</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-cyan-500/10 flex items-center justify-center">
                    <Calendar className="h-5 w-5 text-cyan-500" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-foreground">{sortedCategories.length}</p>
                    <p className="text-sm text-muted-foreground">Categories Logged</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            {/* Category Frequency */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Behaviour Categories</CardTitle>
                <CardDescription>Frequency of each observation type</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {sortedCategories.map((cat) => (
                    <div key={cat.name} className="flex items-center gap-3">
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm font-medium text-foreground">{cat.name}</span>
                          <span className="text-sm text-muted-foreground">{cat.count}x</span>
                        </div>
                        <div className="h-2 bg-secondary rounded-full overflow-hidden">
                          <div
                            className="h-full bg-primary rounded-full"
                            style={{ width: `${(cat.count / totalObservations) * 100}%` }}
                          />
                        </div>
                      </div>
                      <span className={`text-sm font-medium ${severityColor(cat.avgSeverity)}`}>
                        {cat.avgSeverity}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Time of Day Patterns */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Time Patterns</CardTitle>
                <CardDescription>When behaviours occur most</CardDescription>
              </CardHeader>
              <CardContent>
                {sortedTimes.length > 0 ? (
                  <div className="space-y-3">
                    {sortedTimes.map((time) => (
                      <div key={time.time} className="flex items-center gap-3">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-sm font-medium text-foreground">{time.time}</span>
                            <span className="text-sm text-muted-foreground">{time.count}x</span>
                          </div>
                          <div className="h-2 bg-secondary rounded-full overflow-hidden">
                            <div
                              className="h-full bg-cyan-500 rounded-full"
                              style={{ width: `${(time.count / totalObservations) * 100}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-muted-foreground text-sm">No time data recorded yet</p>
                )}
              </CardContent>
            </Card>

            {/* Common Triggers */}
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle className="text-lg">Common Triggers</CardTitle>
                <CardDescription>
                  Words frequently mentioned in trigger notes - helps identify patterns
                </CardDescription>
              </CardHeader>
              <CardContent>
                {sortedTriggers.length > 0 ? (
                  <div className="flex flex-wrap gap-2">
                    {sortedTriggers.map((trigger) => (
                      <span
                        key={trigger.trigger}
                        className="px-3 py-1.5 rounded-full bg-secondary text-secondary-foreground text-sm"
                      >
                        {trigger.trigger} ({trigger.count})
                      </span>
                    ))}
                  </div>
                ) : (
                  <p className="text-muted-foreground text-sm">
                    Add trigger information to observations to see patterns here
                  </p>
                )}
              </CardContent>
            </Card>

            {/* Example Insight */}
            {sortedCategories.length > 0 && sortedTimes.length > 0 && (
              <Card className="md:col-span-2 border-primary/30 bg-primary/5">
                <CardHeader>
                  <CardTitle className="text-lg text-primary">Generated Insight</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-foreground italic">
                    &ldquo;{sortedCategories[0]?.name} observed {sortedCategories[0]?.count} times over the
                    recorded period, most frequently during {sortedTimes[0]?.time?.toLowerCase() || "the day"}.
                    Average severity level: {sortedCategories[0]?.avgSeverity}/5.&rdquo;
                  </p>
                  <p className="text-sm text-muted-foreground mt-2">
                    This type of insight helps answer the question: &ldquo;What evidence shows this is a persistent need?&rdquo;
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </>
      )}
    </div>
  );
}
