"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { ArrowLeft, CheckCircle, XCircle, Clock, AlertCircle } from "lucide-react";
import Link from "next/link";

interface Child {
  id: string;
  first_name: string;
  last_name: string | null;
}

const outcomes = [
  { value: "ongoing", label: "Ongoing", icon: Clock, color: "text-cyan-500", bg: "bg-cyan-500/10" },
  { value: "successful", label: "Successful", icon: CheckCircle, color: "text-emerald-500", bg: "bg-emerald-500/10" },
  { value: "partial", label: "Partial", icon: AlertCircle, color: "text-amber-500", bg: "bg-amber-500/10" },
  { value: "unsuccessful", label: "Unsuccessful", icon: XCircle, color: "text-red-500", bg: "bg-red-500/10" },
];

export default function NewInterventionPage() {
  const router = useRouter();
  const [children, setChildren] = useState<Child[]>([]);
  const [selectedChild, setSelectedChild] = useState<string>("");
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [outcome, setOutcome] = useState("ongoing");
  const [notes, setNotes] = useState("");
  const [startedAt, setStartedAt] = useState("");
  const [endedAt, setEndedAt] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadChildren() {
      const supabase = createClient();
      const { data } = await supabase.from("children").select("id, first_name, last_name").order("first_name");
      if (data) setChildren(data);
    }
    loadChildren();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedChild || !name) {
      setError("Please select a child and enter an intervention name");
      return;
    }

    setIsLoading(true);
    setError(null);

    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      setError("You must be logged in");
      setIsLoading(false);
      return;
    }

    const { error: insertError } = await supabase.from("interventions").insert({
      user_id: user.id,
      child_id: selectedChild,
      name,
      description: description || null,
      outcome,
      notes: notes || null,
      started_at: startedAt || null,
      ended_at: endedAt || null,
    });

    if (insertError) {
      setError(insertError.message);
      setIsLoading(false);
      return;
    }

    router.push("/dashboard/interventions");
    router.refresh();
  };

  return (
    <div className="max-w-xl mx-auto px-4 py-6">
      <Link href="/dashboard/interventions" className="flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6">
        <ArrowLeft className="h-4 w-4" />
        Back to Interventions
      </Link>

      <Card>
        <CardHeader>
          <CardTitle>Add Intervention</CardTitle>
          <CardDescription>
            Record a strategy or support that has been tried
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Child Selection */}
            <div className="space-y-2">
              <Label>Select Child *</Label>
              {children.length === 0 ? (
                <div className="text-center py-4">
                  <p className="text-muted-foreground text-sm mb-2">No children added yet</p>
                  <Link href="/dashboard/children/new">
                    <Button variant="outline" size="sm">Add a Child First</Button>
                  </Link>
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-2">
                  {children.map((child) => (
                    <button
                      key={child.id}
                      type="button"
                      onClick={() => setSelectedChild(child.id)}
                      className={`p-3 rounded-lg border-2 text-left transition-all ${
                        selectedChild === child.id
                          ? "border-primary bg-primary/10"
                          : "border-border hover:border-primary/50"
                      }`}
                    >
                      <span className="font-medium text-foreground">
                        {child.first_name} {child.last_name}
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="grid gap-2">
              <Label htmlFor="name">Intervention Name *</Label>
              <Input
                id="name"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g., Visual timetable, Movement breaks, Quiet space"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="What does this intervention involve?"
                className="min-h-[80px]"
              />
            </div>

            {/* Outcome Selection */}
            <div className="space-y-2">
              <Label>Outcome</Label>
              <div className="grid grid-cols-2 gap-2">
                {outcomes.map((o) => {
                  const Icon = o.icon;
                  return (
                    <button
                      key={o.value}
                      type="button"
                      onClick={() => setOutcome(o.value)}
                      className={`flex items-center gap-2 p-3 rounded-lg border-2 transition-all ${
                        outcome === o.value
                          ? "border-primary bg-primary/10"
                          : "border-border hover:border-primary/50"
                      }`}
                    >
                      <Icon className={`h-4 w-4 ${o.color}`} />
                      <span className="font-medium text-foreground text-sm">{o.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="notes">Notes / Observations</Label>
              <Textarea
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="How did it go? Any observations about effectiveness?"
                className="min-h-[80px]"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="startedAt">Start Date</Label>
                <Input
                  id="startedAt"
                  type="date"
                  value={startedAt}
                  onChange={(e) => setStartedAt(e.target.value)}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="endedAt">End Date</Label>
                <Input
                  id="endedAt"
                  type="date"
                  value={endedAt}
                  onChange={(e) => setEndedAt(e.target.value)}
                />
              </div>
            </div>

            {error && <p className="text-sm text-red-500">{error}</p>}

            <Button type="submit" className="w-full" disabled={isLoading || children.length === 0}>
              {isLoading ? "Saving..." : "Add Intervention"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
