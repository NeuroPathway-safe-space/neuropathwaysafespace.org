import { createClient } from "@/lib/supabase/server";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { Plus, CheckCircle, XCircle, Clock, AlertCircle, ArrowLeft } from "lucide-react";

const outcomeConfig = {
  successful: { icon: CheckCircle, color: "text-emerald-500", bg: "bg-emerald-500/10", label: "Successful" },
  unsuccessful: { icon: XCircle, color: "text-red-500", bg: "bg-red-500/10", label: "Unsuccessful" },
  partial: { icon: AlertCircle, color: "text-amber-500", bg: "bg-amber-500/10", label: "Partial Success" },
  ongoing: { icon: Clock, color: "text-cyan-500", bg: "bg-cyan-500/10", label: "Ongoing" },
};

export default async function InterventionsPage() {
  const supabase = await createClient();

  const { data: interventions } = await supabase
    .from("interventions")
    .select(`
      *,
      children (first_name, last_name)
    `)
    .order("created_at", { ascending: false });

  const successfulCount = interventions?.filter((i) => i.outcome === "successful").length || 0;
  const unsuccessfulCount = interventions?.filter((i) => i.outcome === "unsuccessful").length || 0;
  const ongoingCount = interventions?.filter((i) => i.outcome === "ongoing").length || 0;

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <Link href="/dashboard" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4">
        <ArrowLeft className="h-4 w-4" />
        Back to Dashboard
      </Link>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Intervention Tracker</h1>
          <p className="text-muted-foreground">Track what works and what doesn&apos;t</p>
        </div>
        <Link href="/dashboard/interventions/new">
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            Add Intervention
          </Button>
        </Link>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-3 mb-6">
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-500/10 flex items-center justify-center">
              <CheckCircle className="h-5 w-5 text-emerald-500" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{successfulCount}</p>
              <p className="text-sm text-muted-foreground">Successful</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-red-500/10 flex items-center justify-center">
              <XCircle className="h-5 w-5 text-red-500" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{unsuccessfulCount}</p>
              <p className="text-sm text-muted-foreground">Unsuccessful</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-cyan-500/10 flex items-center justify-center">
              <Clock className="h-5 w-5 text-cyan-500" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{ongoingCount}</p>
              <p className="text-sm text-muted-foreground">Ongoing</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Info Card */}
      <Card className="mb-6 border-amber-500/30 bg-amber-500/5">
        <CardContent className="p-4">
          <p className="text-sm text-foreground">
            <strong>Why track interventions?</strong> Local authorities need to see what strategies have been tried before approving an EHCP. This evidence shows you&apos;ve exhausted available support options.
          </p>
        </CardContent>
      </Card>

      {/* Interventions List */}
      {interventions && interventions.length > 0 ? (
        <div className="space-y-3">
          {interventions.map((intervention) => {
            const config = outcomeConfig[intervention.outcome as keyof typeof outcomeConfig] || outcomeConfig.ongoing;
            const Icon = config.icon;
            
            return (
              <Card key={intervention.id}>
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <div className={`w-10 h-10 rounded-lg ${config.bg} flex items-center justify-center flex-shrink-0`}>
                      <Icon className={`h-5 w-5 ${config.color}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-foreground">{intervention.name}</span>
                        <span className={`text-xs px-2 py-0.5 rounded-full ${config.bg} ${config.color}`}>
                          {config.label}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground mb-1">
                        For: {intervention.children?.first_name} {intervention.children?.last_name}
                      </p>
                      {intervention.description && (
                        <p className="text-sm text-muted-foreground mb-2">{intervention.description}</p>
                      )}
                      {intervention.notes && (
                        <p className="text-sm text-muted-foreground italic">&ldquo;{intervention.notes}&rdquo;</p>
                      )}
                      <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                        {intervention.started_at && (
                          <span>Started: {new Date(intervention.started_at).toLocaleDateString("en-GB")}</span>
                        )}
                        {intervention.ended_at && (
                          <span>Ended: {new Date(intervention.ended_at).toLocaleDateString("en-GB")}</span>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-muted-foreground mb-4">No interventions tracked yet</p>
            <Link href="/dashboard/interventions/new">
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Add Your First Intervention
              </Button>
            </Link>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
