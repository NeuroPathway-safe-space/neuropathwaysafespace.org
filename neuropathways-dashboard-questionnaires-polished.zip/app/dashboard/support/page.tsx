import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Phone, Heart, Shield, ExternalLink, AlertTriangle, ArrowLeft } from "lucide-react";
import Link from "next/link";

const crisisResources = [
  {
    name: "Samaritans",
    phone: "116 123",
    description: "24/7 emotional support for anyone in distress",
    url: "https://www.samaritans.org",
    available: "24/7, free",
  },
  {
    name: "Childline",
    phone: "0800 1111",
    description: "For children and young people under 19",
    url: "https://www.childline.org.uk",
    available: "24/7, free",
  },
  {
    name: "PAPYRUS (HOPELineUK)",
    phone: "0800 068 4141",
    description: "Prevention of young suicide - for people under 35",
    url: "https://www.papyrus-uk.org",
    available: "9am-midnight daily",
  },
  {
    name: "Mind Infoline",
    phone: "0300 123 3393",
    description: "Mental health information and support",
    url: "https://www.mind.org.uk",
    available: "9am-6pm Mon-Fri",
  },
  {
    name: "SHOUT Crisis Text Line",
    phone: "Text SHOUT to 85258",
    description: "Free, confidential, 24/7 text support",
    url: "https://giveusashout.org",
    available: "24/7, free",
  },
  {
    name: "Young Minds",
    phone: "Text YM to 85258",
    description: "Mental health charity for young people",
    url: "https://www.youngminds.org.uk",
    available: "24/7 text service",
  },
  {
    name: "CALM (Campaign Against Living Miserably)",
    phone: "0800 58 58 58",
    description: "For men who are struggling",
    url: "https://www.thecalmzone.net",
    available: "5pm-midnight daily",
  },
  {
    name: "NSPCC Helpline",
    phone: "0808 800 5000",
    description: "For adults concerned about a child",
    url: "https://www.nspcc.org.uk",
    available: "24/7",
  },
];

const safeguardingInfo = [
  {
    title: "What is a safeguarding concern?",
    content: "A safeguarding concern is any worry about a child's welfare that suggests they may be at risk of harm, abuse, or neglect. This includes physical, emotional, sexual abuse, neglect, or exploitation.",
  },
  {
    title: "What should I do if I have a concern?",
    content: "Report your concern immediately to your Designated Safeguarding Lead (DSL) if you work in a school or organisation. If you're a parent, contact your local authority children's services. In an emergency, call 999.",
  },
  {
    title: "Recording observations",
    content: "When recording observations in NeuroPathway, stick to factual, objective descriptions. Note exactly what you saw or heard, including the child's exact words if they made a disclosure. Do not investigate or ask leading questions.",
  },
  {
    title: "Confidentiality",
    content: "While observations should be kept confidential, safeguarding always takes priority. You must share information with appropriate authorities when there is a risk to a child's safety.",
  },
];

export default function SupportPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <Link href="/dashboard" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6">
        <ArrowLeft className="h-4 w-4" />
        Back to Dashboard
      </Link>

      <div className="mb-8">
        <h1 className="text-2xl font-bold text-foreground mb-2">Support & Resources</h1>
        <p className="text-muted-foreground">Mental health crisis lines and safeguarding guidance</p>
      </div>

      {/* Emergency Banner */}
      <Card className="bg-red-500/10 border-red-500/30 mb-8">
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-full bg-red-500/20 flex items-center justify-center shrink-0">
              <AlertTriangle className="h-6 w-6 text-red-500" />
            </div>
            <div>
              <h2 className="font-semibold text-red-400 text-lg mb-2">In an Emergency</h2>
              <p className="text-muted-foreground mb-3">
                If you believe a child is in immediate danger or someone is at risk of harming themselves or others:
              </p>
              <div className="flex flex-wrap gap-3">
                <a href="tel:999" className="inline-flex items-center gap-2 px-4 py-2 bg-red-500 text-white rounded-lg font-medium hover:bg-red-600 transition-colors">
                  <Phone className="h-4 w-4" />
                  Call 999 (Emergency)
                </a>
                <a href="tel:116123" className="inline-flex items-center gap-2 px-4 py-2 bg-amber-500 text-background rounded-lg font-medium hover:bg-amber-600 transition-colors">
                  <Phone className="h-4 w-4" />
                  Samaritans: 116 123
                </a>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Crisis Resources */}
      <Card className="mb-8">
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-amber-500/10 flex items-center justify-center">
              <Heart className="h-5 w-5 text-amber-500" />
            </div>
            <div>
              <CardTitle>Mental Health Support Lines</CardTitle>
              <CardDescription>Free, confidential support services</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 md:grid-cols-2">
            {crisisResources.map((resource) => (
              <Link
                key={resource.name}
                href={resource.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-start justify-between p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors group"
              >
                <div className="space-y-1">
                  <p className="font-medium text-foreground">{resource.name}</p>
                  <p className="text-xs text-muted-foreground">{resource.description}</p>
                  <p className="text-xs text-primary">{resource.available}</p>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <span className="text-primary font-mono text-sm whitespace-nowrap">{resource.phone}</span>
                  <ExternalLink className="h-3 w-3 text-muted-foreground group-hover:text-primary" />
                </div>
              </Link>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Safeguarding Guidance */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-emerald-500/10 flex items-center justify-center">
              <Shield className="h-5 w-5 text-emerald-500" />
            </div>
            <div>
              <CardTitle>Safeguarding Guidance</CardTitle>
              <CardDescription>Understanding your responsibilities</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {safeguardingInfo.map((item, idx) => (
              <div key={idx} className="p-4 bg-secondary/50 rounded-lg">
                <h3 className="font-medium text-foreground mb-2">{item.title}</h3>
                <p className="text-sm text-muted-foreground">{item.content}</p>
              </div>
            ))}
          </div>

          <div className="mt-6 p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
            <h3 className="font-medium text-blue-400 mb-2">Key Contacts for Safeguarding</h3>
            <ul className="text-sm text-muted-foreground space-y-2">
              <li><strong>NSPCC:</strong> 0808 800 5000 - For adults concerned about a child</li>
              <li><strong>Childline:</strong> 0800 1111 - For children and young people</li>
              <li><strong>Local Authority:</strong> Contact your local council&apos;s children&apos;s services</li>
              <li><strong>Police:</strong> 101 (non-emergency) or 999 (emergency)</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Disclaimer */}
      <div className="mt-8 p-4 bg-secondary/30 rounded-lg text-center">
        <p className="text-xs text-muted-foreground">
          NeuroPathway is an observation tracking tool and does not provide medical advice, diagnosis, or treatment. 
          Always seek advice from qualified professionals for mental health or safeguarding concerns.
        </p>
      </div>
    </div>
  );
}
