import { createClient } from "@/lib/supabase/server";
import { redirect, notFound } from "next/navigation";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { PromptEditor } from "../prompt-editor";

export default async function EditPromptPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  
  if (!user) {
    redirect('/login');
  }

  // Check if user is admin
  const { data: profile } = await supabase
    .from('profiles')
    .select('is_admin')
    .eq('id', user.id)
    .single();

  if (!profile?.is_admin) {
    redirect('/dashboard');
  }

  // Get the prompt
  const { data: prompt } = await supabase
    .from('ai_prompts')
    .select('*')
    .eq('id', id)
    .single();

  if (!prompt) {
    notFound();
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <Link href="/dashboard/admin/prompts" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4">
        <ArrowLeft className="h-4 w-4" />
        Back to Prompts
      </Link>

      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">Edit Prompt</h1>
        <p className="text-muted-foreground">{prompt.name} (v{prompt.version})</p>
      </div>

      <PromptEditor prompt={prompt} />
    </div>
  );
}
