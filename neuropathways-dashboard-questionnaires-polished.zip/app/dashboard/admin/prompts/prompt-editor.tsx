'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Slider } from '@/components/ui/slider'
import { Switch } from '@/components/ui/switch'
import { Loader2, Save, TestTube } from 'lucide-react'

interface PromptEditorProps {
  prompt?: {
    id?: string
    name: string
    slug: string
    purpose: string
    category: string
    system_prompt: string
    user_prompt_template: string
    model: string
    temperature: number
    max_tokens?: number
    is_active: boolean
    test_status: string
    version: number
  }
  isNew?: boolean
}

const categories = [
  { value: 'pattern_recognition', label: 'Pattern Recognition' },
  { value: 'risk_stratification', label: 'Risk Stratification' },
  { value: 'ehcp_evidence', label: 'EHCP Evidence' },
  { value: 'cross_setting', label: 'Cross-Setting Analysis' },
  { value: 'strategies', label: 'Strategy Generation' },
  { value: 'safe_space_insights', label: 'Safe Space Insights' },
]

const models = [
  { value: 'openai/gpt-5', label: 'GPT-5 (Recommended)' },
  { value: 'openai/gpt-5-mini', label: 'GPT-5 Mini (Faster)' },
  { value: 'anthropic/claude-opus-4.6', label: 'Claude Opus 4.6' },
  { value: 'google/gemini-3-flash', label: 'Gemini 3 Flash' },
]

export function PromptEditor({ prompt, isNew = false }: PromptEditorProps) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [isTesting, setIsTesting] = useState(false)
  const [testResult, setTestResult] = useState<string | null>(null)
  
  const [formData, setFormData] = useState({
    name: prompt?.name || '',
    slug: prompt?.slug || '',
    purpose: prompt?.purpose || '',
    category: prompt?.category || 'pattern_recognition',
    system_prompt: prompt?.system_prompt || '',
    user_prompt_template: prompt?.user_prompt_template || '',
    model: prompt?.model || 'openai/gpt-5',
    temperature: prompt?.temperature || 0.3,
    max_tokens: prompt?.max_tokens || 4096,
    is_active: prompt?.is_active ?? false,
    test_status: prompt?.test_status || 'draft',
  })

  const handleSave = async () => {
    setIsLoading(true)
    const supabase = createClient()

    try {
      if (isNew || !prompt?.id) {
        // Create new prompt
        const { error } = await supabase
          .from('ai_prompts')
          .insert({
            ...formData,
            version: 1
          })

        if (error) throw error
      } else {
        // Update existing - create new version
        const { error } = await supabase
          .from('ai_prompts')
          .update({
            ...formData,
            version: (prompt.version || 1) + 1,
            updated_at: new Date().toISOString()
          })
          .eq('id', prompt.id)

        if (error) throw error
      }

      router.push('/dashboard/admin/prompts')
      router.refresh()
    } catch (error) {
      console.error('Save error:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleTest = async () => {
    setIsTesting(true)
    setTestResult(null)

    try {
      const res = await fetch('/api/ai/test-prompt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          system_prompt: formData.system_prompt,
          user_prompt: formData.user_prompt_template.replace(/\{\{[^}]+\}\}/g, '[SAMPLE_DATA]'),
          model: formData.model,
          temperature: formData.temperature
        })
      })

      const data = await res.json()
      setTestResult(data.result || data.error || 'Test completed')
    } catch (error) {
      setTestResult(`Error: ${error instanceof Error ? error.message : 'Test failed'}`)
    } finally {
      setIsTesting(false)
    }
  }

  const generateSlug = (name: string) => {
    return name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '') + '-v1'
  }

  return (
    <div className="space-y-6">
      {/* Basic Info */}
      <Card>
        <CardHeader>
          <CardTitle>Basic Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="name">Prompt Name</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => {
                  setFormData({ 
                    ...formData, 
                    name: e.target.value,
                    slug: isNew ? generateSlug(e.target.value) : formData.slug
                  })
                }}
                placeholder="Pattern Recognition Engine"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="slug">Slug (unique identifier)</Label>
              <Input
                id="slug"
                value={formData.slug}
                onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                placeholder="pattern-recognition-v1"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="purpose">Purpose</Label>
            <Textarea
              id="purpose"
              value={formData.purpose}
              onChange={(e) => setFormData({ ...formData, purpose: e.target.value })}
              placeholder="Describe what this prompt does..."
              rows={2}
            />
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label>Category</Label>
              <Select value={formData.category} onValueChange={(v) => setFormData({ ...formData, category: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {categories.map(cat => (
                    <SelectItem key={cat.value} value={cat.value}>{cat.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Test Status</Label>
              <Select value={formData.test_status} onValueChange={(v) => setFormData({ ...formData, test_status: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="testing">Testing</SelectItem>
                  <SelectItem value="production">Production</SelectItem>
                  <SelectItem value="deprecated">Deprecated</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Model Configuration */}
      <Card>
        <CardHeader>
          <CardTitle>Model Configuration</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label>Model</Label>
              <Select value={formData.model} onValueChange={(v) => setFormData({ ...formData, model: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {models.map(model => (
                    <SelectItem key={model.value} value={model.value}>{model.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Temperature: {formData.temperature}</Label>
              <Slider
                value={[formData.temperature]}
                onValueChange={([v]) => setFormData({ ...formData, temperature: v })}
                min={0}
                max={1}
                step={0.1}
              />
              <p className="text-xs text-muted-foreground">
                Lower = more focused, Higher = more creative
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Switch
                checked={formData.is_active}
                onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
              />
              <Label>Active</Label>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Prompts */}
      <Card>
        <CardHeader>
          <CardTitle>Prompt Content</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="system_prompt">System Prompt</Label>
            <Textarea
              id="system_prompt"
              value={formData.system_prompt}
              onChange={(e) => setFormData({ ...formData, system_prompt: e.target.value })}
              placeholder="You are a specialist educational psychologist AI assistant..."
              rows={6}
              className="font-mono text-sm"
            />
            <p className="text-xs text-muted-foreground">
              Sets the AI&apos;s role and behavior. Be specific about constraints and output format.
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="user_prompt_template">User Prompt Template</Label>
            <Textarea
              id="user_prompt_template"
              value={formData.user_prompt_template}
              onChange={(e) => setFormData({ ...formData, user_prompt_template: e.target.value })}
              placeholder="Analyze the following {{observation_count}} observations for {{child_name}}..."
              rows={6}
              className="font-mono text-sm"
            />
            <p className="text-xs text-muted-foreground">
              {`Use {{variable_name}} for dynamic content. Available: child_name, observation_count, date_range, settings, pattern_name, target_setting`}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Test Result */}
      {testResult && (
        <Card>
          <CardHeader>
            <CardTitle>Test Result</CardTitle>
          </CardHeader>
          <CardContent>
            <pre className="text-sm bg-muted p-4 rounded-lg overflow-x-auto whitespace-pre-wrap max-h-96">
              {testResult}
            </pre>
          </CardContent>
        </Card>
      )}

      {/* Actions */}
      <div className="flex items-center gap-3 justify-end sticky bottom-4 bg-background/80 backdrop-blur-sm p-4 -mx-4 border-t">
        <Button variant="outline" onClick={handleTest} disabled={isTesting}>
          {isTesting ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Testing...
            </>
          ) : (
            <>
              <TestTube className="h-4 w-4 mr-2" />
              Test Prompt
            </>
          )}
        </Button>
        <Button onClick={handleSave} disabled={isLoading}>
          {isLoading ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Save className="h-4 w-4 mr-2" />
              {isNew ? 'Create Prompt' : 'Save Changes'}
            </>
          )}
        </Button>
      </div>
    </div>
  )
}
