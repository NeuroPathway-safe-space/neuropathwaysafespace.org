import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { PromptEditor } from "../prompt-editor";

export default async function NewPromptPage({
  searchParams,
}: {
  searchParams: Promise<{ clone?: string }>;
}) {
  const { clone } = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  
  if (!user) {
    redirect('/login');
  }

  // Check if user is admin
  const { data: profile } = await supabase
    .from('profiles')
    .select('is_admin')
    .eq('id', user.id)
    .single();

  if (!profile?.is_admin) {
    redirect('/dashboard');
  }

  // If cloning, get the source prompt
  let clonePrompt = null;
  if (clone) {
    const { data } = await supabase
      .from('ai_prompts')
      .select('*')
      .eq('id', clone)
      .single();
    
    if (data) {
      clonePrompt = {
        ...data,
        name: `${data.name} (Copy)`,
        slug: `${data.slug}-copy`,
        version: 1,
        is_active: false,
        test_status: 'draft'
      };
    }
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <Link href="/dashboard/admin/prompts" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4">
        <ArrowLeft className="h-4 w-4" />
        Back to Prompts
      </Link>

      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">
          {clone ? 'Clone Prompt' : 'New Prompt'}
        </h1>
        <p className="text-muted-foreground">
          {clone ? 'Create a new version based on an existing prompt' : 'Create a new AI prompt configuration'}
        </p>
      </div>

      <PromptEditor prompt={clonePrompt || undefined} isNew />
    </div>
  );
}
