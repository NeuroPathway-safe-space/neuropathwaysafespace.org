import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Link from "next/link";
import { 
  ArrowLeft, 
  Brain, 
  Shield, 
  FileText, 
  Settings2, 
  Plus,
  Edit3,
  Copy,
  ToggleLeft,
  ToggleRight,
  Sparkles,
  Thermometer,
  Hash,
  Clock
} from "lucide-react";
import { PromptEditor } from "./prompt-editor";

const categoryConfig: Record<string, { label: string; icon: typeof Brain; color: string }> = {
  pattern_recognition: { label: 'Pattern Recognition', icon: Brain, color: 'bg-violet-500/10 text-violet-500' },
  risk_stratification: { label: 'Risk Stratification', icon: Shield, color: 'bg-red-500/10 text-red-500' },
  ehcp_evidence: { label: 'EHCP Evidence', icon: FileText, color: 'bg-amber-500/10 text-amber-500' },
  cross_setting: { label: 'Cross-Setting', icon: Settings2, color: 'bg-blue-500/10 text-blue-500' },
  strategies: { label: 'Strategies', icon: Sparkles, color: 'bg-green-500/10 text-green-500' },
  safe_space_insights: { label: 'Safe Space', icon: Shield, color: 'bg-cyan-500/10 text-cyan-500' },
};

export default async function AdminPromptsPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  
  if (!user) {
    redirect('/login');
  }

  // Check if user is admin
  const { data: profile } = await supabase
    .from('profiles')
    .select('is_admin')
    .eq('id', user.id)
    .single();

  if (!profile?.is_admin) {
    redirect('/dashboard');
  }

  // Get all prompts
  const { data: prompts } = await supabase
    .from('ai_prompts')
    .select('*')
    .order('category', { ascending: true })
    .order('version', { ascending: false });

  // Get AI run statistics
  const { data: runStats } = await supabase
    .from('ai_runs')
    .select('engine_type, status, confidence_score')
    .gte('created_at', new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString());

  const statsByEngine = (runStats || []).reduce((acc, run) => {
    if (!acc[run.engine_type]) {
      acc[run.engine_type] = { total: 0, completed: 0, failed: 0, avgConfidence: 0, confidences: [] };
    }
    acc[run.engine_type].total++;
    if (run.status === 'completed' || run.status === 'review_required') {
      acc[run.engine_type].completed++;
      if (run.confidence_score) {
        acc[run.engine_type].confidences.push(run.confidence_score);
      }
    } else if (run.status === 'failed') {
      acc[run.engine_type].failed++;
    }
    return acc;
  }, {} as Record<string, { total: number; completed: number; failed: number; avgConfidence: number; confidences: number[] }>);

  // Calculate averages
  Object.keys(statsByEngine).forEach(key => {
    const stats = statsByEngine[key];
    if (stats.confidences.length > 0) {
      stats.avgConfidence = stats.confidences.reduce((a, b) => a + b, 0) / stats.confidences.length;
    }
  });

  const categories = [...new Set(prompts?.map(p => p.category) || [])];

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      <Link href="/dashboard/ai" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4">
        <ArrowLeft className="h-4 w-4" />
        Back to AI Control Centre
      </Link>

      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Prompt Management</h1>
          <p className="text-muted-foreground">Configure and version AI prompts</p>
        </div>
        <Link href="/dashboard/admin/prompts/new">
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            New Prompt
          </Button>
        </Link>
      </div>

      {/* Engine Performance Overview */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
        {Object.entries(categoryConfig).map(([key, config]) => {
          const stats = statsByEngine[key] || { total: 0, completed: 0, avgConfidence: 0 };
          const Icon = config.icon;
          return (
            <Card key={key}>
              <CardContent className="p-4">
                <div className={`w-10 h-10 rounded-lg ${config.color} flex items-center justify-center mb-3`}>
                  <Icon className="h-5 w-5" />
                </div>
                <p className="text-sm font-medium truncate">{config.label}</p>
                <p className="text-2xl font-bold">{stats.total}</p>
                <p className="text-xs text-muted-foreground">
                  {stats.avgConfidence > 0 ? `${Math.round(stats.avgConfidence * 100)}% avg` : 'No runs'}
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Prompts by Category */}
      <Card>
        <CardHeader>
          <Tabs defaultValue={categories[0] || 'all'}>
            <TabsList className="flex-wrap h-auto gap-1">
              {categories.map(cat => {
                const config = categoryConfig[cat];
                return (
                  <TabsTrigger key={cat} value={cat} className="gap-2">
                    {config?.icon && <config.icon className="h-4 w-4" />}
                    {config?.label || cat}
                  </TabsTrigger>
                );
              })}
            </TabsList>

            {categories.map(category => (
              <TabsContent key={category} value={category} className="mt-4">
                <div className="space-y-4">
                  {prompts?.filter(p => p.category === category).map(prompt => (
                    <PromptCard key={prompt.id} prompt={prompt} />
                  ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </CardHeader>
      </Card>
    </div>
  );
}

function PromptCard({ prompt }: { prompt: {
  id: string;
  name: string;
  slug: string;
  purpose: string;
  category: string;
  model: string;
  temperature: number;
  is_active: boolean;
  test_status: string;
  version: number;
  created_at: string;
  system_prompt: string;
  user_prompt_template: string;
}}) {
  const config = categoryConfig[prompt.category];

  return (
    <div className="border rounded-lg p-4 hover:bg-muted/30 transition-colors">
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-3 flex-1">
          <div className={`w-10 h-10 rounded-lg ${config?.color || 'bg-gray-500/10'} flex items-center justify-center flex-shrink-0`}>
            {config?.icon && <config.icon className="h-5 w-5" />}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-medium">{prompt.name}</h3>
              <Badge variant={prompt.is_active ? 'default' : 'secondary'}>
                {prompt.is_active ? 'Active' : 'Inactive'}
              </Badge>
              <Badge variant="outline" className={
                prompt.test_status === 'production' ? 'bg-green-500/10 text-green-500' :
                prompt.test_status === 'testing' ? 'bg-amber-500/10 text-amber-500' :
                'bg-gray-500/10'
              }>
                {prompt.test_status}
              </Badge>
              <Badge variant="outline" className="text-xs">
                v{prompt.version}
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground mt-1">{prompt.purpose}</p>
            
            {/* Prompt Details */}
            <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
              <span className="flex items-center gap-1">
                <Sparkles className="h-3 w-3" />
                {prompt.model}
              </span>
              <span className="flex items-center gap-1">
                <Thermometer className="h-3 w-3" />
                Temp: {prompt.temperature}
              </span>
              <span className="flex items-center gap-1">
                <Hash className="h-3 w-3" />
                {prompt.slug}
              </span>
              <span className="flex items-center gap-1">
                <Clock className="h-3 w-3" />
                {new Date(prompt.created_at).toLocaleDateString('en-GB')}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1 flex-shrink-0">
          <Link href={`/dashboard/admin/prompts/${prompt.id}`}>
            <Button variant="ghost" size="icon">
              <Edit3 className="h-4 w-4" />
            </Button>
          </Link>
          <Link href={`/dashboard/admin/prompts/new?clone=${prompt.id}`}>
            <Button variant="ghost" size="icon">
              <Copy className="h-4 w-4" />
            </Button>
          </Link>
          <PromptToggle promptId={prompt.id} isActive={prompt.is_active} />
        </div>
      </div>

      {/* Expandable Prompt Content */}
      <details className="mt-4">
        <summary className="text-sm text-muted-foreground cursor-pointer hover:text-foreground">
          View prompt content
        </summary>
        <div className="mt-3 space-y-3">
          <div>
            <p className="text-xs font-medium text-muted-foreground mb-1">System Prompt</p>
            <pre className="text-xs bg-muted p-3 rounded-lg overflow-x-auto whitespace-pre-wrap">
              {prompt.system_prompt}
            </pre>
          </div>
          <div>
            <p className="text-xs font-medium text-muted-foreground mb-1">User Template</p>
            <pre className="text-xs bg-muted p-3 rounded-lg overflow-x-auto whitespace-pre-wrap">
              {prompt.user_prompt_template}
            </pre>
          </div>
        </div>
      </details>
    </div>
  );
}

function PromptToggle({ promptId, isActive }: { promptId: string; isActive: boolean }) {
  return (
    <form action={async () => {
      'use server'
      const supabase = await createClient();
      await supabase
        .from('ai_prompts')
        .update({ is_active: !isActive })
        .eq('id', promptId);
    }}>
      <Button variant="ghost" size="icon" type="submit">
        {isActive ? (
          <ToggleRight className="h-4 w-4 text-green-500" />
        ) : (
          <ToggleLeft className="h-4 w-4 text-muted-foreground" />
        )}
      </Button>
    </form>
  );
}
