"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { CheckCircle2, Loader2, Sparkles } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

interface Child {
  id: string;
  first_name: string | null;
  last_name: string | null;
}

interface Question {
  key: string;
  label: string;
  help: string;
}

// 1-5 scale questions. Higher = doing well, lower = greater need.
const DAILY_QUESTIONS: Question[] = [
  { key: "mood", label: "Overall mood today", help: "1 = very low, 5 = very positive" },
  { key: "regulation", label: "Emotional regulation", help: "1 = frequent dysregulation, 5 = settled" },
  { key: "focus", label: "Focus & engagement", help: "1 = unable to engage, 5 = fully engaged" },
  { key: "social", label: "Social interaction", help: "1 = withdrawn/conflict, 5 = connected" },
  { key: "sleep", label: "Sleep / energy", help: "1 = exhausted, 5 = well rested" },
];

const WEEKLY_QUESTIONS: Question[] = [
  { key: "mood", label: "General mood this week", help: "1 = very low, 5 = very positive" },
  { key: "regulation", label: "Managing big feelings", help: "1 = frequent distress, 5 = mostly settled" },
  { key: "attendance", label: "Attendance / participation", help: "1 = major difficulty, 5 = no concerns" },
  { key: "learning", label: "Learning & focus", help: "1 = significant barriers, 5 = thriving" },
  { key: "relationships", label: "Relationships with peers/adults", help: "1 = strained, 5 = positive" },
  { key: "independence", label: "Independence & coping", help: "1 = needs full support, 5 = independent" },
];

const SCORE_OPTIONS = [
  { value: 1, label: "1" },
  { value: 2, label: "2" },
  { value: 3, label: "3" },
  { value: 4, label: "4" },
  { value: 5, label: "5" },
];

function QuestionSet({
  questions,
  values,
  onChange,
}: {
  questions: Question[];
  values: Record<string, number>;
  onChange: (key: string, value: number) => void;
}) {
  return (
    <div className="grid gap-4">
      {questions.map((q) => (
        <div key={q.key} className="rounded-2xl border bg-background/70 p-4 shadow-sm">
          <div className="mb-3 flex flex-col gap-1 sm:flex-row sm:items-baseline sm:justify-between">
            <Label className="text-sm font-semibold text-foreground">{q.label}</Label>
            <span className="text-xs text-muted-foreground">{q.help}</span>
          </div>
          <div className="grid grid-cols-5 gap-2">
            {SCORE_OPTIONS.map((opt) => {
              const selected = values[q.key] === opt.value;
              return (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => onChange(q.key, opt.value)}
                  aria-pressed={selected}
                  className={`min-h-12 rounded-xl border text-sm font-semibold shadow-sm transition-all hover:-translate-y-0.5 ${
                    selected
                      ? "bg-primary text-primary-foreground border-primary shadow-md"
                      : "bg-card text-muted-foreground border-border hover:border-primary/50 hover:text-foreground"
                  }`}
                >
                  {opt.label}
                </button>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}

export function CheckInForm({
  children,
  completedToday,
  initialCadence = "daily",
}: {
  children: Child[];
  completedToday: { child_id: string; cadence: string }[];
  initialCadence?: "daily" | "weekly";
}) {
  const router = useRouter();
  const { toast } = useToast();
  const [childId, setChildId] = useState<string>(children[0]?.id ?? "");
  const [cadence, setCadence] = useState<"daily" | "weekly">(initialCadence);
  const [dailyValues, setDailyValues] = useState<Record<string, number>>({});
  const [weeklyValues, setWeeklyValues] = useState<Record<string, number>>({});
  const [notes, setNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const questions = cadence === "daily" ? DAILY_QUESTIONS : WEEKLY_QUESTIONS;
  const values = cadence === "daily" ? dailyValues : weeklyValues;
  const setValues = cadence === "daily" ? setDailyValues : setWeeklyValues;

  const answeredCount = questions.filter((q) => values[q.key]).length;
  const alreadyDone = completedToday.some(
    (c) => c.child_id === childId && c.cadence === cadence,
  );

  const handleChange = (key: string, value: number) => {
    setValues((prev) => ({ ...prev, [key]: value }));
  };

  const buildSummary = () => {
    const avg =
      questions.reduce((sum, q) => sum + (values[q.key] || 0), 0) /
      Math.max(answeredCount, 1);
    const lows = questions.filter((q) => values[q.key] && values[q.key] <= 2);
    const highs = questions.filter((q) => values[q.key] && values[q.key] >= 4);
    const parts: string[] = [];
    parts.push(
      `${cadence === "daily" ? "Daily" : "Weekly"} check-in (avg ${avg.toFixed(1)}/5).`,
    );
    if (highs.length) parts.push(`Strengths: ${highs.map((q) => q.label.toLowerCase()).join(", ")}.`);
    if (lows.length) parts.push(`Areas of need: ${lows.map((q) => q.label.toLowerCase()).join(", ")}.`);
    if (notes.trim()) parts.push(`Notes: ${notes.trim()}`);
    return parts.join(" ");
  };

  const handleSubmit = async () => {
    if (!childId) {
      toast({ title: "Select a child first", variant: "destructive" });
      return;
    }
    if (answeredCount < questions.length) {
      toast({ title: "Please answer every question", variant: "destructive" });
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch("/api/check-in", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          childId,
          cadence,
          responses: { ...values, notes },
          scoreFields: questions.map((q) => q.key),
          summary: buildSummary(),
        }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Submission failed");
      }
      toast({
        title: "Check-in saved",
        description: "This is now part of the child's evidence record.",
      });
      setValues({});
      setNotes("");
      router.refresh();
    } catch (e) {
      toast({
        title: "Could not save check-in",
        description: e instanceof Error ? e.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  if (children.length === 0) {
    return (
      <Card>
        <CardContent className="py-8 text-center">
          <p className="text-muted-foreground mb-4">
            Add a child before recording check-ins.
          </p>
          <Button onClick={() => router.push("/dashboard/children/new")}>
            Add a child
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="overflow-hidden border-primary/15 shadow-xl">
      <CardHeader className="border-b bg-gradient-to-r from-primary/10 via-background to-background">
        <div className="flex items-start justify-between gap-4">
          <div>
            <CardTitle className="flex items-center gap-2 text-xl">
              <Sparkles className="h-5 w-5 text-primary" />
              Record a check-in
            </CardTitle>
            <CardDescription className="mt-1">
              Rate each area from 1 (significant need) to 5 (doing well).
            </CardDescription>
          </div>
          <div className="hidden rounded-2xl border bg-background/70 px-4 py-2 text-center sm:block">
            <p className="text-2xl font-bold text-primary">{answeredCount}/{questions.length}</p>
            <p className="text-xs text-muted-foreground">answered</p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="flex flex-col gap-6 p-5 sm:p-6">
        <div className="rounded-2xl border bg-muted/20 p-4">
          <Label htmlFor="child-select" className="mb-2 block font-semibold">Child / young person</Label>
          <Select value={childId} onValueChange={setChildId}>
            <SelectTrigger id="child-select" className="min-h-11">
              <SelectValue placeholder="Select a child" />
            </SelectTrigger>
            <SelectContent>
              {children.map((c) => (
                <SelectItem key={c.id} value={c.id}>
                  {c.first_name} {c.last_name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Tabs value={cadence} onValueChange={(v) => setCadence(v as "daily" | "weekly")}>
          <TabsList className="grid h-12 w-full grid-cols-2 rounded-2xl bg-muted p-1">
            <TabsTrigger value="daily">Daily</TabsTrigger>
            <TabsTrigger value="weekly">Weekly</TabsTrigger>
          </TabsList>
          <TabsContent value="daily" className="mt-5">
            <QuestionSet questions={DAILY_QUESTIONS} values={dailyValues} onChange={handleChange} />
          </TabsContent>
          <TabsContent value="weekly" className="mt-5">
            <QuestionSet questions={WEEKLY_QUESTIONS} values={weeklyValues} onChange={handleChange} />
          </TabsContent>
        </Tabs>

        <div className="rounded-2xl border bg-muted/20 p-4">
          <Label htmlFor="notes" className="mb-2 block font-semibold">Notes (optional)</Label>
          <Textarea
            id="notes"
            placeholder="Anything notable today - context, triggers, what helped..."
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={3}
            className="min-h-24 rounded-xl bg-background"
          />
        </div>

        {alreadyDone && (
          <p className="flex items-center gap-2 text-sm text-emerald-500">
            <CheckCircle2 className="h-4 w-4" />
            A {cadence} check-in already exists for this child today. Submitting will update it.
          </p>
        )}

        <Button onClick={handleSubmit} disabled={submitting} className="min-h-12 rounded-xl text-base shadow-lg">
          {submitting ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Saving...
            </>
          ) : (
            `Save ${cadence} check-in (${answeredCount}/${questions.length})`
          )}
        </Button>
      </CardContent>
    </Card>
  );
}
