import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, CalendarCheck, ClipboardCheck, Sparkles } from "lucide-react";
import { CheckInForm } from "./check-in-form";
import { Badge } from "@/components/ui/badge";

export default async function CheckInPage({
  searchParams,
}: {
  searchParams?: Promise<{ type?: string }>;
}) {
  const params = await searchParams;
  const initialCadence = params?.type === "weekly" ? "weekly" : "daily";
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/auth/login");

  const { data: children } = await supabase
    .from("children")
    .select("id, first_name, last_name")
    .order("first_name", { ascending: true });

  const today = new Date().toISOString().slice(0, 10);
  const { data: todays } = await supabase
    .from("check_ins")
    .select("child_id, cadence")
    .eq("check_in_date", today);

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-5xl mx-auto px-4 py-6">
        <Link
          href="/dashboard"
          className="mb-6 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to dashboard
        </Link>

        <div className="mb-6 overflow-hidden rounded-3xl border border-primary/20 bg-gradient-to-br from-primary/15 via-background to-background p-6 shadow-xl sm:p-8">
          <div className="mb-4 flex flex-wrap gap-2">
            <Badge variant="secondary" className="gap-1 rounded-full px-3 py-1">
              <Sparkles className="h-3.5 w-3.5" />
              Everyday evidence
            </Badge>
            <Badge variant="outline" className="rounded-full bg-background/70 px-3 py-1">
              Safe, factual, needs-led
            </Badge>
          </div>
          <div className="grid gap-5 lg:grid-cols-[1fr_0.75fr] lg:items-end">
            <div>
              <h1 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl text-balance">
                Everyday Observation Questionnaire
              </h1>
              <p className="mt-3 max-w-2xl text-muted-foreground text-pretty">
                A quick daily or weekly snapshot that turns ordinary observations into structured evidence for patterns, support planning and EHCP reports.
              </p>
            </div>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-1">
              <div className="rounded-2xl border bg-background/75 p-4">
                <div className="flex items-center gap-2 text-sm font-medium">
                  <CalendarCheck className="h-4 w-4 text-primary" />
                  Daily: 5 simple ratings
                </div>
                <p className="mt-1 text-xs text-muted-foreground">Mood, regulation, focus, social connection and energy.</p>
              </div>
              <div className="rounded-2xl border bg-background/75 p-4">
                <div className="flex items-center gap-2 text-sm font-medium">
                  <ClipboardCheck className="h-4 w-4 text-primary" />
                  Weekly: wider pattern review
                </div>
                <p className="mt-1 text-xs text-muted-foreground">Attendance, learning, relationships and independence.</p>
              </div>
            </div>
          </div>
        </div>

        <CheckInForm
          children={children ?? []}
          completedToday={todays ?? []}
          initialCadence={initialCadence}
        />
      </div>
    </div>
  );
}
