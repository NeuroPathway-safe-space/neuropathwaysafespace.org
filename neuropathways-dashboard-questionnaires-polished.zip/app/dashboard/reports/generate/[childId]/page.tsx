import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import Link from "next/link";
import { ArrowLeft, FileText, TrendingUp, Users, Calendar, AlertTriangle, CheckCircle, XCircle, School, Stethoscope, FileCheck } from "lucide-react";
import { GenerateReportButton } from "@/components/generate-report-button";
import { Badge } from "@/components/ui/badge";

export default async function GenerateReportPage({
  params,
}: {
  params: Promise<{ childId: string }>;
}) {
  const { childId } = await params;
  const supabase = await createClient();

  // Get child details
  const { data: child } = await supabase
    .from("children")
    .select("*")
    .eq("id", childId)
    .single();

  if (!child) {
    redirect("/dashboard/reports");
  }

  // Get observations for this child
  const { data: observations } = await supabase
    .from("observations")
    .select("*")
    .eq("child_id", childId)
    .order("observed_at", { ascending: false });

  // Get interventions for this child
  const { data: interventions } = await supabase
    .from("interventions")
    .select("*")
    .eq("child_id", childId)
    .order("created_at", { ascending: false });

  // Get latest AI assessment
  const { data: aiAssessment } = await supabase
    .from("ai_assessments")
    .select("id, status, pattern_confidence, risk_status, observation_count, created_at")
    .eq("child_id", childId)
    .order("created_at", { ascending: false })
    .limit(1)
    .single();

  // Calculate patterns
  const categoryPatterns: Record<string, { count: number; totalSeverity: number }> = {};
  const timePatterns: Record<string, number> = {};

  observations?.forEach((obs) => {
    if (!categoryPatterns[obs.category_name]) {
      categoryPatterns[obs.category_name] = { count: 0, totalSeverity: 0 };
    }
    categoryPatterns[obs.category_name].count++;
    categoryPatterns[obs.category_name].totalSeverity += obs.severity;

    if (obs.time_of_day) {
      timePatterns[obs.time_of_day] = (timePatterns[obs.time_of_day] || 0) + 1;
    }
  });

  const sortedCategories = Object.entries(categoryPatterns)
    .map(([name, data]) => ({
      name,
      count: data.count,
      avgSeverity: Math.round((data.totalSeverity / data.count) * 10) / 10,
    }))
    .sort((a, b) => b.count - a.count);

  const mostCommonTime = Object.entries(timePatterns).sort((a, b) => b[1] - a[1])[0];

  const successfulInterventions = interventions?.filter((i) => i.outcome === "successful") || [];
  const unsuccessfulInterventions = interventions?.filter((i) => i.outcome === "unsuccessful") || [];

  const totalObservations = observations?.length || 0;
  const totalInterventions = interventions?.length || 0;

  // Prepare report data
  const reportData = {
    child: {
      firstName: child.first_name,
      lastName: child.last_name,
      schoolYear: child.school_year,
      dateOfBirth: child.date_of_birth,
    },
    summary: {
      totalObservations,
      totalInterventions,
      dateRange: observations?.length
        ? {
            from: observations[observations.length - 1]?.observed_at,
            to: observations[0]?.observed_at,
          }
        : null,
    },
    patterns: sortedCategories,
    timePatterns: Object.entries(timePatterns).map(([time, count]) => ({ time, count })),
    interventions: {
      successful: successfulInterventions.map((i) => ({ name: i.name, notes: i.notes })),
      unsuccessful: unsuccessfulInterventions.map((i) => ({ name: i.name, notes: i.notes })),
    },
    observations: observations?.slice(0, 20).map((o) => ({
      category: o.category_name,
      severity: o.severity,
      notes: o.notes,
      triggers: o.triggers,
      date: o.observed_at,
      timeOfDay: o.time_of_day,
    })),
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <Link href="/dashboard/reports" className="flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6">
        <ArrowLeft className="h-4 w-4" />
        Back to Reports
      </Link>

      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">
          EHCP Evidence Report: {child.first_name} {child.last_name}
        </h1>
        <p className="text-muted-foreground">Review the evidence before generating</p>
      </div>

      {/* Readiness Check */}
      <Card className={`mb-6 ${totalObservations >= 10 ? "border-emerald-500/30 bg-emerald-500/5" : "border-amber-500/30 bg-amber-500/5"}`}>
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            {totalObservations >= 10 ? (
              <CheckCircle className="h-6 w-6 text-emerald-500" />
            ) : (
              <AlertTriangle className="h-6 w-6 text-amber-500" />
            )}
            <div>
              <p className="font-medium text-foreground">
                {totalObservations >= 10
                  ? "Good evidence base for EHCP application"
                  : "More observations recommended"}
              </p>
              <p className="text-sm text-muted-foreground">
                {totalObservations >= 10
                  ? `${totalObservations} observations recorded - showing persistent patterns`
                  : `${totalObservations} observations recorded - aim for at least 10 to show patterns`}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Evidence Summary */}
      <div className="grid gap-4 md:grid-cols-3 mb-6">
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <FileText className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{totalObservations}</p>
              <p className="text-sm text-muted-foreground">Observations</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-cyan-500/10 flex items-center justify-center">
              <TrendingUp className="h-5 w-5 text-cyan-500" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{sortedCategories.length}</p>
              <p className="text-sm text-muted-foreground">Categories</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center">
              <Users className="h-5 w-5 text-amber-500" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{totalInterventions}</p>
              <p className="text-sm text-muted-foreground">Interventions</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Pattern Preview */}
      {sortedCategories.length > 0 && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-lg">Pattern Summary</CardTitle>
            <CardDescription>Key patterns identified from observations</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {sortedCategories.slice(0, 5).map((cat) => (
                <div key={cat.name} className="flex items-center justify-between">
                  <span className="text-foreground">{cat.name}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">{cat.count} observations</span>
                    <span className={`text-sm font-medium ${cat.avgSeverity > 3 ? "text-red-500" : cat.avgSeverity > 2 ? "text-amber-500" : "text-emerald-500"}`}>
                      Avg: {cat.avgSeverity}/5
                    </span>
                  </div>
                </div>
              ))}
            </div>
            {mostCommonTime && (
              <p className="mt-4 pt-4 border-t border-border text-sm text-muted-foreground">
                <Calendar className="h-4 w-4 inline mr-1" />
                Most common time: <strong className="text-foreground">{mostCommonTime[0]}</strong> ({mostCommonTime[1]} observations)
              </p>
            )}
          </CardContent>
        </Card>
      )}

      {/* Interventions Preview */}
      {totalInterventions > 0 && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-lg">Interventions Summary</CardTitle>
            <CardDescription>Strategies tried and their outcomes</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <CheckCircle className="h-4 w-4 text-emerald-500" />
                  <span className="font-medium text-foreground">Successful ({successfulInterventions.length})</span>
                </div>
                {successfulInterventions.length > 0 ? (
                  <ul className="text-sm text-muted-foreground space-y-1">
                    {successfulInterventions.slice(0, 3).map((i) => (
                      <li key={i.id}>• {i.name}</li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-sm text-muted-foreground">None recorded</p>
                )}
              </div>
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <XCircle className="h-4 w-4 text-red-500" />
                  <span className="font-medium text-foreground">Unsuccessful ({unsuccessfulInterventions.length})</span>
                </div>
                {unsuccessfulInterventions.length > 0 ? (
                  <ul className="text-sm text-muted-foreground space-y-1">
                    {unsuccessfulInterventions.slice(0, 3).map((i) => (
                      <li key={i.id}>• {i.name}</li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-sm text-muted-foreground">None recorded</p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Generate Button */}
      <GenerateReportButton childId={childId} reportData={reportData} assessmentId={aiAssessment?.id} />

      {/* Report Types */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle className="text-lg">Report Types Available</CardTitle>
          <CardDescription>Choose the right format for your audience</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="flex items-start gap-3 p-3 rounded-lg border">
              <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center flex-shrink-0">
                <Users className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <p className="font-medium">Parent Summary</p>
                <p className="text-sm text-muted-foreground">Warm, accessible language for families</p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 rounded-lg border">
              <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center flex-shrink-0">
                <School className="h-5 w-5 text-green-500" />
              </div>
              <div>
                <p className="font-medium">Teacher Summary</p>
                <p className="text-sm text-muted-foreground">Professional classroom-focused report</p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 rounded-lg border">
              <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center flex-shrink-0">
                <Stethoscope className="h-5 w-5 text-purple-500" />
              </div>
              <div>
                <p className="font-medium">Clinical Summary</p>
                <p className="text-sm text-muted-foreground">Formal report for health professionals</p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 rounded-lg border">
              <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center flex-shrink-0">
                <FileCheck className="h-5 w-5 text-amber-500" />
              </div>
              <div>
                <p className="font-medium">EHCP Evidence</p>
                <p className="text-sm text-muted-foreground">Structured evidence for EHCP applications</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* AI Assessment Status */}
      {aiAssessment ? (
        <Card className="mt-6 border-primary/30 bg-primary/5">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <CheckCircle className="h-5 w-5 text-primary" />
                <div>
                  <p className="font-medium">AI Assessment Available</p>
                  <p className="text-sm text-muted-foreground">
                    {aiAssessment.observation_count} observations analyzed • {new Date(aiAssessment.created_at).toLocaleDateString("en-GB")}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant={aiAssessment.risk_status === 'green' ? 'default' : aiAssessment.risk_status === 'amber' ? 'secondary' : 'destructive'}>
                  {aiAssessment.risk_status?.toUpperCase()}
                </Badge>
                <Badge variant="outline">{Math.round((aiAssessment.pattern_confidence || 0) * 100)}% confidence</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card className="mt-6 border-amber-500/30 bg-amber-500/5">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <AlertTriangle className="h-5 w-5 text-amber-500" />
              <div>
                <p className="font-medium">No AI Assessment Yet</p>
                <p className="text-sm text-muted-foreground">
                  Run an AI assessment first for more comprehensive reports. <Link href="/dashboard/ai" className="text-primary hover:underline">Go to AI Control Centre</Link>
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
