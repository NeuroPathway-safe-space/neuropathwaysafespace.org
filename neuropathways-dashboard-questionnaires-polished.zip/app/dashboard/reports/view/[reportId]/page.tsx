import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { ArrowLeft, Printer, Calendar, TrendingUp, CheckCircle, XCircle, AlertTriangle } from "lucide-react";

export default async function ViewReportPage({
  params,
}: {
  params: Promise<{ reportId: string }>;
}) {
  const { reportId } = await params;
  const supabase = await createClient();

  const { data: report } = await supabase
    .from("ehcp_reports")
    .select("*")
    .eq("id", reportId)
    .single();

  if (!report) {
    redirect("/dashboard/reports");
  }

  const data = report.report_data as {
    child: { firstName: string; lastName: string | null; schoolYear: string | null };
    summary: { totalObservations: number; totalInterventions: number; dateRange: { from: string; to: string } | null };
    patterns: Array<{ name: string; count: number; avgSeverity: number }>;
    timePatterns: Array<{ time: string; count: number }>;
    interventions: { successful: Array<{ name: string; notes: string | null }>; unsuccessful: Array<{ name: string; notes: string | null }> };
    observations: Array<{ category: string; severity: number; notes: string | null; triggers: string | null; date: string; timeOfDay: string | null }>;
  };

  const topPattern = data.patterns[0];
  const topTime = data.timePatterns.sort((a, b) => b.count - a.count)[0];

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <div className="flex items-center justify-between mb-6">
        <Link href="/dashboard/reports" className="flex items-center gap-2 text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" />
          Back to Reports
        </Link>
        <Button variant="outline" className="gap-2" onClick={() => window.print()}>
          <Printer className="h-4 w-4" />
          Print / Save PDF
        </Button>
      </div>

      {/* Report Header */}
      <div className="mb-8 text-center print:mb-4">
        <h1 className="text-3xl font-bold text-foreground mb-2">
          EHCP Evidence Report
        </h1>
        <p className="text-xl text-muted-foreground">
          {data.child.firstName} {data.child.lastName}
          {data.child.schoolYear && ` - Year ${data.child.schoolYear}`}
        </p>
        <p className="text-sm text-muted-foreground mt-2">
          Generated: {new Date(report.generated_at).toLocaleDateString("en-GB", { 
            day: "numeric", 
            month: "long", 
            year: "numeric" 
          })}
        </p>
      </div>

      {/* Executive Summary */}
      <Card className="mb-6 print:shadow-none print:border">
        <CardHeader>
          <CardTitle>Executive Summary</CardTitle>
        </CardHeader>
        <CardContent className="prose prose-sm max-w-none text-foreground">
          <p>
            This report summarises <strong>{data.summary.totalObservations} observations</strong> recorded 
            {data.summary.dateRange && (
              <> between {new Date(data.summary.dateRange.from).toLocaleDateString("en-GB")} and {new Date(data.summary.dateRange.to).toLocaleDateString("en-GB")}</>
            )}.
            {data.summary.totalInterventions > 0 && (
              <> A total of <strong>{data.summary.totalInterventions} interventions</strong> have been documented.</>
            )}
          </p>
          {topPattern && (
            <p>
              The most frequently observed area of concern is <strong>{topPattern.name}</strong>, 
              recorded {topPattern.count} times with an average severity of {topPattern.avgSeverity}/5.
              {topTime && (
                <> These behaviours are most commonly observed during <strong>{topTime.time.toLowerCase()}</strong>.</>
              )}
            </p>
          )}
          <p className="text-muted-foreground italic">
            This evidence demonstrates persistent needs that require additional support beyond what is currently available.
          </p>
        </CardContent>
      </Card>

      {/* Pattern Analysis */}
      <Card className="mb-6 print:shadow-none print:border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            Behaviour Patterns
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {data.patterns.map((pattern) => (
              <div key={pattern.name} className="border-b border-border pb-4 last:border-0 last:pb-0">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium text-foreground">{pattern.name}</h4>
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-muted-foreground">{pattern.count} occurrences</span>
                    <span className={`text-sm font-medium px-2 py-0.5 rounded ${
                      pattern.avgSeverity > 3 ? "bg-red-500/10 text-red-500" : 
                      pattern.avgSeverity > 2 ? "bg-amber-500/10 text-amber-500" : 
                      "bg-emerald-500/10 text-emerald-500"
                    }`}>
                      Severity: {pattern.avgSeverity}/5
                    </span>
                  </div>
                </div>
                <div className="h-2 bg-secondary rounded-full overflow-hidden">
                  <div
                    className="h-full bg-primary rounded-full"
                    style={{ width: `${(pattern.count / data.summary.totalObservations) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Time Patterns */}
      {data.timePatterns.length > 0 && (
        <Card className="mb-6 print:shadow-none print:border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-cyan-500" />
              Time of Day Analysis
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3 md:grid-cols-2">
              {data.timePatterns.sort((a, b) => b.count - a.count).map((time) => (
                <div key={time.time} className="flex items-center justify-between p-3 rounded-lg bg-secondary/50">
                  <span className="text-foreground">{time.time}</span>
                  <span className="text-muted-foreground">{time.count} observations</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Interventions */}
      <Card className="mb-6 print:shadow-none print:border">
        <CardHeader>
          <CardTitle>Interventions Tried</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 md:grid-cols-2">
            <div>
              <div className="flex items-center gap-2 mb-3">
                <CheckCircle className="h-5 w-5 text-emerald-500" />
                <h4 className="font-medium text-foreground">Successful Strategies</h4>
              </div>
              {data.interventions.successful.length > 0 ? (
                <ul className="space-y-2">
                  {data.interventions.successful.map((i, idx) => (
                    <li key={idx} className="text-sm">
                      <span className="font-medium text-foreground">{i.name}</span>
                      {i.notes && <p className="text-muted-foreground">{i.notes}</p>}
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-sm text-muted-foreground">No successful interventions documented</p>
              )}
            </div>
            <div>
              <div className="flex items-center gap-2 mb-3">
                <XCircle className="h-5 w-5 text-red-500" />
                <h4 className="font-medium text-foreground">Unsuccessful Strategies</h4>
              </div>
              {data.interventions.unsuccessful.length > 0 ? (
                <ul className="space-y-2">
                  {data.interventions.unsuccessful.map((i, idx) => (
                    <li key={idx} className="text-sm">
                      <span className="font-medium text-foreground">{i.name}</span>
                      {i.notes && <p className="text-muted-foreground">{i.notes}</p>}
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-sm text-muted-foreground">No unsuccessful interventions documented</p>
              )}
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-border">
            <p className="text-sm text-muted-foreground flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-amber-500" />
              Multiple intervention strategies have been tried, demonstrating that additional support is required.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Recent Observations */}
      {data.observations && data.observations.length > 0 && (
        <Card className="mb-6 print:shadow-none print:border">
          <CardHeader>
            <CardTitle>Recent Observations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {data.observations.slice(0, 10).map((obs, idx) => (
                <div key={idx} className="p-3 rounded-lg bg-secondary/30 border border-border">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-medium text-foreground">{obs.category}</span>
                    <span className="text-xs text-muted-foreground">
                      {new Date(obs.date).toLocaleDateString("en-GB")}
                      {obs.timeOfDay && ` - ${obs.timeOfDay}`}
                    </span>
                  </div>
                  {obs.notes && <p className="text-sm text-muted-foreground">{obs.notes}</p>}
                  {obs.triggers && (
                    <p className="text-xs text-muted-foreground mt-1">
                      <strong>Triggers:</strong> {obs.triggers}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Footer */}
      <div className="text-center text-sm text-muted-foreground print:mt-8">
        <p>This report was generated by NeuroPathway Safe Space</p>
        <p>For SEND reviews, EHCP applications, and professional meetings</p>
      </div>
    </div>
  );
}
