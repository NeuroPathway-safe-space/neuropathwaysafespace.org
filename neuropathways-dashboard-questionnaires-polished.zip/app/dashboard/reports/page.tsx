import { createClient } from "@/lib/supabase/server";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { FileText, Plus, Calendar, Download, ArrowLeft, Users, School, Stethoscope, FileCheck, Eye, Check, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ReportActions } from "./report-actions";

const reportTypeConfig: Record<string, { icon: typeof Users; label: string; color: string }> = {
  parent_summary: { icon: Users, label: 'Parent Summary', color: 'bg-blue-500/10 text-blue-500' },
  teacher_summary: { icon: School, label: 'Teacher Summary', color: 'bg-green-500/10 text-green-500' },
  clinical_summary: { icon: Stethoscope, label: 'Clinical Summary', color: 'bg-purple-500/10 text-purple-500' },
  ehcp_evidence: { icon: FileCheck, label: 'EHCP Evidence', color: 'bg-amber-500/10 text-amber-500' }
};

export default async function ReportsPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  // Get children
  const { data: children } = await supabase
    .from("children")
    .select("id, first_name, last_name")
    .order("first_name");

  // Get AI-generated reports
  const { data: aiReports } = await supabase
    .from("ai_reports")
    .select(`*, children (first_name, last_name)`)
    .order("created_at", { ascending: false });

  // Get legacy EHCP reports
  const { data: legacyReports } = await supabase
    .from("ehcp_reports")
    .select(`*, children (first_name, last_name)`)
    .order("created_at", { ascending: false });

  const allReports = [
    ...(aiReports || []).map(r => ({ ...r, source: 'ai' })),
    ...(legacyReports || []).map(r => ({ ...r, source: 'legacy', report_type: 'ehcp_evidence' }))
  ].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

  const pendingReports = allReports.filter(r => r.status === 'draft' || r.status === 'pending_review');
  const approvedReports = allReports.filter(r => r.status === 'approved' || r.status === 'final');

  return (
    <div className="max-w-5xl mx-auto px-4 py-6">
      <Link href="/dashboard" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4">
        <ArrowLeft className="h-4 w-4" />
        Back to Dashboard
      </Link>
      
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">EHCP Evidence Reports</h1>
        <p className="text-muted-foreground">Generate AI-powered reports for different audiences</p>
      </div>

      {/* Report Type Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {Object.entries(reportTypeConfig).map(([key, config]) => {
          const count = allReports.filter(r => r.report_type === key).length;
          const Icon = config.icon;
          return (
            <Card key={key}>
              <CardContent className="p-4">
                <div className={`w-10 h-10 rounded-lg ${config.color} flex items-center justify-center mb-3`}>
                  <Icon className="h-5 w-5" />
                </div>
                <p className="font-medium text-sm">{config.label}</p>
                <p className="text-2xl font-bold">{count}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Generate New Report */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-lg">Generate New Report</CardTitle>
          <CardDescription>Select a child and report type to create an AI-powered report</CardDescription>
        </CardHeader>
        <CardContent>
          {children && children.length > 0 ? (
            <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
              {children.map((child) => (
                <Link key={child.id} href={`/dashboard/reports/generate/${child.id}`}>
                  <Card className="hover:border-primary/50 transition-colors cursor-pointer">
                    <CardContent className="p-4 flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <span className="text-sm font-medium text-primary">
                          {child.first_name?.charAt(0)}
                        </span>
                      </div>
                      <div>
                        <p className="font-medium text-foreground">
                          {child.first_name} {child.last_name}
                        </p>
                        <p className="text-sm text-muted-foreground">Generate report</p>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          ) : (
            <div className="text-center py-6">
              <p className="text-muted-foreground mb-4">Add a child first to generate reports</p>
              <Link href="/dashboard/children/new">
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Child
                </Button>
              </Link>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Reports List with Tabs */}
      <Card>
        <CardHeader className="pb-0">
          <Tabs defaultValue="all">
            <TabsList>
              <TabsTrigger value="all">All Reports ({allReports.length})</TabsTrigger>
              <TabsTrigger value="pending">Pending Review ({pendingReports.length})</TabsTrigger>
              <TabsTrigger value="approved">Approved ({approvedReports.length})</TabsTrigger>
            </TabsList>
            
            <TabsContent value="all" className="mt-4">
              <ReportsList reports={allReports} reportTypeConfig={reportTypeConfig} />
            </TabsContent>
            
            <TabsContent value="pending" className="mt-4">
              <ReportsList reports={pendingReports} reportTypeConfig={reportTypeConfig} showActions />
            </TabsContent>
            
            <TabsContent value="approved" className="mt-4">
              <ReportsList reports={approvedReports} reportTypeConfig={reportTypeConfig} />
            </TabsContent>
          </Tabs>
        </CardHeader>
      </Card>
    </div>
  );
}

function ReportsList({ 
  reports, 
  reportTypeConfig,
  showActions = false 
}: { 
  reports: Array<{
    id: string;
    title?: string;
    report_type?: string;
    status?: string;
    version?: number;
    created_at: string;
    source: string;
    children?: { first_name: string; last_name: string };
    content?: unknown;
  }>;
  reportTypeConfig: Record<string, { icon: typeof Users; label: string; color: string }>;
  showActions?: boolean;
}) {
  if (reports.length === 0) {
    return (
      <div className="text-center py-12">
        <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
        <p className="text-muted-foreground">No reports in this category</p>
      </div>
    );
  }

  return (
    <div className="space-y-3 pb-4">
      {reports.map((report) => {
        const config = reportTypeConfig[report.report_type || 'ehcp_evidence'];
        const Icon = config?.icon || FileText;
        
        return (
          <div
            key={report.id}
            className="flex items-center justify-between p-4 rounded-lg border border-border hover:bg-muted/30 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-lg ${config?.color || 'bg-gray-500/10'} flex items-center justify-center`}>
                <Icon className="h-5 w-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <p className="font-medium text-foreground">
                    {report.title || `${report.children?.first_name} ${report.children?.last_name} Report`}
                  </p>
                  <Badge variant={
                    report.status === 'approved' || report.status === 'final' ? 'default' :
                    report.status === 'draft' ? 'secondary' : 'outline'
                  }>
                    {report.status || 'generated'}
                  </Badge>
                  {report.source === 'ai' && (
                    <Badge variant="outline" className="text-xs bg-violet-500/10 text-violet-500 border-violet-500/20">
                      AI
                    </Badge>
                  )}
                </div>
                <p className="text-sm text-muted-foreground flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  {new Date(report.created_at).toLocaleDateString("en-GB")}
                  {report.version && report.version > 1 && ` • v${report.version}`}
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              {report.source === 'ai' ? (
                <ReportActions reportId={report.id} status={report.status} showReviewActions={showActions} />
              ) : (
                <Link href={`/dashboard/reports/view/${report.id}`}>
                  <Button variant="outline" size="sm" className="gap-2">
                    <Eye className="h-4 w-4" />
                    View
                  </Button>
                </Link>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
