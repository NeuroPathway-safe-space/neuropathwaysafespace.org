"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState, useEffect } from "react";
import { Shield, Bell, Lock, Database, ArrowLeft, Key, Copy, Check, Plus, Trash2, Loader2 } from "lucide-react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type InviteCode = {
  id: string;
  code: string;
  created_by: string | null;
  used_by: string | null;
  used_at: string | null;
  expires_at: string | null;
  max_uses: number;
  current_uses: number;
  is_active: boolean;
  created_at: string;
};

export default function AdminSettingsPage() {
  const [settings, setSettings] = useState({
    rateLimitEnabled: true,
    auditLoggingEnabled: true,
    ipBlockingEnabled: true,
    requireEmailVerification: true,
    allowSignups: true,
    maxObservationsPerDay: 100,
    sessionTimeoutMinutes: 60,
  });

  const [inviteCodes, setInviteCodes] = useState<InviteCode[]>([]);
  const [loadingCodes, setLoadingCodes] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [expiresIn, setExpiresIn] = useState("7");
  const [maxUses, setMaxUses] = useState("1");
  const [actionLoading, setActionLoading] = useState(false);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const supabase = createClient();

  useEffect(() => {
    fetchInviteCodes();
  }, []);

  const fetchInviteCodes = async () => {
    setLoadingCodes(true);
    const { data } = await supabase
      .from("admin_invite_codes")
      .select("*")
      .order("created_at", { ascending: false });
    setInviteCodes(data || []);
    setLoadingCodes(false);
  };

  const generateCode = () => {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    let code = "NEURO-ADMIN-";
    for (let i = 0; i < 8; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
  };

  const handleCreateCode = async () => {
    setActionLoading(true);

    const { data: { user } } = await supabase.auth.getUser();

    const expiresAt = expiresIn === "never" 
      ? null 
      : new Date(Date.now() + parseInt(expiresIn) * 24 * 60 * 60 * 1000).toISOString();

    await supabase.from("admin_invite_codes").insert({
      code: generateCode(),
      created_by: user?.id || null,
      expires_at: expiresAt,
      max_uses: parseInt(maxUses),
    });

    setDialogOpen(false);
    setExpiresIn("7");
    setMaxUses("1");
    await fetchInviteCodes();
    setActionLoading(false);
  };

  const handleDeleteCode = async (id: string) => {
    setActionLoading(true);
    await supabase.from("admin_invite_codes").delete().eq("id", id);
    await fetchInviteCodes();
    setActionLoading(false);
  };

  const handleDeactivateCode = async (id: string) => {
    setActionLoading(true);
    await supabase.from("admin_invite_codes").update({ is_active: false }).eq("id", id);
    await fetchInviteCodes();
    setActionLoading(false);
  };

  const copyToClipboard = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const handleToggle = (key: keyof typeof settings) => {
    setSettings((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const isExpired = (expiresAt: string | null) => {
    if (!expiresAt) return false;
    return new Date(expiresAt) < new Date();
  };

  return (
    <div className="p-4 md:p-6">
      <div className="mb-8">
        <Link href="/admin" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4">
          <ArrowLeft className="h-4 w-4" />
          Back to Admin
        </Link>
        <h1 className="text-2xl font-bold text-foreground">Admin Settings</h1>
        <p className="text-muted-foreground">Configure platform security and behaviour</p>
      </div>

      <div className="space-y-6 max-w-2xl">
        {/* Admin Invite Codes */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Key className="h-5 w-5 text-amber-500" />
                  Admin Invite Codes
                </CardTitle>
                <CardDescription>Generate secure codes to invite new admins</CardDescription>
              </div>
              <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                <DialogTrigger asChild>
                  <Button size="sm">
                    <Plus className="mr-2 h-4 w-4" />
                    New Code
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Generate Admin Invite Code</DialogTitle>
                    <DialogDescription>
                      Create a secure code that can be used to register as an admin.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label>Expires In</Label>
                      <Select value={expiresIn} onValueChange={setExpiresIn}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">1 day</SelectItem>
                          <SelectItem value="7">7 days</SelectItem>
                          <SelectItem value="30">30 days</SelectItem>
                          <SelectItem value="never">Never</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Maximum Uses</Label>
                      <Select value={maxUses} onValueChange={setMaxUses}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">1 use</SelectItem>
                          <SelectItem value="5">5 uses</SelectItem>
                          <SelectItem value="10">10 uses</SelectItem>
                          <SelectItem value="999">Unlimited</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleCreateCode} disabled={actionLoading}>
                      {actionLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                      Generate Code
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent>
            {loadingCodes ? (
              <div className="flex justify-center py-4">
                <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
              </div>
            ) : inviteCodes.length > 0 ? (
              <div className="space-y-3">
                {inviteCodes.map((code) => (
                  <div
                    key={code.id}
                    className={`p-4 rounded-lg border ${
                      !code.is_active || isExpired(code.expires_at) || code.current_uses >= code.max_uses
                        ? "border-muted bg-muted/30"
                        : "border-border"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <code className="font-mono text-sm font-bold">{code.code}</code>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6"
                            onClick={() => copyToClipboard(code.code)}
                          >
                            {copiedCode === code.code ? (
                              <Check className="h-3 w-3 text-green-500" />
                            ) : (
                              <Copy className="h-3 w-3" />
                            )}
                          </Button>
                          {!code.is_active && (
                            <span className="text-xs bg-muted text-muted-foreground px-2 py-0.5 rounded">
                              Deactivated
                            </span>
                          )}
                          {isExpired(code.expires_at) && (
                            <span className="text-xs bg-red-500/10 text-red-500 px-2 py-0.5 rounded">
                              Expired
                            </span>
                          )}
                          {code.current_uses >= code.max_uses && (
                            <span className="text-xs bg-yellow-500/10 text-yellow-500 px-2 py-0.5 rounded">
                              Max Uses Reached
                            </span>
                          )}
                        </div>
                        <div className="flex gap-4 mt-2 text-xs text-muted-foreground">
                          <span>Uses: {code.current_uses}/{code.max_uses}</span>
                          {code.expires_at && (
                            <span>Expires: {new Date(code.expires_at).toLocaleDateString()}</span>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {code.is_active && !isExpired(code.expires_at) && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeactivateCode(code.id)}
                            disabled={actionLoading}
                          >
                            Deactivate
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-destructive hover:text-destructive"
                          onClick={() => handleDeleteCode(code.id)}
                          disabled={actionLoading}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-4">
                <Key className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">No invite codes yet</p>
                <p className="text-xs text-muted-foreground">Generate a code to invite new admins</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Security Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Shield className="h-5 w-5 text-amber-500" />
              Security Settings
            </CardTitle>
            <CardDescription>Configure security features</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="rate-limit">Rate Limiting</Label>
                <p className="text-sm text-muted-foreground">
                  Limit requests per user to prevent abuse
                </p>
              </div>
              <Switch
                id="rate-limit"
                checked={settings.rateLimitEnabled}
                onCheckedChange={() => handleToggle("rateLimitEnabled")}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="ip-blocking">IP Blocking</Label>
                <p className="text-sm text-muted-foreground">
                  Block suspicious IP addresses
                </p>
              </div>
              <Switch
                id="ip-blocking"
                checked={settings.ipBlockingEnabled}
                onCheckedChange={() => handleToggle("ipBlockingEnabled")}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="audit-logging">Audit Logging</Label>
                <p className="text-sm text-muted-foreground">
                  Log all user actions for compliance
                </p>
              </div>
              <Switch
                id="audit-logging"
                checked={settings.auditLoggingEnabled}
                onCheckedChange={() => handleToggle("auditLoggingEnabled")}
              />
            </div>
          </CardContent>
        </Card>

        {/* Authentication Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Lock className="h-5 w-5 text-blue-500" />
              Authentication
            </CardTitle>
            <CardDescription>Configure user authentication</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="email-verification">Require Email Verification</Label>
                <p className="text-sm text-muted-foreground">
                  Users must verify email before access
                </p>
              </div>
              <Switch
                id="email-verification"
                checked={settings.requireEmailVerification}
                onCheckedChange={() => handleToggle("requireEmailVerification")}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="allow-signups">Allow New Signups</Label>
                <p className="text-sm text-muted-foreground">
                  Allow new users to register
                </p>
              </div>
              <Switch
                id="allow-signups"
                checked={settings.allowSignups}
                onCheckedChange={() => handleToggle("allowSignups")}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="session-timeout">Session Timeout (minutes)</Label>
              <Input
                id="session-timeout"
                type="number"
                value={settings.sessionTimeoutMinutes}
                onChange={(e) =>
                  setSettings((prev) => ({
                    ...prev,
                    sessionTimeoutMinutes: parseInt(e.target.value) || 60,
                  }))
                }
                className="max-w-32"
              />
            </div>
          </CardContent>
        </Card>

        {/* Limits Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Database className="h-5 w-5 text-green-500" />
              Usage Limits
            </CardTitle>
            <CardDescription>Configure platform limits</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="max-observations">Max Observations Per User Per Day</Label>
              <Input
                id="max-observations"
                type="number"
                value={settings.maxObservationsPerDay}
                onChange={(e) =>
                  setSettings((prev) => ({
                    ...prev,
                    maxObservationsPerDay: parseInt(e.target.value) || 100,
                  }))
                }
                className="max-w-32"
              />
              <p className="text-xs text-muted-foreground">
                Set to 0 for unlimited
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Notifications Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Bell className="h-5 w-5 text-purple-500" />
              Notifications
            </CardTitle>
            <CardDescription>Configure admin notifications</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Email notification settings coming soon. Configure alerts for new signups,
              suspicious activity, and system health.
            </p>
          </CardContent>
        </Card>

        {/* Save Button */}
        <div className="flex justify-end">
          <Button onClick={() => alert("Settings saved!")}>Save Settings</Button>
        </div>
      </div>
    </div>
  );
}
