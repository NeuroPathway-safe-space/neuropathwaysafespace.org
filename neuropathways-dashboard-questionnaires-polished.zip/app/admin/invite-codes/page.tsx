"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, Loader2, Ticket, Copy, Check, ArrowLeft, Clock, CheckCircle, XCircle, Users, Shield, School, Stethoscope, User } from "lucide-react";
import Link from "next/link";

type InviteCode = {
  id: string;
  code: string;
  created_by: string | null;
  role: string;
  max_uses: number;
  uses_count: number;
  expires_at: string | null;
  is_active: boolean;
  notes: string | null;
  created_at: string;
};

const ROLE_CONFIG = {
  admin: { label: "Administrator", icon: Shield, color: "text-red-500", bgColor: "bg-red-500/10" },
  clinician: { label: "Clinician", icon: Stethoscope, color: "text-purple-500", bgColor: "bg-purple-500/10" },
  teacher: { label: "Teacher/SENCO", icon: School, color: "text-blue-500", bgColor: "bg-blue-500/10" },
  parent: { label: "Parent/Carer", icon: User, color: "text-green-500", bgColor: "bg-green-500/10" },
  user: { label: "Standard User", icon: Users, color: "text-gray-500", bgColor: "bg-gray-500/10" },
};

export default function InviteCodesPage() {
  const [codes, setCodes] = useState<InviteCode[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [role, setRole] = useState("parent");
  const [expiresIn, setExpiresIn] = useState("168");
  const [maxUses, setMaxUses] = useState("1");
  const [notes, setNotes] = useState("");
  const [actionLoading, setActionLoading] = useState(false);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [newCode, setNewCode] = useState<string | null>(null);

  const supabase = createClient();

  useEffect(() => {
    fetchCodes();
  }, []);

  const fetchCodes = async () => {
    setLoading(true);
    const { data } = await supabase
      .from("invite_codes")
      .select("*")
      .order("created_at", { ascending: false });
    setCodes(data || []);
    setLoading(false);
  };

  const generateCode = (roleType: string) => {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    const prefix = roleType === "admin" ? "ADMIN" : 
                   roleType === "clinician" ? "CLIN" :
                   roleType === "teacher" ? "EDU" : "NP";
    let result = `${prefix}-`;
    for (let i = 0; i < 8; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  };

  const handleCreateCode = async () => {
    setActionLoading(true);

    const { data: { user } } = await supabase.auth.getUser();
    const code = generateCode(role);

    let expiresAt: string | null = null;
    if (expiresIn !== "permanent") {
      const hours = parseInt(expiresIn);
      expiresAt = new Date(Date.now() + hours * 60 * 60 * 1000).toISOString();
    }

    const { error } = await supabase.from("invite_codes").insert({
      code,
      created_by: user?.id || null,
      role,
      expires_at: expiresAt,
      max_uses: parseInt(maxUses),
      notes: notes || null,
    });

    if (!error) {
      setNewCode(code);
      await fetchCodes();
    }

    setActionLoading(false);
  };

  const handleDeactivateCode = async (id: string) => {
    setActionLoading(true);
    
    await supabase
      .from("invite_codes")
      .update({ is_active: false })
      .eq("id", id);

    await fetchCodes();
    setActionLoading(false);
  };

  const handleDeleteCode = async (id: string) => {
    setActionLoading(true);
    await supabase.from("invite_codes").delete().eq("id", id);
    await fetchCodes();
    setActionLoading(false);
  };

  const copyToClipboard = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const isExpired = (expiresAt: string | null) => {
    if (!expiresAt) return false;
    return new Date(expiresAt) < new Date();
  };

  const getCodeStatus = (code: InviteCode) => {
    if (!code.is_active) return { label: "Deactivated", variant: "secondary" as const };
    if (isExpired(code.expires_at)) return { label: "Expired", variant: "outline" as const };
    if (code.uses_count >= code.max_uses) return { label: "Exhausted", variant: "outline" as const };
    return { label: "Active", variant: "default" as const };
  };

  // Stats
  const activeCodes = codes.filter(c => c.is_active && !isExpired(c.expires_at) && c.uses_count < c.max_uses).length;
  const totalUses = codes.reduce((sum, c) => sum + (c.uses_count || 0), 0);

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <Link href="/admin" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4">
            <ArrowLeft className="h-4 w-4" />
            Back to Admin
          </Link>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-3">
            <Ticket className="h-7 w-7 text-primary" />
            Invite Codes
          </h1>
          <p className="text-muted-foreground">Manage registration invite codes for all user roles</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={(open) => {
          setDialogOpen(open);
          if (!open) {
            setNewCode(null);
            setNotes("");
            setRole("parent");
          }
        }}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Create Code
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create Invite Code</DialogTitle>
              <DialogDescription>
                Generate a new invite code for user registration
              </DialogDescription>
            </DialogHeader>
            
            {newCode ? (
              <div className="py-6">
                <div className="text-center mb-4">
                  <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-3" />
                  <p className="text-sm text-muted-foreground mb-2">Code generated successfully!</p>
                </div>
                <div className="bg-secondary rounded-lg p-4 text-center">
                  <p className="font-mono text-xl font-bold tracking-wider text-foreground mb-2">
                    {newCode}
                  </p>
                  <div className="flex items-center justify-center gap-2 mb-3">
                    <Badge variant={role === "admin" ? "destructive" : "secondary"}>
                      {ROLE_CONFIG[role as keyof typeof ROLE_CONFIG]?.label || role}
                    </Badge>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => copyToClipboard(newCode)}
                  >
                    {copiedCode === newCode ? (
                      <>
                        <Check className="mr-2 h-4 w-4" />
                        Copied!
                      </>
                    ) : (
                      <>
                        <Copy className="mr-2 h-4 w-4" />
                        Copy Code
                      </>
                    )}
                  </Button>
                </div>
                <p className="text-xs text-center text-muted-foreground mt-4">
                  Share this code securely with the person you want to register
                </p>
              </div>
            ) : (
              <>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label>User Role</Label>
                    <Select value={role} onValueChange={setRole}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="parent">
                          <span className="flex items-center gap-2">
                            <User className="h-4 w-4 text-green-500" />
                            Parent / Carer
                          </span>
                        </SelectItem>
                        <SelectItem value="teacher">
                          <span className="flex items-center gap-2">
                            <School className="h-4 w-4 text-blue-500" />
                            Teacher / SENCO
                          </span>
                        </SelectItem>
                        <SelectItem value="clinician">
                          <span className="flex items-center gap-2">
                            <Stethoscope className="h-4 w-4 text-purple-500" />
                            Clinician / Health Professional
                          </span>
                        </SelectItem>
                        <SelectItem value="admin">
                          <span className="flex items-center gap-2">
                            <Shield className="h-4 w-4 text-red-500" />
                            Administrator
                          </span>
                        </SelectItem>
                      </SelectContent>
                    </Select>
                    {role === "admin" && (
                      <p className="text-xs text-amber-500">Admin codes grant full system access. Use with caution.</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label>Expiration</Label>
                    <Select value={expiresIn} onValueChange={setExpiresIn}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="24">24 hours</SelectItem>
                        <SelectItem value="168">7 days</SelectItem>
                        <SelectItem value="720">30 days</SelectItem>
                        <SelectItem value="2160">90 days</SelectItem>
                        <SelectItem value="permanent">Never expires</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Maximum Uses</Label>
                    <Select value={maxUses} onValueChange={setMaxUses}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 use (single user)</SelectItem>
                        <SelectItem value="5">5 uses</SelectItem>
                        <SelectItem value="10">10 uses</SelectItem>
                        <SelectItem value="25">25 uses</SelectItem>
                        <SelectItem value="100">100 uses</SelectItem>
                        <SelectItem value="999">Unlimited</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Notes (optional)</Label>
                    <Textarea
                      placeholder="e.g., For Oakwood Primary School pilot"
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      rows={2}
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleCreateCode} disabled={actionLoading}>
                    {actionLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Generate Code
                  </Button>
                </DialogFooter>
              </>
            )}
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-3 mb-6">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <Ticket className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{codes.length}</p>
                <p className="text-sm text-muted-foreground">Total Codes</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center">
                <CheckCircle className="h-5 w-5 text-green-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{activeCodes}</p>
                <p className="text-sm text-muted-foreground">Active Codes</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
                <Users className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalUses}</p>
                <p className="text-sm text-muted-foreground">Total Registrations</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Registration Link Info */}
      <Card className="mb-6 border-primary/20 bg-primary/5">
        <CardContent className="py-4">
          <div className="flex items-center gap-3">
            <Ticket className="h-5 w-5 text-primary" />
            <div className="flex-1">
              <p className="text-sm font-medium text-foreground">Registration Link</p>
              <p className="text-xs text-muted-foreground">Share this link along with an invite code</p>
            </div>
            <code className="text-xs bg-background px-2 py-1 rounded hidden md:block">
              {typeof window !== 'undefined' ? `${window.location.origin}/auth/sign-up` : '/auth/sign-up'}
            </code>
            <Button
              variant="outline"
              size="sm"
              onClick={() => copyToClipboard(`${window.location.origin}/auth/sign-up`)}
            >
              {copiedCode === `${window.location.origin}/auth/sign-up` ? (
                <>
                  <Check className="mr-2 h-4 w-4" />
                  Copied!
                </>
              ) : (
                <>
                  <Copy className="mr-2 h-4 w-4" />
                  Copy
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>All Invite Codes</CardTitle>
          <CardDescription>Manage and track invite code usage</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : codes.length > 0 ? (
            <div className="space-y-3">
              {codes.map((code) => {
                const status = getCodeStatus(code);
                const roleConfig = ROLE_CONFIG[code.role as keyof typeof ROLE_CONFIG] || ROLE_CONFIG.user;
                const RoleIcon = roleConfig.icon;
                const isActive = code.is_active && !isExpired(code.expires_at) && code.uses_count < code.max_uses;

                return (
                  <div
                    key={code.id}
                    className={`flex items-center justify-between p-4 rounded-lg border ${
                      !isActive ? "border-border bg-muted/30 opacity-60" : "border-border"
                    }`}
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <code className="font-mono font-bold text-foreground bg-secondary px-2 py-1 rounded">
                          {code.code}
                        </code>
                        <Badge variant={status.variant} className={status.label === "Active" ? "bg-green-500/10 text-green-500 border-green-500/30" : ""}>
                          {status.label}
                        </Badge>
                        <div className={`flex items-center gap-1 px-2 py-0.5 rounded text-xs ${roleConfig.bgColor} ${roleConfig.color}`}>
                          <RoleIcon className="h-3 w-3" />
                          {roleConfig.label}
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6"
                          onClick={() => copyToClipboard(code.code)}
                        >
                          {copiedCode === code.code ? (
                            <Check className="h-3 w-3 text-green-500" />
                          ) : (
                            <Copy className="h-3 w-3" />
                          )}
                        </Button>
                      </div>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Users className="h-3 w-3" />
                          {code.uses_count}/{code.max_uses} uses
                        </span>
                        <span>Created {new Date(code.created_at).toLocaleDateString('en-GB')}</span>
                        {code.expires_at && (
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {isExpired(code.expires_at) ? "Expired" : `Expires ${new Date(code.expires_at).toLocaleDateString('en-GB')}`}
                          </span>
                        )}
                      </div>
                      {code.notes && (
                        <p className="text-xs text-muted-foreground mt-1 italic">{code.notes}</p>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      {isActive && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeactivateCode(code.id)}
                          disabled={actionLoading}
                        >
                          <XCircle className="h-4 w-4 mr-1" />
                          Deactivate
                        </Button>
                      )}
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-destructive hover:text-destructive"
                        onClick={() => handleDeleteCode(code.id)}
                        disabled={actionLoading}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-8">
              <Ticket className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
              <p className="text-muted-foreground">No invite codes generated yet</p>
              <p className="text-sm text-muted-foreground">
                Click &quot;Create Code&quot; to generate your first invite code
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
