"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Search, MoreVertical, Shield, Ban, UserCheck, Loader2, ArrowLeft } from "lucide-react";
import Link from "next/link";

type Profile = {
  id: string;
  user_type: string;
  first_name: string | null;
  last_name: string | null;
  organisation_name: string | null;
  is_admin: boolean;
  is_suspended: boolean;
  suspended_reason: string | null;
  created_at: string;
};

export default function AdminUsersPage() {
  const [users, setUsers] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedUser, setSelectedUser] = useState<Profile | null>(null);
  const [suspendDialogOpen, setSuspendDialogOpen] = useState(false);
  const [suspendReason, setSuspendReason] = useState("");
  const [actionLoading, setActionLoading] = useState(false);

  const supabase = createClient();

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    setLoading(true);
    const { data } = await supabase
      .from("profiles")
      .select("*")
      .order("created_at", { ascending: false });
    setUsers(data || []);
    setLoading(false);
  };

  const filteredUsers = users.filter(
    (user) =>
      user.first_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.last_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.organisation_name?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleToggleAdmin = async (user: Profile) => {
    setActionLoading(true);
    await supabase
      .from("profiles")
      .update({ is_admin: !user.is_admin })
      .eq("id", user.id);
    await fetchUsers();
    setActionLoading(false);
  };

  const handleSuspendUser = async () => {
    if (!selectedUser) return;
    setActionLoading(true);
    await supabase
      .from("profiles")
      .update({
        is_suspended: true,
        suspended_reason: suspendReason,
        suspended_at: new Date().toISOString(),
      })
      .eq("id", selectedUser.id);
    setSuspendDialogOpen(false);
    setSuspendReason("");
    setSelectedUser(null);
    await fetchUsers();
    setActionLoading(false);
  };

  const handleUnsuspendUser = async (user: Profile) => {
    setActionLoading(true);
    await supabase
      .from("profiles")
      .update({
        is_suspended: false,
        suspended_reason: null,
        suspended_at: null,
      })
      .eq("id", user.id);
    await fetchUsers();
    setActionLoading(false);
  };

  return (
    <div className="p-4 md:p-6">
      <div className="mb-6">
        <Link href="/admin" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4">
          <ArrowLeft className="h-4 w-4" />
          Back to Admin
        </Link>
        <h1 className="text-2xl font-bold text-foreground">User Management</h1>
        <p className="text-muted-foreground">View and manage all registered users</p>
      </div>

      {/* Search */}
      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search users..."
          className="pl-10"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      {/* Users List */}
      <Card>
        <CardHeader>
          <CardTitle>All Users ({filteredUsers.length})</CardTitle>
          <CardDescription>Click on a user to manage their account</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : filteredUsers.length > 0 ? (
            <div className="space-y-3">
              {filteredUsers.map((user) => (
                <div
                  key={user.id}
                  className="flex items-center justify-between p-4 rounded-lg border border-border hover:bg-accent/50 transition-colors"
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <p className="font-medium">
                        {user.first_name || "Unknown"} {user.last_name || ""}
                      </p>
                      {user.is_admin && (
                        <span className="text-xs bg-amber-500/10 text-amber-500 px-2 py-0.5 rounded flex items-center gap-1">
                          <Shield className="h-3 w-3" />
                          Admin
                        </span>
                      )}
                      {user.is_suspended && (
                        <span className="text-xs bg-red-500/10 text-red-500 px-2 py-0.5 rounded flex items-center gap-1">
                          <Ban className="h-3 w-3" />
                          Suspended
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {user.user_type} {user.organisation_name ? `• ${user.organisation_name}` : ""}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Joined {new Date(user.created_at).toLocaleDateString()}
                    </p>
                  </div>

                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => handleToggleAdmin(user)}>
                        <Shield className="mr-2 h-4 w-4" />
                        {user.is_admin ? "Remove Admin" : "Make Admin"}
                      </DropdownMenuItem>
                      {user.is_suspended ? (
                        <DropdownMenuItem onClick={() => handleUnsuspendUser(user)}>
                          <UserCheck className="mr-2 h-4 w-4" />
                          Unsuspend User
                        </DropdownMenuItem>
                      ) : (
                        <DropdownMenuItem
                          className="text-destructive"
                          onClick={() => {
                            setSelectedUser(user);
                            setSuspendDialogOpen(true);
                          }}
                        >
                          <Ban className="mr-2 h-4 w-4" />
                          Suspend User
                        </DropdownMenuItem>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center text-muted-foreground py-8">No users found</p>
          )}
        </CardContent>
      </Card>

      {/* Suspend Dialog */}
      <Dialog open={suspendDialogOpen} onOpenChange={setSuspendDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Suspend User</DialogTitle>
            <DialogDescription>
              This will prevent {selectedUser?.first_name} from accessing the platform.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="reason">Reason for suspension</Label>
              <Textarea
                id="reason"
                placeholder="Enter reason..."
                value={suspendReason}
                onChange={(e) => setSuspendReason(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSuspendDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={handleSuspendUser}
              disabled={actionLoading}
            >
              {actionLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Suspend User
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
