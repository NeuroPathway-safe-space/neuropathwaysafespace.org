import { createClient } from "@/lib/supabase/server";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, FileText, AlertTriangle, Activity, Ban, ClipboardList } from "lucide-react";
import Link from "next/link";

export default async function AdminDashboard() {
  const supabase = await createClient();

  // Fetch stats
  const [
    { count: totalUsers },
    { count: totalObservations },
    { count: totalChildren },
    { count: blockedIPs },
    { count: recentAuditLogs },
    { data: recentUsers },
  ] = await Promise.all([
    supabase.from("profiles").select("*", { count: "exact", head: true }),
    supabase.from("observations").select("*", { count: "exact", head: true }),
    supabase.from("children").select("*", { count: "exact", head: true }),
    supabase.from("blocked_ips").select("*", { count: "exact", head: true }),
    supabase
      .from("audit_logs")
      .select("*", { count: "exact", head: true })
      .gte("created_at", new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString()),
    supabase
      .from("profiles")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(5),
  ]);

  const stats = [
    {
      title: "Total Users",
      value: totalUsers || 0,
      icon: Users,
      href: "/admin/users",
      color: "text-blue-500",
    },
    {
      title: "Total Observations",
      value: totalObservations || 0,
      icon: FileText,
      href: "/admin/observations",
      color: "text-green-500",
    },
    {
      title: "Children Tracked",
      value: totalChildren || 0,
      icon: Activity,
      href: "/admin/users",
      color: "text-purple-500",
    },
    {
      title: "Blocked IPs",
      value: blockedIPs || 0,
      icon: Ban,
      href: "/admin/blocked-ips",
      color: "text-red-500",
    },
    {
      title: "Audit Logs (24h)",
      value: recentAuditLogs || 0,
      icon: ClipboardList,
      href: "/admin/audit-logs",
      color: "text-amber-500",
    },
  ];

  return (
    <div className="p-4 md:p-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-foreground">Admin Dashboard</h1>
        <p className="text-muted-foreground">Monitor and manage the NeuroPathway platform</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-8">
        {stats.map((stat) => (
          <Link key={stat.title} href={stat.href}>
            <Card className="hover:bg-accent/50 transition-colors cursor-pointer">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <stat.icon className={`h-5 w-5 ${stat.color}`} />
                </div>
                <p className="text-2xl font-bold">{stat.value}</p>
                <p className="text-xs text-muted-foreground">{stat.title}</p>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      {/* Recent Activity */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Recent Users</CardTitle>
            <CardDescription>Newest registered users</CardDescription>
          </CardHeader>
          <CardContent>
            {recentUsers && recentUsers.length > 0 ? (
              <div className="space-y-3">
                {recentUsers.map((user) => (
                  <div
                    key={user.id}
                    className="flex items-center justify-between p-3 rounded-lg bg-secondary/50"
                  >
                    <div>
                      <p className="font-medium text-sm">
                        {user.first_name} {user.last_name || ""}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {user.user_type} • {new Date(user.created_at).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      {user.is_suspended && (
                        <span className="text-xs bg-red-500/10 text-red-500 px-2 py-1 rounded">
                          Suspended
                        </span>
                      )}
                      {user.is_admin && (
                        <span className="text-xs bg-amber-500/10 text-amber-500 px-2 py-1 rounded">
                          Admin
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-sm">No users yet</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Quick Actions</CardTitle>
            <CardDescription>Common admin tasks</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Link href="/admin/users">
              <div className="flex items-center gap-3 p-3 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors cursor-pointer">
                <Users className="h-5 w-5 text-blue-500" />
                <div>
                  <p className="font-medium text-sm">Manage Users</p>
                  <p className="text-xs text-muted-foreground">View, suspend, or modify users</p>
                </div>
              </div>
            </Link>
            <Link href="/admin/observations">
              <div className="flex items-center gap-3 p-3 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors cursor-pointer">
                <FileText className="h-5 w-5 text-green-500" />
                <div>
                  <p className="font-medium text-sm">Moderate Content</p>
                  <p className="text-xs text-muted-foreground">Review and manage observations</p>
                </div>
              </div>
            </Link>
            <Link href="/admin/blocked-ips">
              <div className="flex items-center gap-3 p-3 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors cursor-pointer">
                <Ban className="h-5 w-5 text-red-500" />
                <div>
                  <p className="font-medium text-sm">IP Management</p>
                  <p className="text-xs text-muted-foreground">Block or unblock IP addresses</p>
                </div>
              </div>
            </Link>
            <Link href="/admin/audit-logs">
              <div className="flex items-center gap-3 p-3 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors cursor-pointer">
                <ClipboardList className="h-5 w-5 text-amber-500" />
                <div>
                  <p className="font-medium text-sm">View Audit Logs</p>
                  <p className="text-xs text-muted-foreground">Track all system activity</p>
                </div>
              </div>
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
