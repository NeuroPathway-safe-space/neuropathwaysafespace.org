import { createClient } from "@/lib/supabase/server";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, FileText, TrendingUp, Activity, Calendar, ArrowLeft } from "lucide-react";
import Link from "next/link";

export default async function AdminAnalyticsPage() {
  const supabase = await createClient();

  // Fetch various stats
  const now = new Date();
  const lastWeek = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  const lastMonth = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

  const [
    { count: totalUsers },
    { count: newUsersWeek },
    { count: newUsersMonth },
    { count: totalObservations },
    { count: observationsWeek },
    { count: observationsMonth },
    { count: totalChildren },
    { count: totalReports },
    { data: usersByType },
    { data: observationsByCategory },
  ] = await Promise.all([
    supabase.from("profiles").select("*", { count: "exact", head: true }),
    supabase
      .from("profiles")
      .select("*", { count: "exact", head: true })
      .gte("created_at", lastWeek.toISOString()),
    supabase
      .from("profiles")
      .select("*", { count: "exact", head: true })
      .gte("created_at", lastMonth.toISOString()),
    supabase.from("observations").select("*", { count: "exact", head: true }),
    supabase
      .from("observations")
      .select("*", { count: "exact", head: true })
      .gte("created_at", lastWeek.toISOString()),
    supabase
      .from("observations")
      .select("*", { count: "exact", head: true })
      .gte("created_at", lastMonth.toISOString()),
    supabase.from("children").select("*", { count: "exact", head: true }),
    supabase.from("ehcp_reports").select("*", { count: "exact", head: true }),
    supabase.from("profiles").select("user_type"),
    supabase.from("observations").select("category_name"),
  ]);

  // Calculate user type distribution
  const userTypeCount: Record<string, number> = {};
  usersByType?.forEach((u) => {
    userTypeCount[u.user_type] = (userTypeCount[u.user_type] || 0) + 1;
  });

  // Calculate observation category distribution
  const categoryCount: Record<string, number> = {};
  observationsByCategory?.forEach((o) => {
    categoryCount[o.category_name] = (categoryCount[o.category_name] || 0) + 1;
  });

  const sortedCategories = Object.entries(categoryCount)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8);

  return (
    <div className="p-4 md:p-6">
      <div className="mb-8">
        <Link href="/admin" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4">
          <ArrowLeft className="h-4 w-4" />
          Back to Admin
        </Link>
        <h1 className="text-2xl font-bold text-foreground">Analytics</h1>
        <p className="text-muted-foreground">Platform usage statistics and insights</p>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-500/10">
                <Users className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalUsers || 0}</p>
                <p className="text-xs text-muted-foreground">Total Users</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-green-500/10">
                <FileText className="h-5 w-5 text-green-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalObservations || 0}</p>
                <p className="text-xs text-muted-foreground">Observations</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-purple-500/10">
                <Activity className="h-5 w-5 text-purple-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalChildren || 0}</p>
                <p className="text-xs text-muted-foreground">Children</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-amber-500/10">
                <TrendingUp className="h-5 w-5 text-amber-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalReports || 0}</p>
                <p className="text-xs text-muted-foreground">EHCP Reports</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Growth Stats */}
      <div className="grid md:grid-cols-2 gap-6 mb-8">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Calendar className="h-5 w-5 text-muted-foreground" />
              User Growth
            </CardTitle>
            <CardDescription>New user registrations over time</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/50">
                <span className="text-sm">Last 7 days</span>
                <span className="font-bold text-green-500">+{newUsersWeek || 0}</span>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/50">
                <span className="text-sm">Last 30 days</span>
                <span className="font-bold text-green-500">+{newUsersMonth || 0}</span>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/50">
                <span className="text-sm">All time</span>
                <span className="font-bold">{totalUsers || 0}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <FileText className="h-5 w-5 text-muted-foreground" />
              Observation Activity
            </CardTitle>
            <CardDescription>Observations logged over time</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/50">
                <span className="text-sm">Last 7 days</span>
                <span className="font-bold text-green-500">+{observationsWeek || 0}</span>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/50">
                <span className="text-sm">Last 30 days</span>
                <span className="font-bold text-green-500">+{observationsMonth || 0}</span>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/50">
                <span className="text-sm">All time</span>
                <span className="font-bold">{totalObservations || 0}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Distribution Stats */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">User Types</CardTitle>
            <CardDescription>Distribution of user accounts</CardDescription>
          </CardHeader>
          <CardContent>
            {Object.entries(userTypeCount).length > 0 ? (
              <div className="space-y-3">
                {Object.entries(userTypeCount).map(([type, count]) => (
                  <div key={type} className="flex items-center gap-3">
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm capitalize">{type}</span>
                        <span className="text-sm font-medium">{count}</span>
                      </div>
                      <div className="h-2 bg-secondary rounded-full overflow-hidden">
                        <div
                          className="h-full bg-primary rounded-full"
                          style={{
                            width: `${(count / (totalUsers || 1)) * 100}%`,
                          }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-sm">No data available</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Top Categories</CardTitle>
            <CardDescription>Most observed behaviour categories</CardDescription>
          </CardHeader>
          <CardContent>
            {sortedCategories.length > 0 ? (
              <div className="space-y-3">
                {sortedCategories.map(([category, count]) => (
                  <div key={category} className="flex items-center gap-3">
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm">{category}</span>
                        <span className="text-sm font-medium">{count}</span>
                      </div>
                      <div className="h-2 bg-secondary rounded-full overflow-hidden">
                        <div
                          className="h-full bg-amber-500 rounded-full"
                          style={{
                            width: `${(count / (totalObservations || 1)) * 100}%`,
                          }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-sm">No observations yet</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
