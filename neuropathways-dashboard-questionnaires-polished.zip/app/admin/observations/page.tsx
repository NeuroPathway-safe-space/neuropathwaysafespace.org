"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Search, Loader2, Trash2, Eye, ChevronLeft, ChevronRight, AlertTriangle, ArrowLeft } from "lucide-react";
import Link from "next/link";

type Observation = {
  id: string;
  user_id: string;
  child_id: string;
  category_name: string;
  notes: string | null;
  severity: number | null;
  context: string | null;
  time_of_day: string | null;
  triggers: string | null;
  observed_at: string;
  created_at: string;
  children?: { first_name: string; last_name: string | null };
  profiles?: { first_name: string | null; last_name: string | null };
};

const PAGE_SIZE = 20;

export default function AdminObservationsPage() {
  const [observations, setObservations] = useState<Observation[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterCategory, setFilterCategory] = useState("all");
  const [page, setPage] = useState(0);
  const [totalCount, setTotalCount] = useState(0);
  const [selectedObservation, setSelectedObservation] = useState<Observation | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);

  const supabase = createClient();

  useEffect(() => {
    fetchObservations();
  }, [page, filterCategory]);

  const fetchObservations = async () => {
    setLoading(true);

    let query = supabase
      .from("observations")
      .select(`
        *,
        children (first_name, last_name),
        profiles:user_id (first_name, last_name)
      `, { count: "exact" })
      .order("created_at", { ascending: false })
      .range(page * PAGE_SIZE, (page + 1) * PAGE_SIZE - 1);

    if (filterCategory !== "all") {
      query = query.eq("category_name", filterCategory);
    }

    const { data, count } = await query;
    setObservations(data || []);
    setTotalCount(count || 0);
    setLoading(false);
  };

  const filteredObservations = observations.filter(
    (obs) =>
      obs.category_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      obs.notes?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      obs.children?.first_name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalPages = Math.ceil(totalCount / PAGE_SIZE);

  const handleDelete = async () => {
    if (!selectedObservation) return;

    setActionLoading(true);
    await supabase.from("observations").delete().eq("id", selectedObservation.id);
    setDeleteDialogOpen(false);
    setSelectedObservation(null);
    await fetchObservations();
    setActionLoading(false);
  };

  const getSeverityColor = (severity: number | null) => {
    if (!severity) return "bg-muted";
    if (severity >= 4) return "bg-red-500";
    if (severity >= 3) return "bg-orange-500";
    if (severity >= 2) return "bg-yellow-500";
    return "bg-green-500";
  };

  return (
    <div className="p-4 md:p-6">
      <div className="mb-6">
        <Link href="/admin" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4">
          <ArrowLeft className="h-4 w-4" />
          Back to Admin
        </Link>
        <h1 className="text-2xl font-bold text-foreground">Content Moderation</h1>
        <p className="text-muted-foreground">Review and moderate all observations</p>
      </div>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search observations..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Select value={filterCategory} onValueChange={setFilterCategory}>
          <SelectTrigger className="w-full md:w-48">
            <SelectValue placeholder="Filter by category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            <SelectItem value="Attention / Focus">Attention / Focus</SelectItem>
            <SelectItem value="Emotional Regulation">Emotional Regulation</SelectItem>
            <SelectItem value="Social Interaction">Social Interaction</SelectItem>
            <SelectItem value="Sensory Needs">Sensory Needs</SelectItem>
            <SelectItem value="Learning Engagement">Learning Engagement</SelectItem>
            <SelectItem value="Communication">Communication</SelectItem>
            <SelectItem value="Physical / Motor">Physical / Motor</SelectItem>
            <SelectItem value="Self-Care">Self-Care</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Observations List */}
      <Card>
        <CardHeader>
          <CardTitle>All Observations ({totalCount})</CardTitle>
          <CardDescription>Review content for inappropriate material</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : filteredObservations.length > 0 ? (
            <div className="space-y-3">
              {filteredObservations.map((obs) => (
                <div
                  key={obs.id}
                  className="p-4 rounded-lg border border-border hover:bg-accent/50 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="font-medium">{obs.category_name}</span>
                        <div className={`w-2 h-2 rounded-full ${getSeverityColor(obs.severity)}`} />
                        {obs.severity && (
                          <span className="text-xs text-muted-foreground">
                            Severity: {obs.severity}/5
                          </span>
                        )}
                      </div>
                      {obs.notes && (
                        <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
                          {obs.notes}
                        </p>
                      )}
                      <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
                        <span>
                          Child: {obs.children?.first_name} {obs.children?.last_name || ""}
                        </span>
                        <span>
                          Observer: {obs.profiles?.first_name || "Unknown"} {obs.profiles?.last_name || ""}
                        </span>
                        <span>{new Date(obs.created_at).toLocaleDateString()}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => {
                          setSelectedObservation(obs);
                          setDetailDialogOpen(true);
                        }}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-destructive hover:text-destructive"
                        onClick={() => {
                          setSelectedObservation(obs);
                          setDeleteDialogOpen(true);
                        }}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center text-muted-foreground py-8">No observations found</p>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between mt-6 pt-4 border-t border-border">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage((p) => Math.max(0, p - 1))}
                disabled={page === 0}
              >
                <ChevronLeft className="h-4 w-4 mr-1" />
                Previous
              </Button>
              <span className="text-sm text-muted-foreground">
                Page {page + 1} of {totalPages}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
                disabled={page >= totalPages - 1}
              >
                Next
                <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Detail Dialog */}
      <AlertDialog open={detailDialogOpen} onOpenChange={setDetailDialogOpen}>
        <AlertDialogContent className="max-w-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Observation Details</AlertDialogTitle>
          </AlertDialogHeader>
          {selectedObservation && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-muted-foreground">Category</p>
                  <p className="font-medium">{selectedObservation.category_name}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Severity</p>
                  <p className="font-medium">{selectedObservation.severity || "Not set"}/5</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Time of Day</p>
                  <p className="font-medium">{selectedObservation.time_of_day || "Not set"}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Observed At</p>
                  <p className="font-medium">
                    {new Date(selectedObservation.observed_at).toLocaleString()}
                  </p>
                </div>
              </div>
              {selectedObservation.notes && (
                <div>
                  <p className="text-xs text-muted-foreground">Notes</p>
                  <p className="mt-1 p-3 bg-secondary rounded-lg text-sm">
                    {selectedObservation.notes}
                  </p>
                </div>
              )}
              {selectedObservation.context && (
                <div>
                  <p className="text-xs text-muted-foreground">Context</p>
                  <p className="mt-1 p-3 bg-secondary rounded-lg text-sm">
                    {selectedObservation.context}
                  </p>
                </div>
              )}
              {selectedObservation.triggers && (
                <div>
                  <p className="text-xs text-muted-foreground">Triggers</p>
                  <p className="mt-1 p-3 bg-secondary rounded-lg text-sm">
                    {selectedObservation.triggers}
                  </p>
                </div>
              )}
            </div>
          )}
          <AlertDialogFooter>
            <AlertDialogCancel>Close</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => {
                setDetailDialogOpen(false);
                setDeleteDialogOpen(true);
              }}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-destructive" />
              Delete Observation
            </AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the observation
              from the database.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={handleDelete}
              disabled={actionLoading}
            >
              {actionLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
