"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Trash2, Loader2, Ban, Clock, ArrowLeft } from "lucide-react";
import Link from "next/link";

type BlockedIP = {
  id: string;
  ip_address: string;
  reason: string | null;
  blocked_by: string | null;
  expires_at: string | null;
  created_at: string;
};

export default function BlockedIPsPage() {
  const [blockedIPs, setBlockedIPs] = useState<BlockedIP[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [newIP, setNewIP] = useState("");
  const [newReason, setNewReason] = useState("");
  const [expiresIn, setExpiresIn] = useState("permanent");
  const [actionLoading, setActionLoading] = useState(false);

  const supabase = createClient();

  useEffect(() => {
    fetchBlockedIPs();
  }, []);

  const fetchBlockedIPs = async () => {
    setLoading(true);
    const { data } = await supabase
      .from("blocked_ips")
      .select("*")
      .order("created_at", { ascending: false });
    setBlockedIPs(data || []);
    setLoading(false);
  };

  const handleBlockIP = async () => {
    if (!newIP.trim()) return;

    setActionLoading(true);

    const { data: { user } } = await supabase.auth.getUser();

    let expiresAt: string | null = null;
    if (expiresIn !== "permanent") {
      const hours = parseInt(expiresIn);
      expiresAt = new Date(Date.now() + hours * 60 * 60 * 1000).toISOString();
    }

    await supabase.from("blocked_ips").insert({
      ip_address: newIP.trim(),
      reason: newReason.trim() || null,
      blocked_by: user?.id || null,
      expires_at: expiresAt,
    });

    setNewIP("");
    setNewReason("");
    setExpiresIn("permanent");
    setDialogOpen(false);
    await fetchBlockedIPs();
    setActionLoading(false);
  };

  const handleUnblockIP = async (id: string) => {
    setActionLoading(true);
    await supabase.from("blocked_ips").delete().eq("id", id);
    await fetchBlockedIPs();
    setActionLoading(false);
  };

  const isExpired = (expiresAt: string | null) => {
    if (!expiresAt) return false;
    return new Date(expiresAt) < new Date();
  };

  return (
    <div className="p-4 md:p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <Link href="/admin" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4">
            <ArrowLeft className="h-4 w-4" />
            Back to Admin
          </Link>
          <h1 className="text-2xl font-bold text-foreground">IP Blocking</h1>
          <p className="text-muted-foreground">Manage blocked IP addresses</p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Block IP
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Block IP Address</DialogTitle>
              <DialogDescription>
                This will prevent the IP from accessing the platform.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="ip">IP Address</Label>
                <Input
                  id="ip"
                  placeholder="e.g. 192.168.1.1"
                  value={newIP}
                  onChange={(e) => setNewIP(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="reason">Reason (optional)</Label>
                <Textarea
                  id="reason"
                  placeholder="Enter reason for blocking..."
                  value={newReason}
                  onChange={(e) => setNewReason(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="expires">Block Duration</Label>
                <Select value={expiresIn} onValueChange={setExpiresIn}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 hour</SelectItem>
                    <SelectItem value="24">24 hours</SelectItem>
                    <SelectItem value="168">7 days</SelectItem>
                    <SelectItem value="720">30 days</SelectItem>
                    <SelectItem value="permanent">Permanent</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleBlockIP} disabled={actionLoading || !newIP.trim()}>
                {actionLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Block IP
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Blocked IPs ({blockedIPs.length})</CardTitle>
          <CardDescription>IP addresses currently blocked from accessing the platform</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : blockedIPs.length > 0 ? (
            <div className="space-y-3">
              {blockedIPs.map((ip) => (
                <div
                  key={ip.id}
                  className={`flex items-center justify-between p-4 rounded-lg border ${
                    isExpired(ip.expires_at)
                      ? "border-yellow-500/50 bg-yellow-500/5"
                      : "border-border"
                  }`}
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <Ban className="h-4 w-4 text-red-500" />
                      <span className="font-mono font-medium">{ip.ip_address}</span>
                      {isExpired(ip.expires_at) && (
                        <span className="text-xs bg-yellow-500/10 text-yellow-500 px-2 py-0.5 rounded">
                          Expired
                        </span>
                      )}
                    </div>
                    {ip.reason && (
                      <p className="text-sm text-muted-foreground mt-1">{ip.reason}</p>
                    )}
                    <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                      <span>Blocked {new Date(ip.created_at).toLocaleDateString()}</span>
                      {ip.expires_at && (
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          Expires {new Date(ip.expires_at).toLocaleString()}
                        </span>
                      )}
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-destructive hover:text-destructive"
                    onClick={() => handleUnblockIP(ip.id)}
                    disabled={actionLoading}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <Ban className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
              <p className="text-muted-foreground">No blocked IPs</p>
              <p className="text-sm text-muted-foreground">
                Click &quot;Block IP&quot; to add an IP address to the blocklist
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
