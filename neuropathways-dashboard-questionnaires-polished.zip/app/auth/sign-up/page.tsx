'use client'

import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Checkbox } from '@/components/ui/checkbox'
import Link from 'next/link'
import Image from 'next/image'
import { useRouter } from 'next/navigation'
import { useState } from 'react'
import { School, User, AlertTriangle, Shield, Ticket } from 'lucide-react'

export default function Page() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [repeatPassword, setRepeatPassword] = useState('')
  const [firstName, setFirstName] = useState('')
  const [lastName, setLastName] = useState('')
  const [userType, setUserType] = useState<'school' | 'parent'>('parent')
  const [organisationName, setOrganisationName] = useState('')
  const [inviteCode, setInviteCode] = useState('')
  const [inviteCodeValid, setInviteCodeValid] = useState<boolean | null>(null)
  const [inviteCodeRole, setInviteCodeRole] = useState<string | null>(null)
  const [checkingCode, setCheckingCode] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [acceptedTerms, setAcceptedTerms] = useState(false)
  const [acceptedSafeguarding, setAcceptedSafeguarding] = useState(false)
  const router = useRouter()

  // Validate invite code
  const validateInviteCode = async (code: string) => {
    if (!code || code.length < 4) {
      setInviteCodeValid(null)
      setInviteCodeRole(null)
      return
    }
    
    setCheckingCode(true)
    const supabase = createClient()
    
    try {
      const { data, error } = await supabase
        .from('invite_codes')
        .select('id, code, role, max_uses, uses_count, expires_at, is_active')
        .eq('code', code.toUpperCase())
        .eq('is_active', true)
        .single()
      
      if (error || !data) {
        setInviteCodeValid(false)
        setInviteCodeRole(null)
      } else if (data.max_uses && data.uses_count >= data.max_uses) {
        setInviteCodeValid(false)
        setInviteCodeRole(null)
      } else if (data.expires_at && new Date(data.expires_at) < new Date()) {
        setInviteCodeValid(false)
        setInviteCodeRole(null)
      } else {
        setInviteCodeValid(true)
        setInviteCodeRole(data.role)
      }
    } catch {
      setInviteCodeValid(false)
      setInviteCodeRole(null)
    } finally {
      setCheckingCode(false)
    }
  }

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault()
    const supabase = createClient()
    setIsLoading(true)
    setError(null)

    if (password !== repeatPassword) {
      setError('Passwords do not match')
      setIsLoading(false)
      return
    }

    if (password.length < 6) {
      setError('Password must be at least 6 characters')
      setIsLoading(false)
      return
    }

    if (!acceptedTerms || !acceptedSafeguarding) {
      setError('Please accept the terms and safeguarding policy')
      setIsLoading(false)
      return
    }

    if (!inviteCodeValid) {
      setError('Please enter a valid invite code')
      setIsLoading(false)
      return
    }

    try {
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo:
            process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL ??
            `${window.location.origin}/auth/callback`,
          data: {
            user_type: userType,
            first_name: firstName,
            last_name: lastName,
            organisation_name: userType === 'school' ? organisationName : null,
            invite_code: inviteCode.toUpperCase(),
            assigned_role: inviteCodeRole,
          },
        },
      })
      if (error) throw error
      router.push('/auth/sign-up-success')
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : 'An error occurred')
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-svh w-full items-center justify-center p-6 md:p-10 bg-background">
      <div className="w-full max-w-md">
        <div className="flex flex-col gap-6">
          {/* Logo */}
          <div className="flex justify-center">
            <Link href="/">
              <Image
                src="/logo.jpeg"
                alt="NeuroPathway Safe Space"
                width={80}
                height={80}
                className="rounded-2xl"
              />
            </Link>
          </div>

          <Card className="border-border bg-card">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl text-foreground">Create Account</CardTitle>
              <CardDescription>
                Start building EHCP-ready evidence today
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSignUp}>
                <div className="flex flex-col gap-4">
                  {/* Invite Code */}
                  <div className="grid gap-2">
                    <Label htmlFor="inviteCode" className="flex items-center gap-2">
                      <Ticket className="h-4 w-4" />
                      Invite Code
                    </Label>
                    <div className="relative">
                      <Input
                        id="inviteCode"
                        type="text"
                        placeholder="Enter your invite code"
                        required
                        value={inviteCode}
                        onChange={(e) => {
                          const code = e.target.value.toUpperCase()
                          setInviteCode(code)
                          validateInviteCode(code)
                        }}
                        className={`bg-background uppercase ${
                          inviteCodeValid === true ? 'border-green-500' : 
                          inviteCodeValid === false ? 'border-red-500' : ''
                        }`}
                      />
                      {checkingCode && (
                        <div className="absolute right-3 top-1/2 -translate-y-1/2">
                          <div className="h-4 w-4 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                        </div>
                      )}
                    </div>
                    {inviteCodeValid === true && inviteCodeRole && (
                      <p className="text-xs text-green-500">
                        Valid code - {inviteCodeRole === 'admin' ? 'Administrator' : inviteCodeRole.charAt(0).toUpperCase() + inviteCodeRole.slice(1)} access
                      </p>
                    )}
                    {inviteCodeValid === false && (
                      <p className="text-xs text-red-500">Invalid or expired invite code</p>
                    )}
                    <p className="text-xs text-muted-foreground">
                      Contact your school, local authority, or NeuroPathway team for an invite code.
                    </p>
                  </div>

                  {/* User Type Selection */}
                  <div className="grid gap-2">
                    <Label>I am a...</Label>
                    <div className="grid grid-cols-2 gap-3">
                      <button
                        type="button"
                        onClick={() => setUserType('parent')}
                        className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all ${
                          userType === 'parent'
                            ? 'border-primary bg-primary/10'
                            : 'border-border hover:border-primary/50'
                        }`}
                      >
                        <User className={`h-6 w-6 ${userType === 'parent' ? 'text-primary' : 'text-muted-foreground'}`} />
                        <span className={`text-sm font-medium ${userType === 'parent' ? 'text-primary' : 'text-foreground'}`}>
                          Parent / Carer
                        </span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setUserType('school')}
                        className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all ${
                          userType === 'school'
                            ? 'border-primary bg-primary/10'
                            : 'border-border hover:border-primary/50'
                        }`}
                      >
                        <School className={`h-6 w-6 ${userType === 'school' ? 'text-primary' : 'text-muted-foreground'}`} />
                        <span className={`text-sm font-medium ${userType === 'school' ? 'text-primary' : 'text-foreground'}`}>
                          School / SENCO
                        </span>
                      </button>
                    </div>
                  </div>

                  {/* Name Fields */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="grid gap-2">
                      <Label htmlFor="firstName">First Name</Label>
                      <Input
                        id="firstName"
                        type="text"
                        required
                        value={firstName}
                        onChange={(e) => setFirstName(e.target.value)}
                        className="bg-background"
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input
                        id="lastName"
                        type="text"
                        required
                        value={lastName}
                        onChange={(e) => setLastName(e.target.value)}
                        className="bg-background"
                      />
                    </div>
                  </div>

                  {/* Organisation Name (for schools) */}
                  {userType === 'school' && (
                    <div className="grid gap-2">
                      <Label htmlFor="organisationName">School / Organisation Name</Label>
                      <Input
                        id="organisationName"
                        type="text"
                        required
                        value={organisationName}
                        onChange={(e) => setOrganisationName(e.target.value)}
                        className="bg-background"
                      />
                    </div>
                  )}

                  <div className="grid gap-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="you@example.com"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="bg-background"
                    />
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="password">Password</Label>
                    <Input
                      id="password"
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="bg-background"
                    />
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="repeat-password">Confirm Password</Label>
                    <Input
                      id="repeat-password"
                      type="password"
                      required
                      value={repeatPassword}
                      onChange={(e) => setRepeatPassword(e.target.value)}
                      className="bg-background"
                    />
                  </div>

                  {error && <p className="text-sm text-red-500">{error}</p>}

                  {/* Mental Health Disclaimer */}
                  <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg">
                    <div className="flex items-start gap-2 mb-2">
                      <AlertTriangle className="h-4 w-4 text-amber-500 shrink-0 mt-0.5" />
                      <p className="text-xs text-amber-400 font-medium">Mental Health Notice</p>
                    </div>
                    <p className="text-xs text-muted-foreground mb-2">
                      This is an observation tracking tool, not a mental health service. In a crisis, call Samaritans: 116 123 (24/7, free).
                    </p>
                    <div className="flex items-start gap-2">
                      <Checkbox
                        id="acceptTerms"
                        checked={acceptedTerms}
                        onCheckedChange={(checked) => setAcceptedTerms(checked as boolean)}
                        className="mt-0.5"
                      />
                      <label htmlFor="acceptTerms" className="text-xs text-muted-foreground cursor-pointer">
                        I understand this tool is for observation tracking only and will seek professional help for mental health concerns.
                      </label>
                    </div>
                  </div>

                  {/* Safeguarding Policy */}
                  <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-lg">
                    <div className="flex items-start gap-2 mb-2">
                      <Shield className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                      <p className="text-xs text-emerald-400 font-medium">Safeguarding & GDPR</p>
                    </div>
                    <p className="text-xs text-muted-foreground mb-2">
                      Data is processed under UK GDPR. Safeguarding concerns must be reported to your DSL or local authority.
                    </p>
                    <div className="flex items-start gap-2">
                      <Checkbox
                        id="acceptSafeguarding"
                        checked={acceptedSafeguarding}
                        onCheckedChange={(checked) => setAcceptedSafeguarding(checked as boolean)}
                        className="mt-0.5"
                      />
                      <label htmlFor="acceptSafeguarding" className="text-xs text-muted-foreground cursor-pointer">
                        I accept the safeguarding policy and GDPR terms. I will report concerns through proper channels.
                      </label>
                    </div>
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full bg-primary text-primary-foreground hover:bg-primary/90" 
                    disabled={isLoading || !acceptedTerms || !acceptedSafeguarding || !inviteCodeValid}
                  >
                    {isLoading ? 'Creating account...' : 'Create Account'}
                  </Button>
                </div>
                <div className="mt-4 text-center text-sm text-muted-foreground">
                  Already have an account?{' '}
                  <Link
                    href="/auth/login"
                    className="text-primary underline underline-offset-4"
                  >
                    Sign in
                  </Link>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
