import type { ReactNode } from "react";

// Auth pages create a Supabase client during render and must run at request
// time, never be statically prerendered at build. This cascades to all
// /auth/* routes.
export const dynamic = "force-dynamic";

export default function AuthLayout({ children }: { children: ReactNode }) {
  return children;
}
