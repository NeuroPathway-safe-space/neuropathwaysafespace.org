"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import { createClient } from "@/lib/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Shield, Loader2, CheckCircle, XCircle, Eye, EyeOff } from "lucide-react";

export default function AdminRegisterPage() {
  const router = useRouter();
  const [inviteCode, setInviteCode] = useState("");
  const [codeVerified, setCodeVerified] = useState(false);
  const [codeError, setCodeError] = useState("");
  const [verifyingCode, setVerifyingCode] = useState(false);

  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const supabase = createClient();

  const verifyInviteCode = async () => {
    if (!inviteCode.trim()) {
      setCodeError("Please enter an invite code");
      return;
    }

    setVerifyingCode(true);
    setCodeError("");

    const { data: code } = await supabase
      .from("admin_invite_codes")
      .select("*")
      .eq("code", inviteCode.trim().toUpperCase())
      .single();

    if (!code) {
      setCodeError("Invalid invite code");
      setVerifyingCode(false);
      return;
    }

    if (!code.is_active) {
      setCodeError("This invite code has been deactivated");
      setVerifyingCode(false);
      return;
    }

    if (code.expires_at && new Date(code.expires_at) < new Date()) {
      setCodeError("This invite code has expired");
      setVerifyingCode(false);
      return;
    }

    if (code.current_uses >= code.max_uses) {
      setCodeError("This invite code has reached its maximum uses");
      setVerifyingCode(false);
      return;
    }

    setCodeVerified(true);
    setVerifyingCode(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (password !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }

    if (password.length < 8) {
      setError("Password must be at least 8 characters");
      return;
    }

    setLoading(true);

    // Sign up the user
    const { data: authData, error: signUpError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo:
          process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL ??
          `${window.location.origin}/auth/callback`,
        data: {
          first_name: firstName,
          last_name: lastName,
          user_type: "admin",
          assigned_role: "admin",
        },
      },
    });

    if (signUpError) {
      setError(signUpError.message);
      setLoading(false);
      return;
    }

    if (authData.user) {
      // The signup trigger auto-creates the profile from metadata (admin role).
      // Update it to guarantee the admin flag is set.
      const { error: profileError } = await supabase
        .from("profiles")
        .update({
          user_type: "admin",
          role: "admin",
          first_name: firstName,
          last_name: lastName,
          is_admin: true,
        })
        .eq("id", authData.user.id);

      if (profileError) {
        console.error("Profile error:", profileError);
      }

      // Update the invite code usage
      const { data: code } = await supabase
        .from("admin_invite_codes")
        .select("current_uses")
        .eq("code", inviteCode.trim().toUpperCase())
        .single();

      if (code) {
        await supabase
          .from("admin_invite_codes")
          .update({
            current_uses: code.current_uses + 1,
            used_by: authData.user.id,
            used_at: new Date().toISOString(),
          })
          .eq("code", inviteCode.trim().toUpperCase());
      }

      // Log the admin registration
      await supabase.from("audit_logs").insert({
        user_id: authData.user.id,
        action: "admin_register",
        entity_type: "user",
        entity_id: authData.user.id,
        new_data: { email, first_name: firstName, last_name: lastName, invite_code: inviteCode },
      });

      router.push("/admin");
    }

    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background">
      <div className="w-full max-w-md">
        <Link
          href="/auth/login"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Login
        </Link>

        <Card className="border-amber-500/20">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <div className="relative w-16 h-16 rounded-2xl overflow-hidden bg-[#0a1628] border border-border">
                <Image
                  src="/logo.jpeg"
                  alt="NeuroPathway"
                  fill
                  className="object-cover"
                />
              </div>
            </div>
            <div className="flex items-center justify-center gap-2 mb-2">
              <Shield className="h-5 w-5 text-amber-500" />
              <CardTitle className="text-xl">Admin Registration</CardTitle>
            </div>
            <CardDescription>
              Register as an administrator with a valid invite code
            </CardDescription>
          </CardHeader>

          <CardContent>
            {!codeVerified ? (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="invite-code">Admin Invite Code</Label>
                  <Input
                    id="invite-code"
                    placeholder="NEURO-ADMIN-XXXXXXXX"
                    value={inviteCode}
                    onChange={(e) => {
                      setInviteCode(e.target.value.toUpperCase());
                      setCodeError("");
                    }}
                    className="font-mono text-center tracking-wide"
                  />
                  {codeError && (
                    <p className="text-sm text-destructive flex items-center gap-2">
                      <XCircle className="h-4 w-4" />
                      {codeError}
                    </p>
                  )}
                </div>
                <Button
                  onClick={verifyInviteCode}
                  className="w-full"
                  disabled={verifyingCode || !inviteCode.trim()}
                >
                  {verifyingCode && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Verify Code
                </Button>
                <p className="text-xs text-center text-muted-foreground">
                  Contact an existing administrator to obtain an invite code
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="p-3 rounded-lg bg-green-500/10 border border-green-500/20 flex items-center gap-2 text-sm text-green-500">
                  <CheckCircle className="h-4 w-4" />
                  Invite code verified
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">First Name</Label>
                    <Input
                      id="firstName"
                      placeholder="John"
                      value={firstName}
                      onChange={(e) => setFirstName(e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input
                      id="lastName"
                      placeholder="Doe"
                      value={lastName}
                      onChange={(e) => setLastName(e.target.value)}
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="admin@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      placeholder="At least 8 characters"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      className="pr-10"
                    />
                    <button
                      type="button"
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Confirm Password</Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    placeholder="Confirm your password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                  />
                </div>

                {error && (
                  <p className="text-sm text-destructive flex items-center gap-2">
                    <XCircle className="h-4 w-4" />
                    {error}
                  </p>
                )}

                <Button type="submit" className="w-full bg-amber-500 hover:bg-amber-600" disabled={loading}>
                  {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Create Admin Account
                </Button>
              </form>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
