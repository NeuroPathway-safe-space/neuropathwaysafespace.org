"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { createClient } from "@/lib/supabase/client";
import Link from "next/link";
import Image from "next/image";
import { 
  Heart, 
  Shield, 
  Phone, 
  AlertTriangle, 
  Smile, 
  Meh, 
  Frown,
  Star,
  BookOpen,
  Wind,
  Users,
  ArrowRight,
  Sparkles,
  ArrowLeft,
  Lock,
  Sun,
  Cloud,
  CloudRain,
  Send
} from "lucide-react";

type Screen = "welcome" | "consent" | "login" | "setpin" | "home" | "mood" | "journal" | "breathing" | "resources";

export default function YouthSafeSpace() {
  const [screen, setScreen] = useState<Screen>("welcome");
  const [profileId, setProfileId] = useState<string | null>(null);
  const [displayName, setDisplayName] = useState("");
  const [ageRange, setAgeRange] = useState("");
  const [consentGiven, setConsentGiven] = useState(false);
  const [parentalConsent, setParentalConsent] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [linkCode, setLinkCode] = useState<string | null>(null);
  const [savedName, setSavedName] = useState("");
  const [hasPin, setHasPin] = useState(false);

  // Login form (returning child on a new device)
  const [loginCode, setLoginCode] = useState("");
  const [loginPin, setLoginPin] = useState("");
  const [authError, setAuthError] = useState<string | null>(null);

  // Set / change PIN form
  const [newPin, setNewPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");

  const supabase = createClient();

  // Check for existing session in localStorage
  useEffect(() => {
    const savedProfileId = localStorage.getItem("youth_profile_id");
    const savedDisplayName = localStorage.getItem("youth_display_name");
    const savedLinkCode = localStorage.getItem("youth_link_code");
    const savedHasPin = localStorage.getItem("youth_has_pin") === "true";
    if (savedProfileId) {
      setProfileId(savedProfileId);
      setSavedName(savedDisplayName || "Friend");
      setLinkCode(savedLinkCode);
      setHasPin(savedHasPin);
      setScreen("home");
    }
  }, []);

  const generateLinkCode = () => {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
  };

  // Returning child logs in on any device with their link code + PIN.
  const handleLogin = async () => {
    setAuthError(null);
    if (!loginCode || !loginPin) {
      setAuthError("Enter your code and PIN.");
      return;
    }
    setIsLoading(true);
    try {
      const res = await fetch("/api/youth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ linkCode: loginCode, pin: loginPin }),
      });
      const data = await res.json();
      if (!res.ok) {
        setAuthError(data.error || "Login failed.");
        return;
      }
      localStorage.setItem("youth_profile_id", data.profile.id);
      localStorage.setItem("youth_display_name", data.profile.displayName);
      localStorage.setItem("youth_link_code", data.profile.linkCode);
      localStorage.setItem("youth_has_pin", "true");
      setProfileId(data.profile.id);
      setSavedName(data.profile.displayName);
      setLinkCode(data.profile.linkCode);
      setHasPin(true);
      setLoginCode("");
      setLoginPin("");
      setScreen("home");
    } finally {
      setIsLoading(false);
    }
  };

  // Child sets or changes the PIN on their own profile.
  const handleSetPin = async () => {
    setAuthError(null);
    if (newPin !== confirmPin) {
      setAuthError("Those PINs don't match.");
      return;
    }
    if (!/^\d{4,8}$/.test(newPin)) {
      setAuthError("Your PIN must be 4 to 8 numbers.");
      return;
    }
    if (!profileId || !linkCode) {
      setAuthError("We couldn't find your profile on this device.");
      return;
    }
    setIsLoading(true);
    try {
      const res = await fetch("/api/youth/set-pin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ profileId, linkCode, pin: newPin }),
      });
      const data = await res.json();
      if (!res.ok) {
        setAuthError(data.error || "Could not save PIN.");
        return;
      }
      localStorage.setItem("youth_has_pin", "true");
      setHasPin(true);
      setNewPin("");
      setConfirmPin("");
      setScreen("home");
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreateProfile = async () => {
    if (!displayName || !ageRange || !consentGiven) return;
    
    if ((ageRange === "under-11" || ageRange === "11-14") && !parentalConsent) {
      return;
    }

    setIsLoading(true);
    const code = generateLinkCode();

    const { data, error } = await supabase
      .from("youth_profiles")
      .insert({
        display_name: displayName,
        age_range: ageRange,
        link_code: code,
        consent_given: true,
        consent_timestamp: new Date().toISOString(),
        parental_consent: parentalConsent,
        parental_consent_timestamp: parentalConsent ? new Date().toISOString() : null,
      })
      .select()
      .single();

    if (!error && data) {
      localStorage.setItem("youth_profile_id", data.id);
      localStorage.setItem("youth_display_name", displayName);
      localStorage.setItem("youth_link_code", code);
      setProfileId(data.id);
      setSavedName(displayName);
      setLinkCode(code);
      // Offer to set a PIN so they can log back in on any device.
      setScreen("setpin");
    }
    setIsLoading(false);
  };

  // Crisis Banner Component
  const CrisisBanner = () => (
    <div className="bg-red-500/10 border-b border-red-500/30 px-4 py-2">
      <div className="max-w-lg mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-2">
          <AlertTriangle className="h-3 w-3 text-red-400" />
          <span className="text-red-300 font-medium">Need help now?</span>
        </div>
        <div className="flex gap-3">
          <a href="tel:08001111" className="text-muted-foreground hover:text-red-400 transition-colors">
            Childline: 0800 1111
          </a>
          <a href="tel:116123" className="text-muted-foreground hover:text-red-400 transition-colors">
            Samaritans: 116 123
          </a>
          <a href="tel:999" className="text-red-400 font-medium">
            999
          </a>
        </div>
      </div>
    </div>
  );

  // Welcome Screen
  if (screen === "welcome") {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#0a1628] via-[#0f2847] to-[#0a1628]">
        <CrisisBanner />
        <div className="px-4 pb-8 max-w-lg mx-auto">
          <div className="text-center py-12">
            <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center">
              <Heart className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-3xl font-bold mb-3 text-foreground">Safe Space</h1>
            <p className="text-muted-foreground mb-8">
              A private place to check in with yourself, talk to an AI friend, and find calm when things feel tough.
            </p>
          </div>

          <div className="space-y-4 mb-8">
            <Card className="border-emerald-500/30 bg-emerald-500/5">
              <CardContent className="p-4 flex items-start gap-3">
                <Smile className="w-6 h-6 text-emerald-500 shrink-0 mt-0.5" />
                <div>
                  <p className="font-medium text-sm">Track how you feel</p>
                  <p className="text-xs text-muted-foreground">Quick daily check-ins to spot patterns</p>
                </div>
              </CardContent>
            </Card>
            <Card className="border-blue-500/30 bg-blue-500/5">
              <CardContent className="p-4 flex items-start gap-3">
                <BookOpen className="w-6 h-6 text-blue-500 shrink-0 mt-0.5" />
                <div>
                  <p className="font-medium text-sm">AI Journal</p>
                  <p className="text-xs text-muted-foreground">Write about anything - get supportive responses</p>
                </div>
              </CardContent>
            </Card>
            <Card className="border-purple-500/30 bg-purple-500/5">
              <CardContent className="p-4 flex items-start gap-3">
                <Wind className="w-6 h-6 text-purple-500 shrink-0 mt-0.5" />
                <div>
                  <p className="font-medium text-sm">Calm down tools</p>
                  <p className="text-xs text-muted-foreground">Breathing exercises and grounding techniques</p>
                </div>
              </CardContent>
            </Card>
          </div>

          <Button 
            onClick={() => setScreen("consent")} 
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white h-12 text-base"
          >
            Get Started
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>

          <p className="text-xs text-center text-muted-foreground mt-4 flex items-center justify-center gap-1">
            <Lock className="w-3 h-3" />
            No email needed. Your data stays private.
          </p>

          <Button
            variant="ghost"
            onClick={() => { setAuthError(null); setScreen("login"); }}
            className="w-full mt-3 text-emerald-400 hover:text-emerald-300"
          >
            I already have a space - log in
          </Button>

          <div className="mt-8 pt-6 border-t border-border">
            <p className="text-xs text-muted-foreground text-center mb-3">
              Is your parent or school tracking your wellbeing?
            </p>
            <Link href="/auth/login">
              <Button variant="outline" className="w-full">
                <Users className="w-4 h-4 mr-2" />
                Connect to EHCP Platform
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  // Consent Screen
  if (screen === "consent") {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#0a1628] via-[#0f2847] to-[#0a1628]">
        <CrisisBanner />
        <div className="px-4 pb-8 max-w-lg mx-auto">
          <Button variant="ghost" onClick={() => setScreen("welcome")} className="mb-4 mt-4">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>

          <Card className="bg-card/50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-emerald-500" />
                Your Privacy Matters
              </CardTitle>
              <CardDescription>
                Please read this before continuing
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3 text-sm">
                <div className="p-3 bg-muted/50 rounded-lg">
                  <p className="font-medium mb-1">What we collect:</p>
                  <ul className="text-muted-foreground text-xs space-y-1">
                    <li>• Your mood check-ins and journal entries</li>
                    <li>• A nickname (not your real name)</li>
                    <li>• Your age range</li>
                  </ul>
                </div>

                <div className="p-3 bg-muted/50 rounded-lg">
                  <p className="font-medium mb-1">What we do NOT collect:</p>
                  <ul className="text-muted-foreground text-xs space-y-1">
                    <li>• Your email or phone number</li>
                    <li>• Your real name or location</li>
                    <li>• Any way to identify you</li>
                  </ul>
                </div>

                <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg">
                  <div className="flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium text-amber-400 text-xs">Important</p>
                      <p className="text-xs text-muted-foreground">
                        If you share something that suggests you or someone else is in danger, 
                        we may need to let a trusted adult know to keep everyone safe.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4 pt-4">
                <div>
                  <Label className="text-sm font-medium mb-2 block">Choose your nickname</Label>
                  <Input 
                    placeholder="e.g. StarGazer, BlueBird, etc."
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    maxLength={20}
                    className="bg-background/50"
                  />
                </div>

                <div>
                  <Label className="text-sm font-medium mb-2 block">How old are you?</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { value: "under-11", label: "Under 11" },
                      { value: "11-14", label: "11-14" },
                      { value: "15-18", label: "15-18" },
                      { value: "18+", label: "18+" }
                    ].map((option) => (
                      <Button
                        key={option.value}
                        type="button"
                        variant={ageRange === option.value ? "default" : "outline"}
                        className={ageRange === option.value ? "bg-emerald-600 hover:bg-emerald-700" : ""}
                        onClick={() => setAgeRange(option.value)}
                      >
                        {option.label}
                      </Button>
                    ))}
                  </div>
                </div>

                {(ageRange === "under-11" || ageRange === "11-14") && (
                  <div className="p-3 bg-blue-500/10 border border-blue-500/30 rounded-lg">
                    <div className="flex items-start gap-2">
                      <Checkbox
                        id="parentalConsent"
                        checked={parentalConsent}
                        onCheckedChange={(checked) => setParentalConsent(checked as boolean)}
                      />
                      <label htmlFor="parentalConsent" className="text-xs text-muted-foreground cursor-pointer">
                        A parent or guardian has said it&apos;s okay for me to use this app
                      </label>
                    </div>
                  </div>
                )}

                <div className="flex items-start gap-2">
                  <Checkbox
                    id="consent"
                    checked={consentGiven}
                    onCheckedChange={(checked) => setConsentGiven(checked as boolean)}
                  />
                  <label htmlFor="consent" className="text-xs text-muted-foreground cursor-pointer">
                    I understand how my data will be used and I agree to the privacy terms
                  </label>
                </div>
              </div>

              <Button 
                onClick={handleCreateProfile}
                disabled={!displayName || !ageRange || !consentGiven || isLoading || 
                  ((ageRange === "under-11" || ageRange === "11-14") && !parentalConsent)}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white h-12"
              >
                {isLoading ? "Creating your space..." : "Enter Safe Space"}
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Login Screen (returning child)
  if (screen === "login") {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#0a1628] via-[#0f2847] to-[#0a1628]">
        <CrisisBanner />
        <div className="px-4 pb-8 max-w-lg mx-auto">
          <Button variant="ghost" onClick={() => { setAuthError(null); setScreen("welcome"); }} className="mb-4 mt-4">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>

          <Card className="bg-card/50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="w-5 h-5 text-emerald-500" />
                Welcome back
              </CardTitle>
              <CardDescription>
                Enter your code and PIN to get back into your space.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="loginCode" className="text-sm font-medium mb-2 block">Your code</Label>
                <Input
                  id="loginCode"
                  placeholder="e.g. AB12CD"
                  value={loginCode}
                  onChange={(e) => setLoginCode(e.target.value.toUpperCase())}
                  autoCapitalize="characters"
                  maxLength={6}
                  className="bg-background/50 tracking-widest text-base"
                />
              </div>
              <div>
                <Label htmlFor="loginPin" className="text-sm font-medium mb-2 block">Your PIN</Label>
                <Input
                  id="loginPin"
                  type="password"
                  inputMode="numeric"
                  placeholder="4-8 numbers"
                  value={loginPin}
                  onChange={(e) => setLoginPin(e.target.value.replace(/\D/g, ""))}
                  maxLength={8}
                  className="bg-background/50 text-base"
                />
              </div>

              {authError && (
                <p className="text-sm text-red-400" role="alert">{authError}</p>
              )}

              <Button
                onClick={handleLogin}
                disabled={isLoading}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white h-12"
              >
                {isLoading ? "Checking..." : "Log in"}
              </Button>
              <p className="text-xs text-center text-muted-foreground">
                Forgot your code or PIN? Open the app on the device where you created your space.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Set / change PIN Screen
  if (screen === "setpin") {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#0a1628] via-[#0f2847] to-[#0a1628]">
        <CrisisBanner />
        <div className="px-4 pb-8 max-w-lg mx-auto">
          <Card className="bg-card/50 mt-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="w-5 h-5 text-emerald-500" />
                Create a PIN
              </CardTitle>
              <CardDescription>
                A PIN lets you log back in if you use a different phone or computer. Your code is{" "}
                <span className="font-mono font-semibold text-emerald-400">{linkCode}</span> - keep it safe.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="newPin" className="text-sm font-medium mb-2 block">Choose a PIN</Label>
                <Input
                  id="newPin"
                  type="password"
                  inputMode="numeric"
                  placeholder="4-8 numbers"
                  value={newPin}
                  onChange={(e) => setNewPin(e.target.value.replace(/\D/g, ""))}
                  maxLength={8}
                  className="bg-background/50 text-base"
                />
              </div>
              <div>
                <Label htmlFor="confirmPin" className="text-sm font-medium mb-2 block">Type it again</Label>
                <Input
                  id="confirmPin"
                  type="password"
                  inputMode="numeric"
                  placeholder="4-8 numbers"
                  value={confirmPin}
                  onChange={(e) => setConfirmPin(e.target.value.replace(/\D/g, ""))}
                  maxLength={8}
                  className="bg-background/50 text-base"
                />
              </div>

              {authError && (
                <p className="text-sm text-red-400" role="alert">{authError}</p>
              )}

              <Button
                onClick={handleSetPin}
                disabled={isLoading}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white h-12"
              >
                {isLoading ? "Saving..." : "Save PIN & continue"}
              </Button>
              <Button
                variant="ghost"
                onClick={() => { setAuthError(null); setScreen("home"); }}
                className="w-full text-muted-foreground"
              >
                Skip for now
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Home Screen
  if (screen === "home") {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#0a1628] via-[#0f2847] to-[#0a1628]">
        <CrisisBanner />
        <div className="px-4 pb-24 max-w-lg mx-auto">
          <div className="text-center py-6">
            <p className="text-muted-foreground text-sm">Welcome back</p>
            <h1 className="text-2xl font-bold text-foreground">{savedName || "Friend"}</h1>
          </div>

          {linkCode && (
            <Card className="mb-6 border-emerald-500/30 bg-emerald-500/5">
              <CardContent className="p-4">
                <p className="text-xs text-muted-foreground mb-2">Your link code (share with parent/school to connect):</p>
                <p className="text-2xl font-mono font-bold text-emerald-500 tracking-widest">{linkCode}</p>
              </CardContent>
            </Card>
          )}

          {!hasPin && (
            <Card className="mb-6 border-amber-500/30 bg-amber-500/5">
              <CardContent className="p-4 flex items-center justify-between gap-3">
                <div className="flex items-start gap-2">
                  <Lock className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <p className="text-xs text-muted-foreground">
                    Set a PIN so you can log in on another phone or computer.
                  </p>
                </div>
                <Button
                  size="sm"
                  onClick={() => { setAuthError(null); setScreen("setpin"); }}
                  className="bg-amber-600 hover:bg-amber-700 text-white shrink-0"
                >
                  Set PIN
                </Button>
              </CardContent>
            </Card>
          )}

          <div className="grid grid-cols-2 gap-4 mb-6">
            <Card 
              className="cursor-pointer hover:border-emerald-500/50 transition-colors bg-card/50"
              onClick={() => setScreen("mood")}
            >
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-emerald-500/20 flex items-center justify-center">
                  <Smile className="w-6 h-6 text-emerald-500" />
                </div>
                <p className="font-medium text-sm">Mood Check</p>
                <p className="text-xs text-muted-foreground">How are you?</p>
              </CardContent>
            </Card>

            <Card 
              className="cursor-pointer hover:border-blue-500/50 transition-colors bg-card/50"
              onClick={() => setScreen("journal")}
            >
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-blue-500/20 flex items-center justify-center">
                  <Sparkles className="w-6 h-6 text-blue-500" />
                </div>
                <p className="font-medium text-sm">AI Journal</p>
                <p className="text-xs text-muted-foreground">Talk it out</p>
              </CardContent>
            </Card>

            <Card 
              className="cursor-pointer hover:border-purple-500/50 transition-colors bg-card/50"
              onClick={() => setScreen("breathing")}
            >
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-purple-500/20 flex items-center justify-center">
                  <Wind className="w-6 h-6 text-purple-500" />
                </div>
                <p className="font-medium text-sm">Breathe</p>
                <p className="text-xs text-muted-foreground">Calm down</p>
              </CardContent>
            </Card>

            <Card 
              className="cursor-pointer hover:border-amber-500/50 transition-colors bg-card/50"
              onClick={() => setScreen("resources")}
            >
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-amber-500/20 flex items-center justify-center">
                  <Phone className="w-6 h-6 text-amber-500" />
                </div>
                <p className="font-medium text-sm">Get Help</p>
                <p className="text-xs text-muted-foreground">Crisis support</p>
              </CardContent>
            </Card>
          </div>

          {/* Quick mood buttons */}
          <Card className="bg-card/50">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Quick check-in</CardTitle>
              <CardDescription className="text-xs">Tap how you&apos;re feeling right now</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex justify-between">
                {[
                  { emoji: "😊", score: 5, label: "Great", icon: Sun, color: "text-yellow-400" },
                  { emoji: "🙂", score: 4, label: "Good", icon: Smile, color: "text-emerald-400" },
                  { emoji: "😐", score: 3, label: "Okay", icon: Meh, color: "text-blue-400" },
                  { emoji: "😔", score: 2, label: "Low", icon: Cloud, color: "text-purple-400" },
                  { emoji: "😢", score: 1, label: "Struggling", icon: CloudRain, color: "text-red-400" }
                ].map((mood) => (
                  <button
                    key={mood.score}
                    onClick={async () => {
                      if (!profileId) return;
                      await supabase.from("mood_logs").insert({
                        youth_profile_id: profileId,
                        mood_score: mood.score,
                        mood_emoji: mood.emoji,
                      });
                      // Update last active
                      await supabase.from("youth_profiles").update({ last_active: new Date().toISOString() }).eq("id", profileId);
                      alert(`Logged: ${mood.label}! Keep tracking to see your patterns.`);
                    }}
                    className="flex flex-col items-center p-2 hover:bg-muted/50 rounded-lg transition-colors"
                  >
                    <mood.icon className={`w-8 h-8 mb-1 ${mood.color}`} />
                    <span className="text-xs text-muted-foreground">{mood.label}</span>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Link to main app */}
          <div className="mt-6 text-center">
            <Link href="/auth/sign-up?type=youth">
              <Button variant="outline" size="sm" className="text-xs">
                <Users className="w-3 h-3 mr-1" />
                Create full account to connect with school
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  // Mood Check Screen
  if (screen === "mood") {
    return <MoodCheckScreen profileId={profileId} onBack={() => setScreen("home")} supabase={supabase} />;
  }

  // Journal Screen  
  if (screen === "journal") {
    return <JournalScreen profileId={profileId} onBack={() => setScreen("home")} supabase={supabase} />;
  }

  // Breathing Screen
  if (screen === "breathing") {
    return <BreathingScreen onBack={() => setScreen("home")} profileId={profileId} supabase={supabase} />;
  }

  // Resources Screen
  if (screen === "resources") {
    return <ResourcesScreen onBack={() => setScreen("home")} />;
  }

  return null;
}

// Mood Check Component
function MoodCheckScreen({ profileId, onBack, supabase }: { profileId: string | null; onBack: () => void; supabase: ReturnType<typeof createClient> }) {
  const [moodScore, setMoodScore] = useState<number | null>(null);
  const [energy, setEnergy] = useState<number | null>(null);
  const [anxiety, setAnxiety] = useState<number | null>(null);
  const [sleep, setSleep] = useState<number | null>(null);
  const [feelings, setFeelings] = useState<string[]>([]);
  const [notes, setNotes] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const feelingOptions = ["Happy", "Sad", "Anxious", "Angry", "Tired", "Excited", "Calm", "Stressed", "Lonely", "Hopeful"];

  const handleSubmit = async () => {
    if (!profileId || moodScore === null) return;
    setIsSubmitting(true);

    await supabase.from("mood_logs").insert({
      youth_profile_id: profileId,
      mood_score: moodScore,
      energy_level: energy,
      anxiety_level: anxiety,
      sleep_quality: sleep,
      feelings: feelings,
      notes: notes || null,
    });

    await supabase.from("youth_profiles").update({ last_active: new Date().toISOString() }).eq("id", profileId);

    setSubmitted(true);
    setIsSubmitting(false);
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#0a1628] via-[#0f2847] to-[#0a1628] flex items-center justify-center px-4">
        <Card className="w-full max-w-lg text-center bg-card/50">
          <CardContent className="p-8">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-emerald-500/20 flex items-center justify-center">
              <Star className="w-8 h-8 text-emerald-500" />
            </div>
            <h2 className="text-xl font-bold mb-2">Check-in Complete!</h2>
            <p className="text-muted-foreground text-sm mb-6">
              Thanks for sharing. Tracking how you feel helps you understand yourself better.
            </p>
            <Button onClick={onBack} className="bg-emerald-600 hover:bg-emerald-700">
              Back to Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a1628] via-[#0f2847] to-[#0a1628] px-4 py-6 max-w-lg mx-auto">
      <Button variant="ghost" onClick={onBack} className="mb-4">
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back
      </Button>
      
      <h1 className="text-2xl font-bold mb-6">How are you feeling?</h1>

      <div className="space-y-6">
        {/* Mood */}
        <Card className="bg-card/50">
          <CardContent className="p-4">
            <Label className="text-sm font-medium mb-3 block">Overall mood</Label>
            <div className="flex justify-between">
              {[
                { icon: Sun, score: 5, color: "text-yellow-400", bg: "bg-yellow-400/20" },
                { icon: Smile, score: 4, color: "text-emerald-400", bg: "bg-emerald-400/20" },
                { icon: Meh, score: 3, color: "text-blue-400", bg: "bg-blue-400/20" },
                { icon: Cloud, score: 2, color: "text-purple-400", bg: "bg-purple-400/20" },
                { icon: CloudRain, score: 1, color: "text-red-400", bg: "bg-red-400/20" }
              ].map((m) => (
                <button
                  key={m.score}
                  onClick={() => setMoodScore(m.score)}
                  className={`p-3 rounded-lg transition-all ${m.bg} ${moodScore === m.score ? "ring-2 ring-white/50 scale-110" : "opacity-60 hover:opacity-100"}`}
                >
                  <m.icon className={`w-8 h-8 ${m.color}`} />
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Energy */}
        <Card className="bg-card/50">
          <CardContent className="p-4">
            <Label className="text-sm font-medium mb-3 block">Energy level</Label>
            <div className="flex gap-2">
              {[1, 2, 3, 4, 5].map((n) => (
                <Button
                  key={n}
                  variant={energy === n ? "default" : "outline"}
                  className={`flex-1 ${energy === n ? "bg-emerald-600" : ""}`}
                  onClick={() => setEnergy(n)}
                >
                  {n}
                </Button>
              ))}
            </div>
            <p className="text-xs text-muted-foreground mt-1">1 = very tired, 5 = full of energy</p>
          </CardContent>
        </Card>

        {/* Anxiety */}
        <Card className="bg-card/50">
          <CardContent className="p-4">
            <Label className="text-sm font-medium mb-3 block">Anxiety level</Label>
            <div className="flex gap-2">
              {[1, 2, 3, 4, 5].map((n) => (
                <Button
                  key={n}
                  variant={anxiety === n ? "default" : "outline"}
                  className={`flex-1 ${anxiety === n ? "bg-amber-600" : ""}`}
                  onClick={() => setAnxiety(n)}
                >
                  {n}
                </Button>
              ))}
            </div>
            <p className="text-xs text-muted-foreground mt-1">1 = calm, 5 = very anxious</p>
          </CardContent>
        </Card>

        {/* Feelings */}
        <Card className="bg-card/50">
          <CardContent className="p-4">
            <Label className="text-sm font-medium mb-3 block">Pick any feelings that fit</Label>
            <div className="flex flex-wrap gap-2">
              {feelingOptions.map((f) => (
                <Button
                  key={f}
                  variant={feelings.includes(f) ? "default" : "outline"}
                  size="sm"
                  className={feelings.includes(f) ? "bg-blue-600" : ""}
                  onClick={() => setFeelings(prev => 
                    prev.includes(f) ? prev.filter(x => x !== f) : [...prev, f]
                  )}
                >
                  {f}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Notes */}
        <Card className="bg-card/50">
          <CardContent className="p-4">
            <Label className="text-sm font-medium mb-2 block">Anything else? (optional)</Label>
            <textarea
              className="w-full p-3 rounded-lg bg-background/50 border border-border resize-none text-sm"
              rows={3}
              placeholder="What happened today..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            />
          </CardContent>
        </Card>

        <Button 
          onClick={handleSubmit}
          disabled={moodScore === null || isSubmitting}
          className="w-full bg-emerald-600 hover:bg-emerald-700 h-12"
        >
          {isSubmitting ? "Saving..." : "Save Check-in"}
        </Button>
      </div>
    </div>
  );
}

// Journal Screen Component
function JournalScreen({ profileId, onBack, supabase }: { profileId: string | null; onBack: () => void; supabase: ReturnType<typeof createClient> }) {
  const [message, setMessage] = useState("");
  const [conversation, setConversation] = useState<{role: string; content: string}[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const handleSend = async () => {
    if (!message.trim() || !profileId) return;
    
    const userMessage = message;
    setMessage("");
    setConversation(prev => [...prev, { role: "user", content: userMessage }]);
    setIsLoading(true);

    try {
      const response = await fetch("/api/youth/journal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          message: userMessage,
          profileId,
          conversationHistory: conversation
        }),
      });

      const data = await response.json();
      setConversation(prev => [...prev, { role: "assistant", content: data.response }]);

      // Save journal entry to database.
      // When flagged, the server route already persisted the entry (plus the
      // safeguarding alert + audit log), so we skip the client insert to avoid
      // duplicating the raw entry.
      if (!data.flagged) {
        await supabase.from("journal_entries").insert({
          youth_profile_id: profileId,
          content: userMessage,
          ai_response: data.response,
          detected_emotions: data.emotions || [],
          flagged_for_review: false,
          flag_reason: null,
        });
      }
    } catch {
      setConversation(prev => [...prev, { 
        role: "assistant", 
        content: "I'm having trouble connecting right now. Remember, if you need immediate support, you can call Childline on 0800 1111." 
      }]);
    }
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a1628] via-[#0f2847] to-[#0a1628] flex flex-col max-w-lg mx-auto">
      <div className="p-4 border-b border-border bg-background/50 backdrop-blur-sm">
        <Button variant="ghost" onClick={onBack} className="mb-2" size="sm">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <h1 className="text-xl font-bold flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-blue-500" />
          AI Journal
        </h1>
        <p className="text-xs text-muted-foreground">Write about anything - I&apos;m here to listen</p>
      </div>

      <div className="flex-1 overflow-auto p-4 space-y-4">
        {conversation.length === 0 && (
          <div className="text-center py-8">
            <Sparkles className="w-12 h-12 mx-auto mb-4 text-blue-500/50" />
            <p className="text-muted-foreground text-sm px-4">
              Hi! I&apos;m here to listen. You can tell me about your day, how you&apos;re feeling, or anything on your mind. This is a safe space.
            </p>
          </div>
        )}
        
        {conversation.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
            <div className={`max-w-[85%] p-3 rounded-2xl ${
              msg.role === "user" 
                ? "bg-emerald-600 text-white rounded-br-sm" 
                : "bg-muted rounded-bl-sm"
            }`}>
              <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-muted p-3 rounded-2xl rounded-bl-sm">
              <p className="text-sm text-muted-foreground">Thinking...</p>
            </div>
          </div>
        )}
      </div>

      <div className="p-4 border-t border-border bg-background/50 backdrop-blur-sm">
        <div className="flex gap-2">
          <textarea
            className="flex-1 p-3 rounded-xl bg-muted/50 border border-border resize-none text-sm"
            rows={2}
            placeholder="Write something..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
          />
          <Button 
            onClick={handleSend}
            disabled={!message.trim() || isLoading}
            className="bg-emerald-600 hover:bg-emerald-700 self-end"
            size="icon"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}

// Breathing Exercise Screen
function BreathingScreen({ onBack, profileId, supabase }: { onBack: () => void; profileId: string | null; supabase: ReturnType<typeof createClient> }) {
  const [isActive, setIsActive] = useState(false);
  const [phase, setPhase] = useState<"inhale" | "hold" | "exhale">("inhale");
  const [seconds, setSeconds] = useState(0);
  const [totalSeconds, setTotalSeconds] = useState(0);

  useEffect(() => {
    if (!isActive) return;

    const interval = setInterval(() => {
      setTotalSeconds(t => t + 1);
      setSeconds(s => {
        const newS = s + 1;
        // 4-7-8 breathing pattern
        if (phase === "inhale" && newS >= 4) {
          setPhase("hold");
          return 0;
        }
        if (phase === "hold" && newS >= 7) {
          setPhase("exhale");
          return 0;
        }
        if (phase === "exhale" && newS >= 8) {
          setPhase("inhale");
          return 0;
        }
        return newS;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isActive, phase]);

  const handleComplete = async () => {
    setIsActive(false);
    if (profileId && totalSeconds > 10) {
      await supabase.from("coping_tools").insert({
        youth_profile_id: profileId,
        exercise_type: "breathing-478",
        duration_seconds: totalSeconds,
      });
    }
    onBack();
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a1628] via-[#0f2847] to-[#0a1628] flex flex-col items-center justify-center px-4">
      <Button variant="ghost" onClick={onBack} className="absolute top-4 left-4">
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back
      </Button>
      
      <div className="text-center">
        <p className="text-sm text-muted-foreground mb-4">4-7-8 Breathing</p>
        
        <div 
          className={`w-48 h-48 mx-auto mb-8 rounded-full flex items-center justify-center transition-all duration-1000 ${
            phase === "inhale" ? "bg-blue-500/30 scale-110" :
            phase === "hold" ? "bg-purple-500/30 scale-100" :
            "bg-emerald-500/30 scale-90"
          }`}
        >
          <div className="text-center">
            <p className="text-2xl font-bold capitalize">{isActive ? phase : "Ready?"}</p>
            {isActive && (
              <>
                <p className="text-5xl font-mono mt-2">{seconds}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  {phase === "inhale" && "Breathe in..."}
                  {phase === "hold" && "Hold..."}
                  {phase === "exhale" && "Breathe out..."}
                </p>
              </>
            )}
          </div>
        </div>

        <p className="text-muted-foreground text-sm mb-6 max-w-xs mx-auto">
          {!isActive && "Breathe in for 4 seconds, hold for 7, out for 8. This helps calm your nervous system."}
        </p>

        {!isActive ? (
          <Button onClick={() => { setIsActive(true); setTotalSeconds(0); }} className="bg-emerald-600 hover:bg-emerald-700 h-12 px-8">
            Start Breathing Exercise
          </Button>
        ) : (
          <Button onClick={handleComplete} variant="outline">
            I feel better now
          </Button>
        )}
      </div>
    </div>
  );
}

// Resources Screen
function ResourcesScreen({ onBack }: { onBack: () => void }) {
  const resources = [
    { name: "Childline", phone: "0800 1111", description: "Free, confidential support for under 19s", available: "24/7" },
    { name: "Samaritans", phone: "116 123", description: "Someone to talk to anytime", available: "24/7" },
    { name: "Shout", phone: "Text SHOUT to 85258", description: "Free text support", available: "24/7" },
    { name: "Young Minds", phone: "Text YM to 85258", description: "Mental health support for young people", available: "24/7" },
    { name: "Papyrus (HOPELINEUK)", phone: "0800 068 4141", description: "If you're having thoughts of suicide", available: "24/7" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0a1628] via-[#0f2847] to-[#0a1628] px-4 py-6 max-w-lg mx-auto">
      <Button variant="ghost" onClick={onBack} className="mb-4">
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back
      </Button>
      
      <h1 className="text-2xl font-bold mb-2">Get Help Now</h1>
      <p className="text-muted-foreground text-sm mb-6">
        These services are free, confidential, and here for you
      </p>

      <div className="space-y-4">
        {resources.map((r, i) => (
          <Card key={i} className="bg-card/50">
            <CardContent className="p-4">
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-bold">{r.name}</h3>
                <span className="text-xs text-emerald-500 bg-emerald-500/10 px-2 py-1 rounded">{r.available}</span>
              </div>
              <p className="text-sm text-muted-foreground mb-3">{r.description}</p>
              <a href={r.phone.startsWith("Text") ? `sms:85258` : `tel:${r.phone.replace(/\s/g, "")}`}>
                <Button className="w-full bg-emerald-600 hover:bg-emerald-700">
                  <Phone className="w-4 h-4 mr-2" />
                  {r.phone}
                </Button>
              </a>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="mt-6 border-red-500/30 bg-red-500/5">
        <CardContent className="p-4 text-center">
          <p className="font-bold text-red-400 mb-2">In immediate danger?</p>
          <a href="tel:999">
            <Button className="bg-red-600 hover:bg-red-700 w-full">
              Call 999
            </Button>
          </a>
        </CardContent>
      </Card>
    </div>
  );
}
