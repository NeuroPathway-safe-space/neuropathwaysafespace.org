import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { NextResponse } from "next/server";

// Link a youth profile to a child in the EHCP system
export async function POST(req: Request) {
  const { linkCode, childId, action } = await req.json();

  const supabase = await createClient();

  // Get the current user (parent/school staff)
  const { data: { user } } = await supabase.auth.getUser();
  
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  if (action === "link") {
    // Find the youth profile by link code
    const { data: youthProfile, error: findError } = await supabase
      .from("youth_profiles")
      .select("id, display_name, consent_given, parental_consent")
      .eq("link_code", linkCode)
      .single();

    if (findError || !youthProfile) {
      return NextResponse.json({ error: "Invalid link code" }, { status: 404 });
    }

    // Verify the child belongs to this user
    const { data: child, error: childError } = await supabase
      .from("children")
      .select("id, first_name")
      .eq("id", childId)
      .eq("user_id", user.id)
      .single();

    if (childError || !child) {
      return NextResponse.json({ error: "Child not found or unauthorized" }, { status: 404 });
    }

    // Link the youth profile to the child.
    // Ownership of `childId` is already verified above. We use the service-role
    // client for this UPDATE because the youth_profiles RLS UPDATE policy keys
    // off `linked_by_user_id`, which is still NULL before this first link — so a
    // non-admin parent's update would otherwise affect zero rows.
    const admin = createAdminClient();
    const { error: updateError } = await admin
      .from("youth_profiles")
      .update({
        linked_child_id: childId,
        linked_by_user_id: user.id,
      })
      .eq("id", youthProfile.id);

    if (updateError) {
      return NextResponse.json({ error: "Failed to link profiles" }, { status: 500 });
    }

    // Log the link action
    await supabase.from("audit_logs").insert({
      user_id: user.id,
      action: "youth_profile_linked",
      entity_type: "youth_profile",
      entity_id: youthProfile.id,
      details: { 
        childId, 
        youthDisplayName: youthProfile.display_name,
        childFirstName: child.first_name 
      },
    });

    return NextResponse.json({ 
      status: "linked", 
      message: `Youth profile "${youthProfile.display_name}" linked to ${child.first_name}`,
      youthProfile: {
        id: youthProfile.id,
        displayName: youthProfile.display_name,
      }
    });
  }

  if (action === "sync_to_observations") {
    // Sync youth mood data to EHCP observations
    const { data: youthProfile } = await supabase
      .from("youth_profiles")
      .select("id, linked_child_id")
      .eq("link_code", linkCode)
      .eq("linked_by_user_id", user.id)
      .single();

    if (!youthProfile || !youthProfile.linked_child_id) {
      return NextResponse.json({ error: "Profile not linked" }, { status: 400 });
    }

    // Get recent mood checkins that haven't been synced
    const { data: moodCheckins } = await supabase
      .from("mood_logs")
      .select("*")
      .eq("youth_profile_id", youthProfile.id)
      .order("created_at", { ascending: false })
      .limit(30);

    if (!moodCheckins || moodCheckins.length === 0) {
      return NextResponse.json({ status: "no_data", message: "No mood data to sync" });
    }

    // Get the emotional regulation category
    const { data: category } = await supabase
      .from("observation_categories")
      .select("id")
      .eq("name", "Emotional Regulation")
      .single();

    // Create observations from mood data
    const observations = moodCheckins.map(checkin => ({
      user_id: user.id,
      child_id: youthProfile.linked_child_id,
      category_id: category?.id,
      title: `Youth Self-Report: ${checkin.mood_emoji || "Mood Check"}`,
      antecedent: "Self-reported via Youth Safe Space app",
      behaviour: `Mood: ${checkin.mood_score}/5, Energy: ${checkin.energy_level || "N/A"}/5, Anxiety: ${checkin.anxiety_level || "N/A"}/5. Feelings: ${checkin.feelings?.join(", ") || "None specified"}`,
      consequence: checkin.notes || "No additional notes provided",
      severity: mapMoodToSeverity(checkin.mood_score),
      time_of_day: getTimeOfDay(new Date(checkin.created_at)),
      setting: "Home/Personal",
      support_provided: "Youth Safe Space app - mood tracking",
      outcome: checkin.mood_score >= 3 ? "Coping adequately" : "May need additional support",
      created_at: checkin.created_at,
    }));

    // Insert observations (skip duplicates by checking dates)
    let syncedCount = 0;
    for (const obs of observations) {
      const { error } = await supabase.from("observations").insert(obs);
      if (!error) syncedCount++;
    }

    // Log the sync
    await supabase.from("audit_logs").insert({
      user_id: user.id,
      action: "youth_data_synced",
      entity_type: "observations",
      details: { 
        youthProfileId: youthProfile.id,
        childId: youthProfile.linked_child_id,
        syncedCount,
      },
    });

    return NextResponse.json({ 
      status: "synced", 
      message: `Synced ${syncedCount} mood entries to EHCP observations`,
      syncedCount,
    });
  }

  return NextResponse.json({ error: "Invalid action" }, { status: 400 });
}

// Get linked youth profiles for a user's children
export async function GET(req: Request) {
  const supabase = await createClient();

  const { data: { user } } = await supabase.auth.getUser();
  
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  // Get all youth profiles linked to this user's children
  const { data: youthProfiles, error } = await supabase
    .from("youth_profiles")
    .select(`
      id,
      display_name,
      age_range,
      link_code,
      linked_child_id,
      consent_given,
      parental_consent,
      last_active,
      created_at,
      children:linked_child_id (
        id,
        first_name,
        last_name
      )
    `)
    .eq("linked_by_user_id", user.id);

  if (error) {
    return NextResponse.json({ error: "Failed to fetch profiles" }, { status: 500 });
  }

  // Get summary stats for each profile
  const profilesWithStats = await Promise.all(
    (youthProfiles || []).map(async (profile) => {
      const { count: moodCount } = await supabase
        .from("mood_logs")
        .select("*", { count: "exact", head: true })
        .eq("youth_profile_id", profile.id);

      const { count: journalCount } = await supabase
        .from("journal_entries")
        .select("*", { count: "exact", head: true })
        .eq("youth_profile_id", profile.id);

      const { data: recentMood } = await supabase
        .from("mood_logs")
        .select("mood_score, mood_emoji, created_at")
        .eq("youth_profile_id", profile.id)
        .order("created_at", { ascending: false })
        .limit(1)
        .single();

      return {
        ...profile,
        stats: {
          moodCheckins: moodCount || 0,
          journalEntries: journalCount || 0,
          recentMood: recentMood || null,
        }
      };
    })
  );

  return NextResponse.json({ profiles: profilesWithStats });
}

// Map mood score to severity (inverted)
function mapMoodToSeverity(mood: number | null): number {
  if (!mood) return 3;
  return 6 - mood; // 5 mood = 1 severity, 1 mood = 5 severity
}

// Get time of day from date
function getTimeOfDay(date: Date): string {
  const hour = date.getHours();
  if (hour < 12) return "morning";
  if (hour < 17) return "afternoon";
  return "evening";
}
