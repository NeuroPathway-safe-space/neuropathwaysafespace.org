import { createAdminClient } from "@/lib/supabase/admin";
import { verifyPin } from "@/lib/youth-pin";
import { NextResponse } from "next/server";

/**
 * Lightweight child login for the Safe Space app.
 *
 * Children are not Supabase auth users. They sign back in on any device with
 * their link code + PIN. We look the profile up with the service-role client,
 * verify the salted PIN hash, and return only the minimal identity the app
 * needs (id + display name). No raw journal/mood data is returned here.
 */
export async function POST(req: Request) {
  const { linkCode, pin } = await req.json();

  if (!linkCode || !pin) {
    return NextResponse.json({ error: "Enter your code and PIN" }, { status: 400 });
  }

  const admin = createAdminClient();

  const { data: profile, error } = await admin
    .from("youth_profiles")
    .select("id, display_name, pin_hash")
    .eq("link_code", String(linkCode).trim().toUpperCase())
    .single();

  // Generic message so we don't reveal whether the code or the PIN was wrong.
  const invalid = NextResponse.json(
    { error: "That code or PIN didn't match. Try again." },
    { status: 401 },
  );

  if (error || !profile) return invalid;
  if (!profile.pin_hash) {
    return NextResponse.json(
      { error: "This profile has no PIN yet. Set one from the device you created it on." },
      { status: 400 },
    );
  }
  if (!verifyPin(String(pin), profile.pin_hash)) return invalid;

  // Touch last_active so professionals can see engagement.
  await admin
    .from("youth_profiles")
    .update({ last_active: new Date().toISOString() })
    .eq("id", profile.id);

  return NextResponse.json({
    status: "ok",
    profile: {
      id: profile.id,
      displayName: profile.display_name,
      linkCode: String(linkCode).trim().toUpperCase(),
    },
  });
}
