import { generateText } from "ai";
import { resolveModel } from "@/lib/ai/model";
import { createAdminClient } from "@/lib/supabase/admin";

// Safeguarding overrides privacy: when crisis content is detected we persist a
// flagged journal entry, an audit-trail event, and (when the child app profile
// is linked to a platform child record) a safeguarding alert for professionals.
async function escalateSafeguarding(
  profileId: string | undefined,
  message: string,
  matchedKeyword: string,
) {
  if (!profileId) return;
  try {
    const admin = createAdminClient();

    // Always preserve a flagged, private journal entry (raw text never leaves this table).
    const { data: entry } = await admin
      .from("journal_entries")
      .insert({
        youth_profile_id: profileId,
        content: message,
        flagged_for_review: true,
        flag_reason: "Crisis language detected - potential safeguarding concern",
        detected_emotions: ["distressed", "struggling"],
      })
      .select("id")
      .single();

    // Resolve the linked child and the adult who linked this profile (if any).
    const { data: profile } = await admin
      .from("youth_profiles")
      .select("id, linked_child_id, linked_by_user_id")
      .eq("id", profileId)
      .single();

    // safeguarding_alerts.child_id is NOT NULL, so an alert can only be raised
    // once the profile is linked to a platform child record.
    if (profile?.linked_child_id) {
      await admin.from("safeguarding_alerts").insert({
        child_id: profile.linked_child_id,
        // Attribute the alert to the linking professional/parent. The alerts API
        // restricts non-admins to alerts where user_id or assigned_to matches
        // their id, so without this the alert would only ever be visible to
        // admins and never reach the responsible adult who linked the child.
        user_id: profile.linked_by_user_id ?? null,
        assigned_to: profile.linked_by_user_id ?? null,
        source: "ai_detection",
        source_id: entry?.id ?? null,
        severity: "high",
        alert_type: "crisis_language",
        description:
          "Crisis language detected in a Safe Space journal entry. Immediate review by an authorised safeguarding lead is required.",
        ai_reasoning: `Automated keyword detection matched "${matchedKeyword}". Raw entry text is withheld; review the flagged record in the safeguarding workflow.`,
        status: "new",
      });
    }

    // Always log the event to the audit trail, linked or not.
    await admin.from("audit_logs").insert({
      action: "safeguarding_crisis_detected",
      entity_type: "youth_profile",
      entity_id: profileId,
      details: {
        source: "safe_space_journal",
        linked: !!profile?.linked_child_id,
        matched_keyword: matchedKeyword,
        journal_entry_id: entry?.id ?? null,
      },
    });
  } catch (error) {
    console.error("[v0] Safeguarding escalation failed:", error);
  }
}

export async function POST(req: Request) {
  const { message, profileId, conversationHistory = [] } = await req.json();

  // Check for crisis keywords using whole-word matching so benign words that
  // merely contain a keyword as a substring (e.g. "died"/"diet" for "die",
  // "indie" for "die") do not trigger a false safeguarding escalation.
  const crisisKeywords = ["suicide", "kill myself", "end it", "hurt myself", "self harm", "die", "cutting", "don't want to live", "want to die"];
  const lowerForCrisis = typeof message === "string" ? message.toLowerCase() : "";
  const matchedKeyword = crisisKeywords.find((keyword) => {
    const escaped = keyword.replace(/[.*+?^${}()|[\]\\]/g, (c) => "\\" + c);
    return new RegExp(`\\b${escaped}\\b`, "i").test(lowerForCrisis);
  });
  const hasCrisisContent = !!matchedKeyword;

  if (hasCrisisContent) {
    // Persist flag, audit trail, and (if linked) a safeguarding alert before responding.
    await escalateSafeguarding(profileId, message, matchedKeyword);

    return Response.json({
      response: `I can hear that you're going through something really difficult right now. Please know that you matter and there are people who want to help. Please reach out to Childline right now on 0800 1111 - they're free, confidential, and available 24/7. You don't have to go through this alone. Would you like me to share some other resources that might help?`,
      emotions: ["distressed", "struggling"],
      flagged: true,
      flagReason: "Crisis keywords detected - potential safeguarding concern",
    });
  }

  try {
    // Build conversation context
    const contextMessages = conversationHistory.slice(-6).map((msg: { role: string; content: string }) => 
      `${msg.role === "user" ? "Young person" : "You"}: ${msg.content}`
    ).join("\n");

    const result = await generateText({
      model: resolveModel("openai/gpt-4o-mini"),
      system: `You are a supportive, warm AI companion for young people in a mental health app called NeuroPathway Safe Space. 

Your role is to:
- Be like a kind, understanding friend who listens without judgment
- Acknowledge and validate their feelings
- Offer gentle encouragement and hope
- Suggest simple coping strategies when appropriate (like breathing, journaling, talking to someone)
- NEVER diagnose, give medical advice, or replace professional help
- ALWAYS encourage them to talk to a trusted adult if they're really struggling
- Keep responses conversational and warm (3-4 sentences usually)
- Use simple, friendly language appropriate for young people
- Ask gentle follow-up questions to show you care

If they mention anything concerning about safety, self-harm, abuse, or bullying, gently acknowledge it and encourage them to speak to a trusted adult or contact Childline (0800 1111).

Remember: You're a supportive friend in their pocket, not a therapist. Be real, be warm, be brief.`,
      prompt: `${contextMessages ? `Previous conversation:\n${contextMessages}\n\n` : ""}The young person writes: "${message}"

Respond naturally as their supportive AI friend.`,
      maxOutputTokens: 200,
    });

    // Simple emotion detection
    const emotions: string[] = [];
    const lowerMessage = message.toLowerCase();
    if (lowerMessage.includes("sad") || lowerMessage.includes("cry") || lowerMessage.includes("upset")) emotions.push("sad");
    if (lowerMessage.includes("angry") || lowerMessage.includes("mad") || lowerMessage.includes("furious")) emotions.push("angry");
    if (lowerMessage.includes("anxious") || lowerMessage.includes("worried") || lowerMessage.includes("scared")) emotions.push("anxious");
    if (lowerMessage.includes("happy") || lowerMessage.includes("good") || lowerMessage.includes("great")) emotions.push("happy");
    if (lowerMessage.includes("tired") || lowerMessage.includes("exhausted")) emotions.push("tired");
    if (lowerMessage.includes("lonely") || lowerMessage.includes("alone")) emotions.push("lonely");
    if (lowerMessage.includes("stressed") || lowerMessage.includes("overwhelmed")) emotions.push("stressed");

    return Response.json({
      response: result.text,
      emotions,
      flagged: false,
      flagReason: null,
    });
  } catch (error) {
    console.error("AI Journal error:", error);
    return Response.json({
      response: `Thanks for sharing that with me. Your feelings are valid, and it takes courage to write them down. Remember, if things ever feel too heavy, talking to someone you trust can really help. I'm here whenever you want to chat.`,
      emotions: [],
      flagged: false,
      flagReason: null,
    });
  }
}
