import { createAdminClient } from "@/lib/supabase/admin";
import { hashPin, isValidPin } from "@/lib/youth-pin";
import { NextResponse } from "next/server";

/**
 * Lets a child set (or change) the PIN on their own Safe Space profile.
 * Ownership is proven by supplying BOTH the profile id and its link code,
 * which only the child who created the profile has. Uses the service-role
 * client because children are not Supabase auth users.
 */
export async function POST(req: Request) {
  const { profileId, linkCode, pin } = await req.json();

  if (!profileId || !linkCode || !pin) {
    return NextResponse.json({ error: "Missing details" }, { status: 400 });
  }

  if (!isValidPin(pin)) {
    return NextResponse.json(
      { error: "PIN must be 4 to 8 digits." },
      { status: 400 },
    );
  }

  const admin = createAdminClient();

  // Verify the profile id and link code belong to the same profile.
  const { data: profile, error: findError } = await admin
    .from("youth_profiles")
    .select("id, link_code")
    .eq("id", profileId)
    .single();

  if (findError || !profile || profile.link_code !== linkCode) {
    return NextResponse.json({ error: "Profile not found" }, { status: 404 });
  }

  const { error: updateError } = await admin
    .from("youth_profiles")
    .update({ pin_hash: hashPin(pin) })
    .eq("id", profileId);

  if (updateError) {
    return NextResponse.json({ error: "Could not save PIN" }, { status: 500 });
  }

  return NextResponse.json({ status: "ok" });
}
