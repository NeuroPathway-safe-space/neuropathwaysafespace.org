import { createClient } from "@/lib/supabase/server";
import { generateText } from "ai";
import { resolveModel } from "@/lib/ai/model";
import { NextResponse } from "next/server";

export async function POST(req: Request) {
  const { childId } = await req.json();

  const supabase = await createClient();

  const { data: { user } } = await supabase.auth.getUser();
  
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  // Verify the child belongs to this user
  const { data: child } = await supabase
    .from("children")
    .select("id, first_name, last_name")
    .eq("id", childId)
    .eq("user_id", user.id)
    .single();

  if (!child) {
    return NextResponse.json({ error: "Child not found" }, { status: 404 });
  }

  // Get linked youth profile if any
  const { data: youthProfile } = await supabase
    .from("youth_profiles")
    .select("id, display_name")
    .eq("linked_child_id", childId)
    .single();

  // Gather all data sources
  const [observations, moodCheckins, journalEntries, exercises] = await Promise.all([
    // EHCP Observations (last 30 days)
    supabase
      .from("observations")
      .select("*")
      .eq("child_id", childId)
      .gte("created_at", new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString())
      .order("created_at", { ascending: false })
      .limit(50),
    
    // Youth mood checkins
    youthProfile ? supabase
      .from("mood_logs")
      .select("*")
      .eq("youth_profile_id", youthProfile.id)
      .gte("created_at", new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString())
      .order("created_at", { ascending: false })
      .limit(50) : Promise.resolve({ data: [] }),
    
    // Youth journal entries (without AI responses for privacy)
    youthProfile ? supabase
      .from("journal_entries")
      .select("id, detected_emotions, detected_themes, flagged_for_review, created_at")
      .eq("youth_profile_id", youthProfile.id)
      .gte("created_at", new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString())
      .order("created_at", { ascending: false })
      .limit(30) : Promise.resolve({ data: [] }),
    
    // Grounding exercises completed
    youthProfile ? supabase
      .from("coping_tools")
      .select("*")
      .eq("youth_profile_id", youthProfile.id)
      .gte("created_at", new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString())
      .order("created_at", { ascending: false }) : Promise.resolve({ data: [] }),
  ]);

  // Calculate basic statistics
  const moodData = moodCheckins.data || [];
  const avgMood = moodData.length > 0 
    ? moodData.reduce((sum, m) => sum + (m.mood_score || 0), 0) / moodData.length 
    : null;
  
  const avgAnxiety = moodData.filter(m => m.anxiety_level).length > 0
    ? moodData.filter(m => m.anxiety_level).reduce((sum, m) => sum + m.anxiety_level, 0) / moodData.filter(m => m.anxiety_level).length
    : null;

  const avgEnergy = moodData.filter(m => m.energy_level).length > 0
    ? moodData.filter(m => m.energy_level).reduce((sum, m) => sum + m.energy_level, 0) / moodData.filter(m => m.energy_level).length
    : null;

  // Count feelings
  const feelingCounts: Record<string, number> = {};
  moodData.forEach(m => {
    (m.feelings || []).forEach((f: string) => {
      feelingCounts[f] = (feelingCounts[f] || 0) + 1;
    });
  });

  // Detect patterns in observations
  const observationData = observations.data || [];
  const severityCounts = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
  observationData.forEach(o => {
    if (o.severity) severityCounts[o.severity as keyof typeof severityCounts]++;
  });

  // Flagged journal entries (safeguarding)
  const flaggedEntries = (journalEntries.data || []).filter(j => j.flagged_for_review);

  // Generate AI insights
  const dataContext = {
    childName: child.first_name,
    hasYouthProfile: !!youthProfile,
    period: "30 days",
    observations: {
      count: observationData.length,
      severityDistribution: severityCounts,
      categories: [...new Set(observationData.map(o => o.category_id))].length,
    },
    selfReported: youthProfile ? {
      moodCheckins: moodData.length,
      averageMood: avgMood?.toFixed(1),
      averageAnxiety: avgAnxiety?.toFixed(1),
      averageEnergy: avgEnergy?.toFixed(1),
      topFeelings: Object.entries(feelingCounts)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5)
        .map(([feeling, count]) => ({ feeling, count })),
      journalEntries: (journalEntries.data || []).length,
      flaggedForReview: flaggedEntries.length,
      exercisesCompleted: (exercises.data || []).length,
    } : null,
  };

  let aiInsights = "";
  try {
    const result = await generateText({
      model: resolveModel("openai/gpt-4o-mini"),
      system: `You are an educational psychologist assistant analyzing behaviour and wellbeing data for a child's EHCP (Education, Health and Care Plan) support.

Your role is to:
1. Identify patterns in the data that could inform support strategies
2. Highlight any concerning trends that may need attention
3. Suggest evidence-based interventions based on observed patterns
4. Note positive trends and progress
5. Flag any safeguarding concerns for adult review

Keep insights concise, professional, and actionable. Use bullet points.
Do NOT diagnose conditions - only describe observed patterns.
Always reference the data source (parent observation vs self-reported).`,
      prompt: `Analyze this 30-day data summary for ${child.first_name}:

DATA SUMMARY:
${JSON.stringify(dataContext, null, 2)}

Provide:
1. KEY PATTERNS (3-5 bullet points)
2. AREAS OF CONCERN (if any)
3. POSITIVE INDICATORS (if any)
4. RECOMMENDED STRATEGIES (2-3 actionable suggestions)
${flaggedEntries.length > 0 ? '\n5. SAFEGUARDING NOTE: There are flagged journal entries that require adult review.' : ''}`,
      maxOutputTokens: 600,
    });

    aiInsights = result.text;
  } catch (error) {
    console.error("AI insights error:", error);
    aiInsights = "Unable to generate AI insights at this time.";
  }

  // Build response
  const response = {
    child: {
      id: child.id,
      name: `${child.first_name} ${child.last_name}`,
    },
    youthProfile: youthProfile ? {
      id: youthProfile.id,
      displayName: youthProfile.display_name,
      linked: true,
    } : null,
    period: "30 days",
    statistics: {
      observations: {
        total: observationData.length,
        severityDistribution: severityCounts,
        highSeverityCount: severityCounts[4] + severityCounts[5],
      },
      selfReported: youthProfile ? {
        moodCheckins: moodData.length,
        averageMood: avgMood,
        averageAnxiety: avgAnxiety,
        averageEnergy: avgEnergy,
        topFeelings: Object.entries(feelingCounts)
          .sort((a, b) => b[1] - a[1])
          .slice(0, 5),
        journalEntries: (journalEntries.data || []).length,
        exercisesCompleted: (exercises.data || []).length,
      } : null,
    },
    safeguarding: {
      flaggedEntries: flaggedEntries.length,
      requiresReview: flaggedEntries.length > 0,
    },
    aiInsights,
    generatedAt: new Date().toISOString(),
  };

  // Persist a professional-facing SUMMARY only (raw journals/moods never cross over).
  // This is what the professional dashboard reads via pattern_analysis.
  const periodEnd = new Date();
  const periodStart = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
  const severityTrend =
    avgMood == null ? "insufficient_data" : avgMood >= 3.5 ? "stable" : avgMood >= 2.5 ? "monitor" : "declining";

  await supabase.from("pattern_analysis").insert({
    child_id: childId,
    youth_profile_id: youthProfile?.id ?? null,
    domain: "emotional_wellbeing",
    pattern_name: "Self-reported wellbeing summary",
    summary: aiInsights,
    trend: severityTrend,
    frequency: `${moodData.length} mood check-ins / 30 days`,
    severity: severityCounts[4] + severityCounts[5] > 0 ? "elevated" : "typical",
    evidence_count: observationData.length + moodData.length,
    period_start: periodStart.toISOString().slice(0, 10),
    period_end: periodEnd.toISOString().slice(0, 10),
    source: youthProfile ? "safe_space" : "observations",
  });

  // Log the analysis
  await supabase.from("audit_logs").insert({
    user_id: user.id,
    action: "pattern_analysis_generated",
    entity_type: "child",
    entity_id: childId,
    details: { 
      hasYouthData: !!youthProfile,
      observationCount: observationData.length,
      moodCheckinCount: moodData.length,
    },
  });

  return NextResponse.json(response);
}

// GET endpoint to check if pattern analysis is available
export async function GET(req: Request) {
  const url = new URL(req.url);
  const childId = url.searchParams.get("childId");

  if (!childId) {
    return NextResponse.json({ error: "childId required" }, { status: 400 });
  }

  const supabase = await createClient();

  const { data: { user } } = await supabase.auth.getUser();
  
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  // Check if child has youth profile linked
  const { data: youthProfile } = await supabase
    .from("youth_profiles")
    .select("id")
    .eq("linked_child_id", childId)
    .single();

  // Count available data
  const [obsCount, moodCount] = await Promise.all([
    supabase
      .from("observations")
      .select("*", { count: "exact", head: true })
      .eq("child_id", childId)
      .gte("created_at", new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()),
    
    youthProfile ? supabase
      .from("mood_logs")
      .select("*", { count: "exact", head: true })
      .eq("youth_profile_id", youthProfile.id)
      .gte("created_at", new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString())
    : Promise.resolve({ count: 0 }),
  ]);

  return NextResponse.json({
    hasData: (obsCount.count || 0) > 0 || (moodCount.count || 0) > 0,
    hasYouthProfile: !!youthProfile,
    observationCount: obsCount.count || 0,
    moodCheckinCount: moodCount.count || 0,
    canGenerateInsights: (obsCount.count || 0) >= 3 || (moodCount.count || 0) >= 5,
  });
}
