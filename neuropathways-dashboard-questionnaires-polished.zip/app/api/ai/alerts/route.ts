import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient()
    const { data: { user } } = await supabase.auth.getUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Check if user is admin
    const { data: profile } = await supabase
      .from('profiles')
      .select('is_admin')
      .eq('id', user.id)
      .single()

    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')
    const severity = searchParams.get('severity')
    const childId = searchParams.get('child_id')

    let query = supabase
      .from('safeguarding_alerts')
      .select(`
        *,
        children(first_name, last_name),
        profiles!safeguarding_alerts_assigned_to_fkey(full_name, email)
      `)
      .order('created_at', { ascending: false })

    // Non-admins only see alerts for their children or assigned to them
    if (!profile?.is_admin) {
      query = query.or(`user_id.eq.${user.id},assigned_to.eq.${user.id}`)
    }

    if (status) {
      query = query.eq('status', status)
    } else {
      // Default to showing active alerts
      query = query.in('status', ['new', 'acknowledged', 'investigating', 'escalated'])
    }

    if (severity) {
      query = query.eq('severity', severity)
    }

    if (childId) {
      query = query.eq('child_id', childId)
    }

    const { data: alerts, error } = await query.limit(100)

    if (error) {
      return NextResponse.json({ error: 'Failed to fetch alerts' }, { status: 500 })
    }

    return NextResponse.json(alerts)
  } catch (error) {
    console.error('Fetch error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch alerts' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()
    const { data: { user } } = await supabase.auth.getUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { child_id, alert_type, description, severity = 'medium' } = body

    if (!child_id || !alert_type || !description) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    // Verify user owns this child
    const { data: child, error: childError } = await supabase
      .from('children')
      .select('id')
      .eq('id', child_id)
      .eq('user_id', user.id)
      .single()

    if (childError || !child) {
      return NextResponse.json({ error: 'Child not found' }, { status: 404 })
    }

    const { data: alert, error } = await supabase
      .from('safeguarding_alerts')
      .insert({
        child_id,
        user_id: user.id,
        source: 'manual',
        alert_type,
        description,
        severity,
        status: 'new'
      })
      .select()
      .single()

    if (error) {
      return NextResponse.json({ error: 'Failed to create alert' }, { status: 500 })
    }

    return NextResponse.json(alert)
  } catch (error) {
    console.error('Create error:', error)
    return NextResponse.json(
      { error: 'Failed to create alert' },
      { status: 500 }
    )
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const supabase = await createClient()
    const { data: { user } } = await supabase.auth.getUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { alert_id, action, notes, escalate_to } = body

    if (!alert_id || !action) {
      return NextResponse.json({ error: 'alert_id and action are required' }, { status: 400 })
    }

    const validActions = ['acknowledge', 'investigate', 'escalate', 'resolve', 'false_positive', 'assign']
    if (!validActions.includes(action)) {
      return NextResponse.json({ error: 'Invalid action' }, { status: 400 })
    }

    // Check if user is admin
    const { data: profile } = await supabase
      .from('profiles')
      .select('is_admin')
      .eq('id', user.id)
      .single()

    // Verify the caller is authorized to mutate this alert:
    // admins can act on any alert, others only on alerts they own or are assigned to.
    const { data: existingAlert, error: alertError } = await supabase
      .from('safeguarding_alerts')
      .select('id, user_id, assigned_to')
      .eq('id', alert_id)
      .single()

    if (alertError || !existingAlert) {
      return NextResponse.json({ error: 'Alert not found' }, { status: 404 })
    }

    const isAuthorized = profile?.is_admin
      || existingAlert.user_id === user.id
      || existingAlert.assigned_to === user.id

    if (!isAuthorized) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    const updates: Record<string, unknown> = {}

    switch (action) {
      case 'acknowledge':
        updates.status = 'acknowledged'
        updates.acknowledged_at = new Date().toISOString()
        updates.assigned_to = user.id
        break
      case 'investigate':
        updates.status = 'investigating'
        updates.assigned_to = user.id
        break
      case 'escalate':
        updates.status = 'escalated'
        updates.escalated_to = escalate_to
        break
      case 'resolve':
        updates.status = 'resolved'
        updates.resolution_notes = notes
        updates.resolved_at = new Date().toISOString()
        break
      case 'false_positive':
        updates.status = 'false_positive'
        updates.resolution_notes = notes
        updates.resolved_at = new Date().toISOString()
        break
      case 'assign':
        updates.assigned_to = body.assign_to
        break
    }

    const { error } = await supabase
      .from('safeguarding_alerts')
      .update(updates)
      .eq('id', alert_id)

    if (error) {
      return NextResponse.json({ error: 'Failed to update alert' }, { status: 500 })
    }

    // Log to audit
    await supabase.from('audit_logs').insert({
      user_id: user.id,
      action: `safeguarding_${action}`,
      entity_type: 'safeguarding_alert',
      entity_id: alert_id,
      details: { action, notes }
    })

    return NextResponse.json({ success: true, action })
  } catch (error) {
    console.error('Update error:', error)
    return NextResponse.json(
      { error: 'Failed to update alert' },
      { status: 500 }
    )
  }
}
