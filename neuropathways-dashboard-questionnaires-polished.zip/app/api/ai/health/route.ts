import { NextResponse } from 'next/server'
import { generateText } from 'ai'
import { resolveModel, isAzureFoundryConfigured, activeModelLabel, azureDeployment } from '@/lib/ai/model'

export const dynamic = 'force-dynamic'

/**
 * Lightweight connectivity check for the NeuroPathway AI backend.
 *
 * GET  -> reports whether Azure AI Foundry is configured (no model call).
 * POST -> performs a live round-trip to the agent to confirm connectivity.
 */
export async function GET() {
  return NextResponse.json({
    backend: isAzureFoundryConfigured ? 'azure-ai-foundry' : 'vercel-ai-gateway',
    label: activeModelLabel(),
    configured: isAzureFoundryConfigured,
    deployment: isAzureFoundryConfigured ? azureDeployment : null,
    endpointConfigured: Boolean(process.env.AZURE_FOUNDRY_ENDPOINT),
  })
}

export async function POST() {
  const startedAt = Date.now()
  try {
    const result = await generateText({
      model: resolveModel('openai/gpt-5-mini'),
      system: 'You are a connectivity probe. Reply with exactly: OK',
      prompt: 'Respond with the single word OK to confirm connectivity.',
      maxOutputTokens: 16,
    })

    return NextResponse.json({
      ok: true,
      backend: isAzureFoundryConfigured ? 'azure-ai-foundry' : 'vercel-ai-gateway',
      label: activeModelLabel(),
      reply: result.text.trim(),
      tokens: result.usage?.totalTokens ?? 0,
      latency_ms: Date.now() - startedAt,
    })
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        backend: isAzureFoundryConfigured ? 'azure-ai-foundry' : 'vercel-ai-gateway',
        label: activeModelLabel(),
        error: error instanceof Error ? error.message : 'Unknown error',
        latency_ms: Date.now() - startedAt,
      },
      { status: 502 },
    )
  }
}
