import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { aiOrchestrator } from '@/lib/ai/orchestrator'

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()
    const { data: { user } } = await supabase.auth.getUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { child_id, assessment_type = 'full' } = body

    if (!child_id) {
      return NextResponse.json({ error: 'child_id is required' }, { status: 400 })
    }

    // Verify user owns this child
    const { data: child, error: childError } = await supabase
      .from('children')
      .select('id, first_name, last_name')
      .eq('id', child_id)
      .eq('user_id', user.id)
      .single()

    if (childError || !child) {
      return NextResponse.json({ error: 'Child not found' }, { status: 404 })
    }

    const childName = [child.first_name, child.last_name].filter(Boolean).join(' ')

    // Run the full assessment
    const result = await aiOrchestrator.runFullAssessment({
      user_id: user.id,
      child_id: child.id,
      child_name: childName
    })

    return NextResponse.json({
      success: true,
      assessment_id: result.assessment_id,
      summary: {
        patterns_found: Array.isArray(result.patterns.output) ? result.patterns.output.length : 0,
        risk_status: (result.risk.output as { status: string })?.status || 'unknown',
        ehcp_areas_mapped: Array.isArray(result.ehcp.output) ? result.ehcp.output.length : 0,
        strategies_generated: result.strategies.reduce((acc, s) => acc + (Array.isArray(s.output) ? s.output.length : 0), 0),
        requires_review: result.patterns.requires_review || result.risk.requires_review || result.ehcp.requires_review
      },
      details: result
    })
  } catch (error) {
    console.error('Assessment error:', error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Failed to run assessment' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient()
    const { data: { user } } = await supabase.auth.getUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const childId = searchParams.get('child_id')
    const assessmentId = searchParams.get('assessment_id')

    if (assessmentId) {
      // Get specific assessment
      const { data: assessment, error } = await supabase
        .from('ai_assessments')
        .select(`
          *,
          ai_patterns(*),
          ai_strategies(*),
          ai_reports(*)
        `)
        .eq('id', assessmentId)
        .single()

      if (error || !assessment) {
        return NextResponse.json({ error: 'Assessment not found' }, { status: 404 })
      }

      return NextResponse.json(assessment)
    }

    if (childId) {
      // Get all assessments for a child
      const { data: assessments, error } = await supabase
        .from('ai_assessments')
        .select('*')
        .eq('child_id', childId)
        .order('created_at', { ascending: false })

      if (error) {
        return NextResponse.json({ error: 'Failed to fetch assessments' }, { status: 500 })
      }

      return NextResponse.json(assessments)
    }

    // Get all assessments for user
    const { data: assessments, error } = await supabase
      .from('ai_assessments')
      .select(`
        *,
        children(first_name, last_name)
      `)
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(50)

    if (error) {
      return NextResponse.json({ error: 'Failed to fetch assessments' }, { status: 500 })
    }

    return NextResponse.json(assessments)
  } catch (error) {
    console.error('Fetch error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch assessments' },
      { status: 500 }
    )
  }
}
