import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient()
    const { data: { user } } = await supabase.auth.getUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Check if user is admin
    const { data: profile } = await supabase
      .from('profiles')
      .select('is_admin')
      .eq('id', user.id)
      .single()

    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status') || 'pending'
    const priority = searchParams.get('priority')
    const type = searchParams.get('type')

    let query = supabase
      .from('human_reviews')
      .select(`
        *,
        children(first_name, last_name),
        profiles!human_reviews_user_id_fkey(full_name, email)
      `)
      .eq('status', status)
      .order('created_at', { ascending: false })

    // Non-admins only see their own reviews
    if (!profile?.is_admin) {
      query = query.or(`user_id.eq.${user.id},reviewer_id.eq.${user.id}`)
    }

    if (priority) {
      query = query.eq('priority', priority)
    }

    if (type) {
      query = query.eq('reviewable_type', type)
    }

    const { data: reviews, error } = await query.limit(100)

    if (error) {
      return NextResponse.json({ error: 'Failed to fetch reviews' }, { status: 500 })
    }

    return NextResponse.json(reviews)
  } catch (error) {
    console.error('Fetch error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch reviews' },
      { status: 500 }
    )
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const supabase = await createClient()
    const { data: { user } } = await supabase.auth.getUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { review_id, action, notes, edits } = body

    if (!review_id || !action) {
      return NextResponse.json({ error: 'review_id and action are required' }, { status: 400 })
    }

    const validActions = ['approve', 'reject', 'needs_edit', 'claim']
    if (!validActions.includes(action)) {
      return NextResponse.json({ error: 'Invalid action' }, { status: 400 })
    }

    // Get the review
    const { data: review, error: fetchError } = await supabase
      .from('human_reviews')
      .select('*')
      .eq('id', review_id)
      .single()

    if (fetchError || !review) {
      return NextResponse.json({ error: 'Review not found' }, { status: 404 })
    }

    const updates: Record<string, unknown> = {
      reviewer_id: user.id,
      reviewed_at: new Date().toISOString()
    }

    if (action === 'claim') {
      updates.status = 'in_review'
      updates.reviewed_at = null
    } else if (action === 'approve') {
      updates.status = 'approved'
      updates.reviewer_notes = notes
    } else if (action === 'reject') {
      updates.status = 'rejected'
      updates.reviewer_notes = notes
    } else if (action === 'needs_edit') {
      updates.status = 'needs_edit'
      updates.reviewer_notes = notes
      updates.edits_made = edits
    }

    const { error: updateError } = await supabase
      .from('human_reviews')
      .update(updates)
      .eq('id', review_id)

    if (updateError) {
      return NextResponse.json({ error: 'Failed to update review' }, { status: 500 })
    }

    // Update the linked entity status
    if (action === 'approve' || action === 'reject') {
      const entityTable = review.reviewable_type === 'assessment' ? 'ai_assessments' 
        : review.reviewable_type === 'report' ? 'ai_reports'
        : null

      if (entityTable) {
        await supabase
          .from(entityTable)
          .update({
            status: action === 'approve' ? 'approved' : 'rejected',
            approved_by: action === 'approve' ? user.id : null,
            approved_at: action === 'approve' ? new Date().toISOString() : null
          })
          .eq('id', review.reviewable_id)
      }
    }

    // Log to audit
    await supabase.from('audit_logs').insert({
      user_id: user.id,
      action: `review_${action}`,
      entity_type: 'human_review',
      entity_id: review_id,
      details: { action, notes, reviewable_type: review.reviewable_type }
    })

    return NextResponse.json({ success: true, action })
  } catch (error) {
    console.error('Review error:', error)
    return NextResponse.json(
      { error: 'Failed to process review' },
      { status: 500 }
    )
  }
}
