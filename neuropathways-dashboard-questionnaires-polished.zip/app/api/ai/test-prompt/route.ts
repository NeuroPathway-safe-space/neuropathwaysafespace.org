import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { generateText } from 'ai'
import { resolveModel } from '@/lib/ai/model'

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()
    const { data: { user } } = await supabase.auth.getUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Check if admin
    const { data: profile } = await supabase
      .from('profiles')
      .select('is_admin')
      .eq('id', user.id)
      .single()

    if (!profile?.is_admin) {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
    }

    const { system_prompt, user_prompt, model, temperature } = await request.json()

    if (!system_prompt || !user_prompt) {
      return NextResponse.json({ error: 'Missing prompts' }, { status: 400 })
    }

    const startTime = Date.now()
    
    const result = await generateText({
      model: resolveModel(model || 'openai/gpt-5-mini'),
      system: system_prompt,
      prompt: user_prompt,
      temperature: temperature || 0.3,
      maxOutputTokens: 1000 // Limit for testing
    })

    const latency = Date.now() - startTime

    return NextResponse.json({
      result: result.text,
      tokens: result.usage?.totalTokens || 0,
      latency_ms: latency,
      model: model || 'openai/gpt-5-mini'
    })
  } catch (error) {
    console.error('Test prompt error:', error)
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : 'Test failed' 
    }, { status: 500 })
  }
}
