import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { aiOrchestrator, PatternResult, Strategy } from '@/lib/ai/orchestrator'

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()
    const { data: { user } } = await supabase.auth.getUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { child_id, report_type, assessment_id } = await request.json()

    if (!child_id || !report_type) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    // Get child info
    const { data: child } = await supabase
      .from('children')
      .select('first_name, last_name')
      .eq('id', child_id)
      .eq('user_id', user.id)
      .single()

    if (!child) {
      return NextResponse.json({ error: 'Child not found' }, { status: 404 })
    }

    // Get latest assessment or run one
    let assessment
    if (assessment_id) {
      const { data } = await supabase
        .from('ai_assessments')
        .select('*, ai_patterns(*), ai_strategies(*)')
        .eq('id', assessment_id)
        .single()
      assessment = data
    } else {
      // Get the most recent assessment
      const { data } = await supabase
        .from('ai_assessments')
        .select('*, ai_patterns(*), ai_strategies(*)')
        .eq('child_id', child_id)
        .order('created_at', { ascending: false })
        .limit(1)
        .single()
      assessment = data
    }

    if (!assessment) {
      return NextResponse.json({ 
        error: 'No assessment found. Please run an AI assessment first.' 
      }, { status: 400 })
    }

    // Generate report
    await aiOrchestrator.initialize()
    const result = await aiOrchestrator.generateReport({
      user_id: user.id,
      child_id,
      child_name: `${child.first_name} ${child.last_name}`,
      report_type: report_type as 'parent_summary' | 'teacher_summary' | 'clinical_summary' | 'ehcp_evidence',
      assessment: {
        patterns: (assessment.patterns || assessment.ai_patterns || []) as PatternResult[],
        risk_status: assessment.risk_status || 'green',
        strategies: (assessment.ai_strategies || []) as Strategy[]
      }
    })

    return NextResponse.json({
      success: true,
      report: result.output,
      run_id: result.run_id,
      confidence: result.confidence_score
    })
  } catch (error) {
    console.error('Report generation error:', error)
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : 'Failed to generate report' 
    }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient()
    const { data: { user } } = await supabase.auth.getUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const childId = searchParams.get('child_id')
    const reportType = searchParams.get('report_type')

    let query = supabase
      .from('ai_reports')
      .select('*, children(first_name, last_name)')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })

    if (childId) {
      query = query.eq('child_id', childId)
    }
    if (reportType) {
      query = query.eq('report_type', reportType)
    }

    const { data: reports, error } = await query

    if (error) throw error

    return NextResponse.json({ reports })
  } catch (error) {
    console.error('Fetch reports error:', error)
    return NextResponse.json({ error: 'Failed to fetch reports' }, { status: 500 })
  }
}
