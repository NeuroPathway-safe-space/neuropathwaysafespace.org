import { createClient } from "@/lib/supabase/server";
import { NextResponse } from "next/server";

// Everyday observation questionnaire submission.
// Stores a structured check-in AND threads it into the evidence pipeline:
//  - one observation row (so it counts toward EHCP evidence + patterns)
//  - one pattern_analysis summary (so it surfaces on the professional dashboard)
// This is needs-first and never diagnostic.

interface CheckInPayload {
  childId: string;
  cadence: "daily" | "weekly";
  responses: Record<string, number | string>;
  scoreFields: string[]; // which response keys are 1-5 scores
  summary: string;
}

export async function POST(req: Request) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  }

  const body = (await req.json()) as CheckInPayload;
  const { childId, cadence, responses, scoreFields, summary } = body;

  if (!childId || !cadence || !responses) {
    return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
  }

  // Average the 1-5 score fields into an overall score.
  const scores = scoreFields
    .map((f) => Number(responses[f]))
    .filter((n) => !Number.isNaN(n) && n > 0);
  const avg =
    scores.length > 0 ? scores.reduce((a, b) => a + b, 0) / scores.length : null;
  const overallScore = avg == null ? null : Math.round(avg);

  // Lower average = greater need. Map to a 1-5 severity (inverted).
  const severity = avg == null ? null : Math.max(1, Math.min(5, 6 - Math.round(avg)));

  // 1) Persist the structured check-in (upsert: one per child/cadence/day).
  const { data: checkIn, error: checkInError } = await supabase
    .from("check_ins")
    .upsert(
      {
        user_id: user.id,
        child_id: childId,
        cadence,
        responses,
        summary,
        overall_score: overallScore,
        check_in_date: new Date().toISOString().slice(0, 10),
      },
      { onConflict: "child_id,cadence,check_in_date" },
    )
    .select("id")
    .single();

  if (checkInError) {
    console.error("[v0] check-in insert failed:", checkInError);
    return NextResponse.json({ error: checkInError.message }, { status: 500 });
  }

  // 2) Create an observation so the check-in feeds EHCP evidence + patterns.
  const cadenceLabel = cadence === "daily" ? "Daily check-in" : "Weekly review";
  const { data: observation } = await supabase
    .from("observations")
    .insert({
      user_id: user.id,
      child_id: childId,
      title: `${cadenceLabel} - ${new Date().toLocaleDateString("en-GB")}`,
      behaviour: summary || `${cadenceLabel} completed`,
      severity,
      setting: "Everyday observation questionnaire",
    })
    .select("id")
    .single();

  // Link the observation back to the check-in.
  if (observation?.id && checkIn?.id) {
    await supabase
      .from("check_ins")
      .update({ observation_id: observation.id })
      .eq("id", checkIn.id);
  }

  // 3) For weekly reviews (or concerning daily scores) write a professional-facing summary.
  const isConcerning = severity != null && severity >= 4;
  if (cadence === "weekly" || isConcerning) {
    const periodStart = new Date(
      Date.now() - (cadence === "weekly" ? 7 : 1) * 24 * 60 * 60 * 1000,
    );
    await supabase.from("pattern_analysis").insert({
      child_id: childId,
      domain: "everyday_observation",
      pattern_name: `${cadenceLabel} summary`,
      summary,
      trend: isConcerning ? "monitor" : "stable",
      frequency: cadence === "weekly" ? "Weekly review" : "Daily check-in",
      severity: isConcerning ? "elevated" : "typical",
      evidence_count: scores.length,
      period_start: periodStart.toISOString().slice(0, 10),
      period_end: new Date().toISOString().slice(0, 10),
      source: "observations",
    });
  }

  // 4) Audit trail.
  await supabase.from("audit_logs").insert({
    user_id: user.id,
    action: "check_in_submitted",
    entity_type: "child",
    entity_id: childId,
    details: { cadence, overall_score: overallScore, severity },
  });

  return NextResponse.json({ success: true, overallScore });
}
