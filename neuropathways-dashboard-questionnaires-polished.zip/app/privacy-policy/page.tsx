import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Shield, Lock, FileCheck, Users, Eye, Trash2, AlertTriangle, Phone, ArrowLeft } from "lucide-react";
import Link from "next/link";

const policies = [
  {
    icon: Shield,
    title: "UK GDPR Compliance",
    content: [
      "All personal data is processed lawfully, fairly, and transparently under UK GDPR and the Data Protection Act 2018.",
      "Data processing is based on legitimate interests (supporting EHCP applications) and/or consent.",
      "We process only the minimum data necessary for the stated purpose.",
      "Data subjects have full rights to access, rectify, and request deletion of their data.",
    ],
  },
  {
    icon: Lock,
    title: "Data Security",
    content: [
      "All data is encrypted at rest using AES-256 encryption.",
      "Data in transit is protected using TLS 1.3 encryption.",
      "Access is restricted through secure authentication and authorisation controls.",
      "Regular security audits and vulnerability assessments are conducted.",
      "Data is stored on secure servers located in the UK/EU.",
    ],
  },
  {
    icon: Eye,
    title: "Access Control",
    content: [
      "Each user can only access their own observations and data.",
      "Schools and parents maintain separate accounts with no cross-access.",
      "Admin access is strictly controlled and audited.",
      "Row Level Security (RLS) policies enforce data isolation at the database level.",
    ],
  },
  {
    icon: FileCheck,
    title: "Data Retention",
    content: [
      "Observation data is retained for as long as needed for EHCP purposes.",
      "Users can request deletion of their data at any time.",
      "Upon account deletion, all associated data is permanently removed within 30 days.",
      "Audit logs may be retained for compliance purposes with personal data anonymised.",
    ],
  },
  {
    icon: Users,
    title: "Safeguarding Responsibilities",
    content: [
      "This tool supports evidence collection but does not replace safeguarding procedures.",
      "Users remain responsible for reporting safeguarding concerns through proper channels.",
      "Concerns must be reported to your Designated Safeguarding Lead (DSL) or local authority.",
      "The tool includes prompts to remind users of their safeguarding duties.",
    ],
  },
  {
    icon: Trash2,
    title: "Your Rights",
    content: [
      "Right to access: Request a copy of your personal data.",
      "Right to rectification: Request correction of inaccurate data.",
      "Right to erasure: Request deletion of your data.",
      "Right to portability: Receive your data in a machine-readable format.",
      "Right to object: Object to processing of your data.",
    ],
  },
];

export default function PrivacyPolicyPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <Link href="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6">
        <ArrowLeft className="h-4 w-4" />
        Back to Home
      </Link>

      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground mb-2">Privacy & Safeguarding Policy</h1>
        <p className="text-muted-foreground">How we protect your data and support safeguarding</p>
      </div>

      {/* Emergency Banner */}
      <Card className="bg-red-500/10 border-red-500/30 mb-8">
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <AlertTriangle className="h-6 w-6 text-red-500 shrink-0" />
            <div>
              <h2 className="font-semibold text-red-400 mb-2">Safeguarding Emergency</h2>
              <p className="text-sm text-muted-foreground mb-3">
                If you believe a child is in immediate danger, do not wait to record observations. Contact:
              </p>
              <div className="flex flex-wrap gap-3 text-sm">
                <a href="tel:999" className="inline-flex items-center gap-1 text-red-400 hover:underline">
                  <Phone className="h-4 w-4" />
                  Emergency: 999
                </a>
                <a href="tel:08088005000" className="inline-flex items-center gap-1 text-amber-400 hover:underline">
                  <Phone className="h-4 w-4" />
                  NSPCC: 0808 800 5000
                </a>
                <span className="text-muted-foreground">or your local authority children&apos;s services</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Introduction */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>About This Policy</CardTitle>
          <CardDescription>Last updated: {new Date().toLocaleDateString("en-GB", { month: "long", year: "numeric" })}</CardDescription>
        </CardHeader>
        <CardContent className="prose prose-sm max-w-none text-muted-foreground">
          <p>
            NeuroPathway Safe Space (&quot;we&quot;, &quot;us&quot;, or &quot;our&quot;) is committed to protecting the privacy and safety of 
            all users, with particular attention to the children and young people whose observations are recorded 
            using our platform.
          </p>
          <p>
            This policy explains how we collect, use, and protect personal data in accordance with UK GDPR, 
            the Data Protection Act 2018, and safeguarding best practices. We recognise the sensitive nature 
            of information about children&apos;s educational needs and behaviour, and have designed our systems 
            to maintain the highest standards of data protection and safeguarding awareness.
          </p>
        </CardContent>
      </Card>

      {/* Policy Sections */}
      <div className="space-y-6">
        {policies.map((policy, idx) => {
          const Icon = policy.icon;
          return (
            <Card key={idx}>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <CardTitle className="text-lg">{policy.title}</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {policy.content.map((item, itemIdx) => (
                    <li key={itemIdx} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <span className="text-primary mt-1">•</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Contact Information */}
      <Card className="mt-8">
        <CardHeader>
          <CardTitle>Contact Us</CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground space-y-4">
          <p>
            If you have any questions about this policy, wish to exercise your data rights, or have 
            any concerns about how we handle data, please contact us:
          </p>
          <div className="p-4 bg-secondary/50 rounded-lg">
            <p><strong>Data Protection Enquiries:</strong> privacy@neuropathway.app</p>
            <p><strong>Safeguarding Concerns:</strong> safeguarding@neuropathway.app</p>
          </div>
          <p className="text-xs">
            You also have the right to lodge a complaint with the Information Commissioner&apos;s Office (ICO) 
            if you believe your data protection rights have been breached: <a href="https://ico.org.uk" className="text-primary hover:underline" target="_blank" rel="noopener noreferrer">ico.org.uk</a>
          </p>
        </CardContent>
      </Card>

      {/* Mental Health Disclaimer */}
      <div className="mt-8 p-6 bg-amber-500/10 border border-amber-500/30 rounded-lg">
        <div className="flex items-start gap-4">
          <AlertTriangle className="h-6 w-6 text-amber-500 shrink-0" />
          <div>
            <h3 className="font-semibold text-amber-400 mb-2">Mental Health Disclaimer</h3>
            <p className="text-sm text-muted-foreground">
              NeuroPathway is an observation tracking and evidence building tool. It is not a mental health service 
              and does not provide medical advice, diagnosis, or treatment. If you are concerned about a child&apos;s 
              mental health or your own wellbeing, please contact:
            </p>
            <div className="mt-3 flex flex-wrap gap-3 text-sm">
              <a href="tel:116123" className="text-amber-400 hover:underline">Samaritans: 116 123 (24/7)</a>
              <a href="tel:08001111" className="text-amber-400 hover:underline">Childline: 0800 1111</a>
              <span className="text-muted-foreground">or speak to your GP or school SENCO</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
