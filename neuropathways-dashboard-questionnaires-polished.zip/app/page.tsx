import { Navbar } from "@/components/navbar";
import { HeroCard } from "@/components/hero-card";
import { CrisisBanner } from "@/components/crisis-banner";
import { ChallengeSection } from "@/components/challenge-section";
import { SolutionSection } from "@/components/solution-section";
import { IndividualEHCPSection } from "@/components/individual-ehcp-section";
import { PatternRecognitionSection } from "@/components/pattern-recognition-section";
import { ComplianceSection } from "@/components/compliance-section";
import { WhyItWorks } from "@/components/why-it-works";
import { Footer } from "@/components/footer";

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <Navbar />
      <HeroCard />
      <CrisisBanner />
      <ChallengeSection />
      <SolutionSection />
      <IndividualEHCPSection />
      <PatternRecognitionSection />
      <ComplianceSection />
      <WhyItWorks />
      <Footer />
    </main>
  );
}
